import { supabase } from "./supabase";

export type CostType = "material" | "labor" | "equipment" | "other";

export interface ProjectCost {
  id: string;
  project_id: string;
  cost_type: CostType;
  source_id: string | null;
  source_type?: string | null;
  description: string;
  amount: number;
  cost_date: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface CostSummary {
  material_cost: number;
  labor_cost: number;
  equipment_cost: number;
  other_cost: number;
  total_cost: number;
}

export interface BudgetSummary {
  material_budget: number;
  labor_budget: number;
  equipment_budget: number;
  other_budget: number;
  total_budget: number;
}

export interface BudgetVsActual {
  budget: BudgetSummary;
  actual: CostSummary;
  variance: {
    material_variance: number;
    labor_variance: number;
    equipment_variance: number;
    other_variance: number;
    total_variance: number;
  };
}

export interface FinancialSummary {
  total_budget: number;
  total_cost: number;
  remaining_budget: number;
  profit_margin: number;
}

export async function createProjectCost(
  projectId: string,
  costType: CostType,
  description: string,
  amount: number,
  costDate?: string,
  sourceId?: string,
  notes?: string
) {
  try {
    const insertData: any = {
      project_id: projectId,
      cost_type: costType,
      description,
      amount,
      source_id: sourceId || null,
      notes: notes || null,
    };

    if (costDate) {
      insertData.cost_date = costDate;
    }

    const { data, error } = await supabase
      .from("project_costs")
      .insert(insertData)
      .select()
      .single();

    if (error) {
      console.error("Error creating project cost:", error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (e) {
    console.error("Exception creating project cost:", e);
    return { success: false, error: e };
  }
}

export async function getProjectCostSummary(
  projectId: string
): Promise<CostSummary> {
  try {
    const { data, error } = await supabase
      .from("project_costs")
      .select("cost_type, amount")
      .eq("project_id", projectId);

    if (error) {
      console.error("Error fetching project costs:", error);
      return {
        material_cost: 0,
        labor_cost: 0,
        equipment_cost: 0,
        other_cost: 0,
        total_cost: 0,
      };
    }

    const summary: CostSummary = {
      material_cost: 0,
      labor_cost: 0,
      equipment_cost: 0,
      other_cost: 0,
      total_cost: 0,
    };

    data?.forEach((cost) => {
      const amount = Number(cost.amount) || 0;
      summary.total_cost += amount;

      switch (cost.cost_type) {
        case "material":
          summary.material_cost += amount;
          break;
        case "labor":
          summary.labor_cost += amount;
          break;
        case "equipment":
          summary.equipment_cost += amount;
          break;
        case "other":
          summary.other_cost += amount;
          break;
      }
    });

    return summary;
  } catch (e) {
    console.error("Exception fetching cost summary:", e);
    return {
      material_cost: 0,
      labor_cost: 0,
      equipment_cost: 0,
      other_cost: 0,
      total_cost: 0,
    };
  }
}

export async function getProjectBudgetSummary(
  projectId: string
): Promise<BudgetSummary> {
  try {
    const { data: boqHeaders, error: headerError } = await supabase
      .from("boq_headers")
      .select("id")
      .eq("project_id", projectId)
      .order("updated_at", { ascending: false })
      .order("version", { ascending: false })
      .limit(1);

    if (headerError || !boqHeaders || boqHeaders.length === 0) {
      return {
        material_budget: 0,
        labor_budget: 0,
        equipment_budget: 0,
        other_budget: 0,
        total_budget: 0,
      };
    }

    const boqId = boqHeaders[0].id;

    const { data: items, error: itemsError } = await supabase
      .from("boq_items")
      .select("qty, rate, category, item")
      .eq("boq_id", boqId)
      .eq("is_section_header", false);

    if (itemsError || !items) {
      return {
        material_budget: 0,
        labor_budget: 0,
        equipment_budget: 0,
        other_budget: 0,
        total_budget: 0,
      };
    }

    const summary: BudgetSummary = {
      material_budget: 0,
      labor_budget: 0,
      equipment_budget: 0,
      other_budget: 0,
      total_budget: 0,
    };

    items.forEach((item) => {
      const qty = Number(item.qty) || 0;
      const rate = Number(item.rate) || 0;
      const amount = qty * rate;

      summary.total_budget += amount;

      const category = (item.category || "").toLowerCase();
      const itemName = (item.item || "").toLowerCase();
      const combined = `${category} ${itemName}`;

      if (
        combined.includes("labor") ||
        combined.includes("labour") ||
        combined.includes("crew") ||
        combined.includes("worker")
      ) {
        summary.labor_budget += amount;
      } else if (
        combined.includes("equipment") ||
        combined.includes("machinery") ||
        combined.includes("tool") ||
        combined.includes("crane") ||
        combined.includes("excavator")
      ) {
        summary.equipment_budget += amount;
      } else if (
        combined.includes("material") ||
        combined.includes("concrete") ||
        combined.includes("steel") ||
        combined.includes("brick") ||
        combined.includes("cement") ||
        combined.includes("sand") ||
        combined.includes("aggregate") ||
        combined.includes("timber") ||
        combined.includes("paint") ||
        combined.includes("pipe") ||
        combined.includes("cable")
      ) {
        summary.material_budget += amount;
      } else {
        summary.other_budget += amount;
      }
    });

    return summary;
  } catch (e) {
    console.error("Exception fetching budget summary:", e);
    return {
      material_budget: 0,
      labor_budget: 0,
      equipment_budget: 0,
      other_budget: 0,
      total_budget: 0,
    };
  }
}

export async function getBudgetVsActual(
  projectId: string
): Promise<BudgetVsActual> {
  const budget = await getProjectBudgetSummary(projectId);
  const actual = await getProjectCostSummary(projectId);

  return {
    budget,
    actual,
    variance: {
      material_variance: budget.material_budget - actual.material_cost,
      labor_variance: budget.labor_budget - actual.labor_cost,
      equipment_variance: budget.equipment_budget - actual.equipment_cost,
      other_variance: budget.other_budget - actual.other_cost,
      total_variance: budget.total_budget - actual.total_cost,
    },
  };
}

export async function fetchProjectCosts(projectId: string) {
  try {
    const { data, error } = await supabase
      .from("project_costs")
      .select("*")
      .eq("project_id", projectId)
      .order("cost_date", { ascending: false })
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching project costs:", error);
      return { success: false, error, data: [] };
    }

    return { success: true, data: data || [] };
  } catch (e) {
    console.error("Exception fetching project costs:", e);
    return { success: false, error: e, data: [] };
  }
}

export async function deleteProjectCost(costId: string) {
  try {
    const { error } = await supabase
      .from("project_costs")
      .delete()
      .eq("id", costId);

    if (error) {
      console.error("Error deleting project cost:", error);
      return { success: false, error };
    }

    return { success: true };
  } catch (e) {
    console.error("Exception deleting project cost:", e);
    return { success: false, error: e };
  }
}

export async function createCostFromProcurement(
  procurementItem: {
    id: string;
    project_id: string;
    material_name: string;
    quantity: number;
    unit: string | null;
  },
  unitCost: number
) {
  const totalAmount = Number(procurementItem.quantity) * unitCost;
  const description = `${procurementItem.material_name} - ${procurementItem.quantity} ${procurementItem.unit || "units"}`;

  return createProjectCost(
    procurementItem.project_id,
    "material",
    description,
    totalAmount,
    undefined,
    procurementItem.id,
    `Auto-generated from procurement item`
  );
}

export async function getProjectFinancialSummary(
  projectId: string
): Promise<FinancialSummary> {
  const budget = await getProjectBudgetSummary(projectId);
  const costs = await getProjectCostSummary(projectId);

  const total_budget = budget.total_budget;
  const total_cost = costs.total_cost;
  const remaining_budget = total_budget - total_cost;
  const profit_margin = total_budget > 0 ? (remaining_budget / total_budget) * 100 : 0;

  return {
    total_budget,
    total_cost,
    remaining_budget,
    profit_margin,
  };
}

export interface CommittedDeliveredSummary {
  total_budget: number;
  committed_value: number;
  delivered_value: number;
  remaining_budget: number;
  variance: number;
}

export interface CategoryBreakdown {
  category: string;
  committed: number;
  delivered: number;
  remaining: number;
}

export interface CommittedDeliveredSummaryByBucket {
  material_committed: number;
  labor_committed: number;
  equipment_committed: number;
  other_committed: number;
  total_committed: number;
}

export async function getCommittedDeliveredSummary(
  projectId: string
): Promise<CommittedDeliveredSummary> {
  try {
    const budget = await getProjectBudgetSummary(projectId);

    const { data: poItems, error: poError } = await supabase
      .from("purchase_order_items")
      .select(`
        total_amount,
        delivered_qty,
        quantity,
        unit_rate,
        purchase_order_id,
        purchase_orders!inner(project_id)
      `)
      .eq("purchase_orders.project_id", projectId);

    if (poError) {
      console.error("Error fetching PO items:", poError);
    }

    let committed_value = 0;
    let delivered_value = 0;

    if (poItems) {
      poItems.forEach((item: any) => {
        committed_value += Number(item.total_amount || 0);
        const deliveredQty = Number(item.delivered_qty || 0);
        const unitRate = Number(item.unit_rate || 0);
        delivered_value += deliveredQty * unitRate;
      });
    }

    const total_budget = budget.total_budget;
    const remaining_budget = total_budget - delivered_value;
    const variance = total_budget - committed_value;

    return {
      total_budget,
      committed_value,
      delivered_value,
      remaining_budget,
      variance,
    };
  } catch (e) {
    console.error("Exception getting committed/delivered summary:", e);
    return {
      total_budget: 0,
      committed_value: 0,
      delivered_value: 0,
      remaining_budget: 0,
      variance: 0,
    };
  }
}

export async function getCommittedDeliveredSummaryByBucket(
  projectId: string
): Promise<CommittedDeliveredSummaryByBucket> {
  try {
    const { data: poItems, error: poError } = await supabase
      .from("purchase_order_items")
      .select(`
        total_amount,
        procurement_item_id,
        procurement_items(finance_bucket),
        purchase_orders!inner(project_id)
      `)
      .eq("purchase_orders.project_id", projectId);

    if (poError) {
      console.error("Error fetching PO items for bucket summary:", poError);
    }

    const result: CommittedDeliveredSummaryByBucket = {
      material_committed: 0,
      labor_committed: 0,
      equipment_committed: 0,
      other_committed: 0,
      total_committed: 0,
    };

    if (poItems) {
      poItems.forEach((item: any) => {
        const amount = Number(item.total_amount || 0);
        const bucket = item.procurement_items?.finance_bucket || 'other';
        
        result.total_committed += amount;
        
        switch (bucket) {
          case 'material':
            result.material_committed += amount;
            break;
          case 'labor':
            result.labor_committed += amount;
            break;
          case 'equipment':
            result.equipment_committed += amount;
            break;
          case 'other':
          default:
            result.other_committed += amount;
            break;
        }
      });
    }

    return result;
  } catch (e) {
    console.error("Exception getting committed/delivered summary by bucket:", e);
    return {
      material_committed: 0,
      labor_committed: 0,
      equipment_committed: 0,
      other_committed: 0,
      total_committed: 0,
    };
  }
}

export interface CommittedDeliveredSummaryByBucketDetailed {
  material_committed: number;
  labor_committed: number;
  equipment_committed: number;
  other_committed: number;
  total_committed: number;
  material_delivered: number;
  labor_delivered: number;
  equipment_delivered: number;
  other_delivered: number;
  total_delivered: number;
}

export async function getCommittedDeliveredSummaryByBucketDetailed(
  projectId: string
): Promise<CommittedDeliveredSummaryByBucketDetailed> {
  try {
    const { data: poItems, error: poError } = await supabase
      .from("purchase_order_items")
      .select(`
        total_amount,
        delivered_qty,
        unit_rate,
        procurement_item_id,
        procurement_items(finance_bucket),
        purchase_orders!inner(project_id)
      `)
      .eq("purchase_orders.project_id", projectId);

    if (poError) {
      console.error("Error fetching PO items for detailed bucket summary:", poError);
    }

    const result: CommittedDeliveredSummaryByBucketDetailed = {
      material_committed: 0,
      labor_committed: 0,
      equipment_committed: 0,
      other_committed: 0,
      total_committed: 0,
      material_delivered: 0,
      labor_delivered: 0,
      equipment_delivered: 0,
      other_delivered: 0,
      total_delivered: 0,
    };

    if (poItems) {
      poItems.forEach((item: any) => {
        const amount = Number(item.total_amount || 0);
        const deliveredQty = Number(item.delivered_qty || 0);
        const unitRate = Number(item.unit_rate || 0);
        const deliveredAmount = deliveredQty * unitRate;
        const bucket = item.procurement_items?.finance_bucket || 'other';
        
        result.total_committed += amount;
        result.total_delivered += deliveredAmount;
        
        switch (bucket) {
          case 'material':
            result.material_committed += amount;
            result.material_delivered += deliveredAmount;
            break;
          case 'labor':
            result.labor_committed += amount;
            result.labor_delivered += deliveredAmount;
            break;
          case 'equipment':
            result.equipment_committed += amount;
            result.equipment_delivered += deliveredAmount;
            break;
          case 'other':
          default:
            result.other_committed += amount;
            result.other_delivered += deliveredAmount;
            break;
        }
      });
    }

    return result;
  } catch (e) {
    console.error("Exception getting committed/delivered summary by bucket detailed:", e);
    return {
      material_committed: 0,
      labor_committed: 0,
      equipment_committed: 0,
      other_committed: 0,
      total_committed: 0,
      material_delivered: 0,
      labor_delivered: 0,
      equipment_delivered: 0,
      other_delivered: 0,
      total_delivered: 0,
    };
  }
}

export async function getCategoryBreakdown(
  projectId: string
): Promise<CategoryBreakdown[]> {
  try {
    const { data: poItems, error } = await supabase
      .from("purchase_order_items")
      .select(`
        total_amount,
        delivered_qty,
        quantity,
        unit_rate,
        procurement_item_id,
        purchase_orders!inner(project_id)
      `)
      .eq("purchase_orders.project_id", projectId);

    if (error) {
      console.error("Error fetching PO items for category breakdown:", error);
      return [];
    }

    if (!poItems || poItems.length === 0) {
      return [];
    }

    const procurementItemIds = poItems
      .map((item: any) => item.procurement_item_id)
      .filter(Boolean);

    if (procurementItemIds.length === 0) {
      return [];
    }

    const { data: procItems } = await supabase
      .from("procurement_items")
      .select("id, category")
      .in("id", procurementItemIds);

    const categoryMap = new Map<string, string>();
    procItems?.forEach((item: any) => {
      if (item.category) {
        categoryMap.set(item.id, item.category);
      }
    });

    const categoryTotals = new Map<string, { committed: number; delivered: number }>();

    poItems.forEach((item: any) => {
      const category = item.procurement_item_id
        ? categoryMap.get(item.procurement_item_id) || "Uncategorized"
        : "Uncategorized";

      const committed = Number(item.total_amount || 0);
      const deliveredQty = Number(item.delivered_qty || 0);
      const unitRate = Number(item.unit_rate || 0);
      const delivered = deliveredQty * unitRate;

      const existing = categoryTotals.get(category) || { committed: 0, delivered: 0 };
      categoryTotals.set(category, {
        committed: existing.committed + committed,
        delivered: existing.delivered + delivered,
      });
    });

    const breakdown: CategoryBreakdown[] = [];
    categoryTotals.forEach((totals, category) => {
      breakdown.push({
        category,
        committed: totals.committed,
        delivered: totals.delivered,
        remaining: totals.committed - totals.delivered,
      });
    });

    breakdown.sort((a, b) => b.committed - a.committed);

    return breakdown;
  } catch (e) {
    console.error("Exception getting category breakdown:", e);
    return [];
  }
}
