// src/lib/import/types.ts
//
// Generic, config-driven Import Wizard types. One EntityImportConfig per
// importable entity type (Clients now; Projects/Expenses follow in later
// rounds). Adding a future entity — Workers, Suppliers, whatever a future
// customer's migration needs — means writing one new config object and
// registering it in entityConfigs.ts; the wizard shell (ImportWizard.tsx)
// never needs to change.

export type ImportFieldType = "text" | "email" | "phone" | "number" | "date" | "select" | "lookup";

export interface ImportFieldConfig {
  key: string;                 // DB column name this field maps to
  label: string;                // shown in the mapping UI
  required: boolean;
  type: ImportFieldType;
  // Lowercased/normalized header strings that auto-suggest this field during
  // column mapping — real-world exports rarely use the exact DB column name
  // (Zoho's "Company Name" vs. our "name", for instance).
  aliases?: string[];
  options?: { value: string; label: string }[]; // for type "select"
  // For type "lookup": which prior entity's lookup map (see LookupMaps
  // below) this field resolves against, e.g. a Projects "Client" column
  // resolving to a client_id via the Clients pass's lookup map. Unused by
  // Clients (the first entity in the chain, nothing to resolve against).
  lookupEntityKey?: string;
  // Allows more than one uploaded column to be mapped to this field at
  // once — e.g. a single "address" target built from several separate
  // Billing Address / City / State / Country columns, which is how most
  // accounting/CRM exports actually split address data (confirmed against
  // a real Zoho Contacts export: 6 separate Billing-prefixed columns, no
  // single "Address" column at all). When true, the Map Columns step lets
  // multiple headers point at this field; their values are concatenated —
  // in the order the columns appear in the uploaded file, skipping any
  // blank parts — into one final string, joined by `joinWith`. Ordinary
  // (non-multiSource) fields still only accept one source column, same as
  // before.
  multiSource?: boolean;
  joinWith?: string; // only used when multiSource is true; defaults to ", "
  // Only meaningful when type is "lookup". Plain lookup fields (e.g.
  // Projects' client) leave an unresolved reference null — non-blocking,
  // but never creates anything. createIfMissing fields (e.g. Expenses'
  // category, a simple flat list the user hasn't necessarily pre-
  // populated) instead create a new row in the target table when nothing
  // matches, via the config's createLookupTarget hook below.
  createIfMissing?: boolean;
  // Only meaningful for a grouped entity (see EntityImportConfig.groupByField
  // below) — e.g. Invoices, where Zoho's export has one row per line item
  // with invoice-level fields (number, date, client) repeated identically
  // across every row belonging to the same invoice. true = this field
  // varies per row WITHIN a group (item description, quantity, rate) and
  // gets collected into an array, one entry per underlying row. Unset/
  // false (the default) = a header field — identical across every row in
  // a well-formed group, so its value is taken from the group's first row.
  isLineItemField?: boolean;
}

// Structured field-issue tagging — used internally so grouped entities can
// tell a header-field problem (blocks the whole group) apart from a
// line-item-field problem (excludes just that one line item) without
// parsing formatted message strings back apart. Ungrouped entities never
// see this shape directly; PreviewRow.errors/warnings stay plain string[]
// either way.
export interface FieldIssue {
  fieldKey: string;
  message: string;
}

export interface ParsedFile {
  fileName: string;
  headers: string[];
  rows: Record<string, string>[]; // raw string cell values, keyed by original header
}

// header -> fieldKey it's mapped to, or null if the column is skipped
export type ColumnMapping = Record<string, string | null>;

export type DedupAction = "create" | "skip" | "update";

export interface ExistingRecord {
  id: string;
  label: string;   // human-readable label for display, e.g. the client's name
  keys: string[];   // normalized candidate match keys for this existing row
}

// One line item within a grouped PreviewRow (e.g. one row of an invoice's
// underlying CSV rows). Kept separate from the header's own errors —
// a line item with errors is simply excluded from what actually gets
// created, it doesn't block the rest of the invoice.
export interface GroupedLineItem {
  values: Record<string, any>;
  errors: string[];       // non-empty means this specific line item is excluded from import
  sourceRowIndex: number; // which underlying parsed row this came from
}

export interface PreviewRow {
  rowIndex: number;             // index into ParsedFile.rows (for a grouped entity, the first underlying row in the group), kept for traceability into results
  values: Record<string, any>;  // mapped + type-coerced field values (fallback-derived values already applied) — header-level values only for a grouped entity
  errors: string[];             // validation errors on REQUIRED (header) fields; non-empty blocks import for this row
  warnings: string[];           // format issues on OPTIONAL fields — reported but non-blocking; that field's value is dropped, not the whole row
  fallbackFields: string[];     // required fields whose value was derived via config.buildFallback rather than the source file — flagged, not hidden
  match: ExistingRecord | null; // existing DB row this one appears to duplicate, if any
  action: DedupAction;          // what happens on import — user-adjustable per row when a match exists
  // Populated only for a grouped entity (config.groupByField set) — every
  // underlying row that shared this group's key, and which of them are
  // actually valid enough to become a real line item on import.
  lineItems?: GroupedLineItem[];
  groupRowIndexes?: number[];
}

export type RowOutcome =
  | { status: "created"; rowIndex: number; id: string }
  | { status: "updated"; rowIndex: number; id: string }
  | { status: "skipped"; rowIndex: number; reason: string }
  // Had a validation/routing error (required field missing, or
  // validateFieldWithLookups excluding it) and was therefore never
  // attempted against the DB at all — distinct from "failed" below, which
  // means the row WAS attempted and the database itself rejected it.
  // Conflating these two (both previously reported as "failed") is what
  // made Bills' first real run look like 129 catastrophic failures when
  // 120 of them were rows correctly excluded before import ever started,
  // working exactly as designed.
  | { status: "excluded"; rowIndex: number; reason: string }
  | { status: "failed"; rowIndex: number; error: string };

// Built up as each entity pass completes — e.g. after Clients import, a
// lookup map of normalized-name/email -> new client id lets the Projects
// pass resolve a "Client" column without the user re-entering anything.
// Seeded from existing DB rows too, so referencing a client that predates
// this wizard entirely also resolves correctly.
export type LookupMaps = Record<string, Map<string, { id: string; label: string }>>;

export interface EntityImportConfig {
  key: string;      // e.g. "clients" — also the LookupMaps key other entities reference
  label: string;     // "Clients"
  table: string;      // Supabase table name
  fields: ImportFieldConfig[];
  dedupEnabled: boolean; // false for Expenses per the approved plan — no dedup, always "create"

  // Lookup maps this config needs loaded beyond what its own fields'
  // lookupEntityKey values already imply — SettingsImportPage.tsx's
  // "which lookup maps does this entity need" computation is normally
  // driven entirely by scanning field.lookupEntityKey, but a
  // validateFieldWithLookups check can need a DIFFERENT lookup than the
  // field's own (e.g. Bills' supplier_id field resolves against
  // lookups.suppliers for its own FK, via its own lookupEntityKey, but
  // validateFieldWithLookups on that same field ALSO needs
  // lookups.workers loaded, to check whether the vendor is actually a
  // subcontractor rather than a real supplier — a single field can only
  // declare one lookupEntityKey, so there's no way to express "also load
  // this other map" without this). Omit when every lookup a config needs
  // already comes from its own fields' lookupEntityKey values.
  additionalLookupSources?: string[];

  // Fetches existing company rows and computes each one's normalized match
  // keys, for both dedup (this entity) and lookup resolution (entities
  // later in the chain that reference this one).
  fetchExisting: (companyId: string) => Promise<ExistingRecord[]>;

  // Candidate normalized keys for a freshly-mapped row, checked against the
  // ExistingRecord.keys fetched above, in priority order (e.g. email before
  // name for Clients — the stronger signal wins). Receives lookups too, so
  // an entity referencing another (e.g. Projects matching on name+client)
  // can resolve that reference before building its match key.
  matchKeysFor: (values: Record<string, any>, lookups: LookupMaps) => string[];

  // Per-field validation beyond plain "required" (format checks etc.).
  // Return null when valid.
  validateField?: (field: ImportFieldConfig, value: any) => string | null;

  // Like validateField, but for a check that genuinely can't be answered
  // without a lookup — e.g. Bills vs Field Payments both reading the same
  // uploaded Bill.csv, split by whether a vendor name resolves to a
  // Supplier or a Worker. plain validateField has no access to `lookups`
  // at all, which is why this is a separate hook rather than an extra
  // parameter bolted onto it.
  //
  // Deliberately does NOT follow validateField's required-vs-optional
  // gating (a non-required field's validateField error is downgraded to a
  // non-blocking warning with the field cleared — see processRawRow). A
  // non-null return here is ALWAYS a blocking error, regardless of
  // field.required, because this hook exists to answer "does this row
  // belong in this entity's destination table at all," not "is this
  // field's format acceptable" — those are orthogonal concerns, and a
  // routing/classification mismatch should never be quietly downgraded to
  // a warning just because the field itself happens to be optional (e.g.
  // Bills' supplier field is a plain non-blocking lookup for normal
  // resolution purposes, but a positive Worker match on it must still
  // exclude the whole row).
  validateFieldWithLookups?: (field: ImportFieldConfig, value: any, lookups: LookupMaps) => string | null;

  // General value-normalization hook for a field whose raw text needs
  // mapping to one of a fixed set of canonical values that won't match
  // verbatim what source systems actually export — e.g. Zoho's Projects
  // export uses "Active" for status; this app's CHECK constraint expects
  // exactly "active". Called for every non-blank mapped value on any field
  // this hook recognizes (check `fieldKey` internally, same pattern as
  // buildFallback below); return undefined to leave the raw value
  // untouched. `usedFallback: true` means the raw text didn't match
  // anything recognized and a default was substituted — flagged as a
  // non-blocking warning in Preview, same treatment as any other optional-
  // field format issue; it never blocks the row. `values` (the row's full
  // mapped-values-so-far) is passed for the rare case a remap decision
  // needs another field's value — e.g. Bills' "Overdue" Zoho status maps
  // to this app's "partial" or "approved" depending on whether
  // subtotal/total_amount/balance_due show a partial payment already
  // made. Optional third parameter — every existing remapValue
  // implementation that doesn't need it is unaffected.
  remapValue?: (fieldKey: string, rawValue: string, values: Record<string, any>) => { value: string; usedFallback: boolean } | undefined;

  // General robustness hook for a required field that's commonly blank in
  // real-world exports across accounting/CRM systems (not specific to any
  // one export) — e.g. expenses.description is NOT NULL in this app's
  // schema, but "Description" columns are routinely empty in practice.
  // Called only when the mapped value for `fieldKey` is blank; return a
  // reasonable value derived from the row's OTHER mapped values (e.g.
  // category + vendor), or null/undefined to leave it blank — in which case
  // the normal "required" validation error still applies, same as if this
  // hook didn't exist. Whenever a fallback is used, the wizard flags it on
  // the row rather than silently treating it as if it came from the file.
  buildFallback?: (fieldKey: string, values: Record<string, any>) => string | null | undefined;

  // Builds the final DB payload from a preview row's mapped values, resolving
  // any lookup fields against `lookups` and applying entity-specific
  // defaults (e.g. status defaults) the wizard shell has no business knowing.
  // companyId is always set explicitly on the payload here rather than
  // relied on any DB-side default (e.g. clients.company_id defaults to
  // current_company_id() per the live schema check, but that default isn't
  // confirmed to exist on every table) — matches how every other insert path
  // in this app already works (fetch company_id once, pass it explicitly).
  buildPayload: (values: Record<string, any>, lookups: LookupMaps, companyId: string) => Record<string, any>;

  // For a "lookup" field with createIfMissing: true — called (by the
  // wizard shell, during the real import step only, never during Preview,
  // which must stay side-effect-free) when resolution against the
  // existing lookup map fails. Creates a new row in the target table and
  // returns its {id, label}. The wizard shell caches in-flight creations
  // per field+normalized-value so concurrent rows in the same processing
  // chunk requesting the same brand-new value share one creation instead
  // of racing to insert it twice.
  createLookupTarget?: (fieldKey: string, rawValue: string, companyId: string) => Promise<{ id: string; label: string }>;

  // For an entity whose source export has multiple rows per logical
  // record (e.g. Zoho's Invoice.csv: one row per line item, invoice-level
  // fields repeated identically across each invoice's rows) — the FIELD
  // KEY (not header) whose value groups underlying parsed rows into one
  // logical record. When set, the wizard groups rows by this field's
  // mapped value before building Preview rows, and buildGroupHeaderPayload
  // / buildLineItemPayload / lineItemTable below are used instead of the
  // ordinary single-table buildPayload/table. Unset for every ordinary
  // (one-row-per-record) entity — Clients, Projects, Expenses never touch
  // any of this.
  groupByField?: string;

  // Builds the header (parent) row's DB payload from a group's header-
  // level values (the fields NOT marked isLineItemField) plus the
  // group's own line items (read-only here — useful if a header field
  // needs to be derived from them) and resolved lookups. Only called for
  // a grouped entity.
  buildGroupHeaderPayload?: (headerValues: Record<string, any>, lineItems: GroupedLineItem[], lookups: LookupMaps, companyId: string) => Record<string, any>;

  // Builds one line-item (child) row's DB payload, called once per VALID
  // line item (i.e. GroupedLineItem.errors is empty) at import time, once
  // the header's real id is known. lineNumber is 1-indexed position
  // within the group's valid line items.
  buildLineItemPayload?: (lineItemValues: Record<string, any>, lineNumber: number, headerId: string, headerValues: Record<string, any>, companyId: string) => Record<string, any>;

  // The child table a grouped entity's line items insert into — separate
  // from `table` above, which for a grouped entity is the HEADER table
  // (e.g. table: "client_invoices", lineItemTable: "client_invoice_line_items").
  lineItemTable?: string;

  // The column on lineItemTable that references the header row's id —
  // required whenever lineItemTable is set. Genuinely differs between
  // grouped entities: client_invoice_line_items uses invoice_id, but
  // supplier_invoice_line_items uses supplier_invoice_id (confirmed
  // against the live migrations — NOT the same name, despite the
  // superficially parallel table shapes). The shell's update-path
  // line-item cleanup (delete existing before re-inserting) needs this
  // column name explicitly — hardcoding "invoice_id" there was a real,
  // latent bug found while investigating the Bills three_way_match_status
  // failure: it happened to be correct for Invoices by coincidence, but
  // would have broken the very next "update an existing bill" retry.
  lineItemParentField?: string;

  // Optional, grouped entities only. The shell's UPDATE-payload builder
  // only ever overwrites a field whose config.fields entry actually got a
  // non-blank raw value THIS row — correct for direct 1:1 fields, but a
  // header payload can contain PURELY DERIVED keys with no config.fields
  // entry of their own at all (e.g. Invoices' tax_amount/tax_rate/
  // amount_paid, computed from subtotal/total_amount/balance_due). Without
  // this hook those keys would silently never be included in an update,
  // leaving stale figures on a re-imported record whose real inputs
  // changed. Called only on the update path, after buildGroupHeaderPayload
  // — receives that same header payload so the config can decide, using
  // its own knowledge of which raw fields a derived key actually depends
  // on, which extra keys are safe to overwrite given what this particular
  // row provided. Return {} to add nothing.
  buildGroupHeaderUpdateExtras?: (headerValues: Record<string, any>, headerPayload: Record<string, any>) => Record<string, any>;

  // Optional. For an entity whose rows can reference OTHER ROWS IN THE
  // SAME UPLOAD (e.g. Chart of Accounts' Parent Account — a lookup
  // against sibling rows being imported right now, not pre-existing DB
  // data resolvable via the normal LookupMaps built before Preview even
  // ran). Called once, after every row in this batch has already been
  // created/updated by the normal loop — receives the real ids just
  // produced (only for rows that succeeded; excluded/failed rows are
  // absent) plus every row's original mapped values (including whatever
  // raw self-referencing field the config chose not to resolve via
  // buildPayload), and does whatever follow-up work is needed — typically
  // one fresh query against the live table (which now includes this
  // batch) to resolve names to ids, then targeted UPDATE calls. Runs
  // regardless of upload order, and naturally also resolves a reference
  // to an account from an EARLIER import, not only ones in this same
  // batch, since it queries live data rather than only this run's rows.
  resolveSelfReferentialLinks?: (
    outcomes: { rowIndex: number; id: string }[],
    previewRows: PreviewRow[],
    companyId: string
  ) => Promise<void>;

  // Optional. Runs once, at Preview-build time, after every row/group has
  // already gone through the normal per-row pipeline (mapping, remap,
  // validation, dedup match) — receives the FULL set of PreviewRows built
  // so far, free to read and mutate them with real cross-row visibility
  // (something no other hook has: buildFallback only ever sees one row's
  // own values) before they're ever shown to the user or written to
  // React state. Built for Chart of Accounts' auto-generated Account
  // Code — assigning sequential codes per account type needs to know
  // about every other row's resolved type in the same batch, and about
  // what codes already exist live in the DB, neither of which a single-
  // row hook like buildFallback can see. Also receives lookups and
  // companyId so an implementation can query live data (e.g. the highest
  // existing code per type) the same way resolveSelfReferentialLinks
  // does for its own, later, post-insert pass. Must return the full rows
  // array (mutating in place and returning it is fine — this runs before
  // setPreviewRows ever makes them React state, so there's no
  // immutability concern yet).
  postProcessPreviewRows?: (
    rows: PreviewRow[],
    lookups: LookupMaps,
    companyId: string
  ) => Promise<PreviewRow[]>;
}

// A fetchable source of {id, label} records for lookup/create resolution.
// Every full EntityImportConfig already satisfies this (its own
// fetchExisting), so registering clients/projects here is free — but not
// every lookup target is itself a directly-importable entity (Expenses'
// category resolves against expense_categories, a simple flat list
// Veron never separately imports as its own wizard pass). See
// entityConfigs.ts's LOOKUP_SOURCES registry.
export interface LookupSource {
  fetchExisting: (companyId: string) => Promise<ExistingRecord[]>;
}
