﻿import { supabase } from "./supabase";

export interface ClientInvoice {
  id: string;
  company_id: string;
  project_id?: string | null;
  client_id?: string | null;
  contract_id?: string | null;
  invoice_number: string;
  invoice_date: string;
  due_date: string;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total_amount: number;
  amount_paid: number;
  balance_due: number;
  status: "draft" | "sent" | "partial" | "paid" | "overdue" | "cancelled";
  notes?: string | null;
  terms?: string | null;
  sent_date?: string | null;
  paid_date?: string | null;
  created_at?: string;
  updated_at?: string;
  created_by?: string | null;
  /** Banking step 3a: the books entry for this invoice, or why it isn't in the books yet. */
  gl_transaction_id?: string | null;
  ledger_note?: string | null;
}

export interface ClientInvoiceLineItem {
  id?: string;
  invoice_id: string;
  company_id: string;
  line_number: number;
  description: string;
  quantity: number;
  unit: string;
  rate: number;
  amount: number;
  notes?: string | null;
  // The name (e.g. a beneficiary) of the BOQ item this line was billed for; printed under the description when set.
  line_name?: string | null;
  boq_item_id?: string | null;
  milestone_id?: string | null;
  billing_item_id?: string | null;
  percent_complete?: number | null;
  previously_billed?: number | null;
  retainage_percent?: number | null;
  retainage_amount?: number | null;
  created_at?: string;
  updated_at?: string;
}

export interface ClientPayment {
  id: string;
  company_id: string;
  client_id?: string | null;
  invoice_id?: string | null;
  // The project an advance was received for (set only on advances; needs the client_payments.project_id column).
  project_id?: string | null;
  payment_number: string;
  payment_date: string;
  amount: number;
  payment_method: "check" | "ach" | "wire" | "credit_card" | "cash" | "other";
  reference_number?: string | null;
  notes?: string | null;
  created_at?: string;
  created_by?: string | null;
  /** Banking step 3b: "Deposited to" (a bank / cash account in the chart; empty = primary bank), the books entry, or why it isn't in the books. */
  deposit_account_id?: string | null;
  gl_transaction_id?: string | null;
  ledger_note?: string | null;
}

export interface SupplierInvoice {
  id: string;
  company_id: string;
  supplier_id?: string | null;
  project_id?: string | null;
  purchase_order_id?: string | null;
  invoice_number: string;
  invoice_date: string;
  due_date: string;
  subtotal: number;
  tax_amount: number;
  shipping_amount: number;
  total_amount: number;
  amount_paid: number;
  balance_due: number;
  status: "pending" | "approved" | "partial" | "paid" | "disputed";
  po_matched: boolean;
  receiving_matched: boolean;
  three_way_match_status?: "pending" | "matched" | "mismatch" | "no_po" | "no_receiving" | "overbilling" | null;
  notes?: string | null;
  approved_by?: string | null;
  approved_at?: string | null;
  created_at?: string;
  updated_at?: string;
  created_by?: string | null;
}

export interface SupplierInvoiceLineItem {
  id?: string;
  supplier_invoice_id: string;
  purchase_order_item_id?: string | null;
  chart_account_id?: string | null;
  line_no: number;
  item_name: string;
  description?: string | null;
  unit: string;
  quantity: number;
  unit_cost: number;
  total_amount: number;
  po_quantity?: number | null;
  po_unit_cost?: number | null;
  received_quantity?: number | null;
  match_status?: "matched" | "quantity_mismatch" | "price_mismatch" | "not_received" | "pending" | null;
  match_notes?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface ThreeWayMatchResult {
  match_status: "matched" | "mismatch" | "no_po" | "no_receiving" | "overbilling" | "error";
  match_details: {
    total_invoice_amount: number;
    total_po_amount: number;
    line_items: Array<{
      line_no: number;
      item_name: string;
      status: string;
      notes: string;
      invoice_qty: number;
      invoice_cost: number;
      po_qty?: number;
      po_cost?: number;
      received_qty?: number;
    }>;
  };
  can_auto_approve: boolean;
}

export interface Expense {
  id: string;
  company_id: string;
  project_id?: string | null;
  category_id?: string | null;
  // The expense account (Chart of Accounts) the expense is charged to; category_id is the older link.
  chart_account_id?: string | null;
  worker_id?: string | null;
  expense_date: string;
  vendor?: string | null;
  description: string;
  amount: number;
  payment_method?: string | null;
  receipt_url?: string | null;
  ocr_processed: boolean;
  ocr_confidence?: number | null;
  ocr_data?: any;
  status: "pending" | "approved" | "reimbursed" | "rejected";
  approved_by?: string | null;
  approved_at?: string | null;
  reimbursed_at?: string | null;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
  created_by?: string | null;
}

export interface BankAccount {
  id: string;
  company_id: string;
  account_name: string;
  account_type: "checking" | "savings" | "credit" | "line_of_credit";
  account_number_last_4?: string | null;
  bank_name?: string | null;
  current_balance: number;
  available_balance: number;
  is_primary: boolean;
  is_active: boolean;
  /** The Chart of Accounts account this bank account is in the books (migration 20260969). */
  chart_account_id?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface CashTransaction {
  id: string;
  company_id: string;
  bank_account_id?: string | null;
  transaction_date: string;
  transaction_type: "income" | "expense" | "transfer";
  category?: string | null;
  amount: number;
  balance_after?: number | null;
  description: string;
  reference_number?: string | null;
  client_payment_id?: string | null;
  supplier_payment_id?: string | null;
  expense_id?: string | null;
  payroll_entry_id?: string | null;
  created_at?: string;
  created_by?: string | null;
}

export async function fetchClientInvoices(companyId: string) {
  const { data, error } = await supabase
    .from("client_invoices")
    .select("*, clients(name), projects(name)")
    .eq("company_id", companyId)
    .order("invoice_date", { ascending: false });

  if (error) throw error;
  return data;
}

export async function createClientInvoice(invoice: Partial<ClientInvoice>) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from("client_invoices")
    .insert([
      {
        ...invoice,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data as ClientInvoice;
}

export async function updateClientInvoice(id: string, updates: Partial<ClientInvoice>) {
  const { data, error } = await supabase
    .from("client_invoices")
    .update(updates)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as ClientInvoice;
}

export async function fetchInvoiceLineItems(invoiceId: string) {
  const { data, error } = await supabase
    .from("client_invoice_line_items")
    .select("*")
    .eq("invoice_id", invoiceId)
    .order("line_number", { ascending: true });

  if (error) throw error;
  return data as ClientInvoiceLineItem[];
}

export async function createInvoiceLineItems(lineItems: Partial<ClientInvoiceLineItem>[]) {
  const { data, error } = await supabase
    .from("client_invoice_line_items")
    .insert(lineItems)
    .select();

  if (error) throw error;
  return data as ClientInvoiceLineItem[];
}

export async function updateInvoiceLineItem(id: string, updates: Partial<ClientInvoiceLineItem>) {
  const { data, error } = await supabase
    .from("client_invoice_line_items")
    .update(updates)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as ClientInvoiceLineItem;
}

export async function deleteInvoiceLineItem(id: string) {
  const { error } = await supabase
    .from("client_invoice_line_items")
    .delete()
    .eq("id", id);

  if (error) throw error;
}

export async function fetchInvoicePayments(invoiceId: string) {
  const { data, error } = await supabase
    .from("client_payments")
    .select("*")
    .eq("invoice_id", invoiceId)
    .order("payment_date", { ascending: false });

  if (error) throw error;
  return data as ClientPayment[];
}

export async function createClientPayment(payment: Partial<ClientPayment>) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from("client_payments")
    .insert([
      {
        ...payment,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (error) throw error;

  if (data) {
    let projectId: string | null = null;
    let clientName = "Client";

    if (data.invoice_id) {
      const { data: invoice } = await supabase
        .from("client_invoices")
        .select("project_id, clients(name)")
        .eq("id", data.invoice_id)
        .maybeSingle();

      if (invoice) {
        projectId = invoice.project_id;
        const clients = invoice.clients as any;
        clientName = clients?.name || clientName;
      }
    } else if (data.client_id) {
      const { data: client } = await supabase
        .from("clients")
        .select("name")
        .eq("id", data.client_id)
        .maybeSingle();

      if (client) {
        clientName = client.name;
      }
    }

    const isAdvance = !data.invoice_id && !!(data as any).project_id;
    const description = `${isAdvance ? "Advance payment" : "Payment"} from ${clientName}${data.reference_number ? ` (Ref: ${data.reference_number})` : ""}`;

    const { error: cashError } = await supabase
      .from("cash_transactions")
      .insert({
        company_id: data.company_id,
        transaction_date: data.payment_date,
        transaction_type: "income",
        category: "client_payment",
        amount: data.amount,
        description,
        reference_number: data.reference_number,
        client_payment_id: data.id,
        created_by: user?.id,
      });

    if (cashError) {
      console.error("Error creating cash transaction from client payment:", cashError);
    }
  }

  return data as ClientPayment;
}

// ---- Advance payments ------------------------------------------------------------------------------------------------
// An advance is money received from a client for a PROJECT before any invoice exists: a client_payments row with
// project_id set and invoice_id null, plus the usual cash_transactions income entry (createClientPayment makes it). It is
// applied to an invoice later by linking it (invoice_id) and calling updateInvoiceAfterPayment, which recalculates the
// invoice from its linked payments. Needs client_payments.project_id (a nullable column added by its own migration).
export const ADVANCE_NOT_ENABLED_MESSAGE =
  "Advance tracking isn't switched on yet: the database update that adds client_payments.project_id hasn't been applied.";

function isMissingProjectIdColumn(error: any): boolean {
  const msg = String(error?.message || error || "");
  return /project_id/i.test(msg) && /(does not exist|schema cache|could not find)/i.test(msg);
}

const ADVANCE_METHODS: ClientPayment["payment_method"][] = ["check", "ach", "wire", "credit_card", "cash", "other"];

export async function recordAdvancePayment(input: {
  companyId: string;
  projectId: string;
  clientId: string;
  amount: number;
  paymentDate: string;
  method: ClientPayment["payment_method"];
  referenceNumber?: string | null;
  notes?: string | null;
  depositAccountId?: string | null;
}): Promise<ClientPayment> {
  if (!input.companyId) throw new Error("Your company could not be determined.");
  if (!input.projectId) throw new Error("Choose a project.");
  if (!input.clientId) throw new Error("This project has no client set. Set the project's client first, then record the advance.");
  const amount = Math.round((Number(input.amount) + Number.EPSILON) * 100) / 100;
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an advance amount greater than zero.");
  if (amount >= 1e10) throw new Error("That amount is too large.");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.paymentDate || "")) throw new Error("Enter a valid payment date.");
  if (!ADVANCE_METHODS.includes(input.method)) throw new Error("Choose a payment method.");

  try {
    return await createClientPayment({
      company_id: input.companyId,
      client_id: input.clientId,
      project_id: input.projectId,
      invoice_id: null,
      payment_number: `ADV-${Date.now()}`,
      payment_date: input.paymentDate,
      amount,
      payment_method: input.method,
      reference_number: input.referenceNumber?.trim() || null,
      notes: input.notes?.trim() || null,
      deposit_account_id: input.depositAccountId || null,
    });
  } catch (e: any) {
    if (isMissingProjectIdColumn(e)) throw new Error(ADVANCE_NOT_ENABLED_MESSAGE);
    throw e;
  }
}

// Advances not yet applied to any invoice (project set, invoice not), oldest first; optionally for one company/project.
// Returns an empty list (rather than failing) while the project_id column doesn't exist yet.
export async function fetchUnappliedAdvances(opts: { companyId?: string; projectId?: string } = {}): Promise<ClientPayment[]> {
  let query = supabase
    .from("client_payments")
    .select("*")
    .is("invoice_id", null)
    .not("project_id", "is", null)
    .gt("amount", 0)   // an advance fully applied to invoices keeps its row at 0 (Banking step 3c)
    .order("payment_date", { ascending: true })
    .order("created_at", { ascending: true });
  if (opts.companyId) query = query.eq("company_id", opts.companyId);
  if (opts.projectId) query = query.eq("project_id", opts.projectId);
  const { data, error } = await query;
  if (error) {
    if (isMissingProjectIdColumn(error)) return [];
    throw error;
  }
  return (data || []) as ClientPayment[];
}

/** Banking step 3c: apply part (or all) of an unapplied advance to an issued invoice. What is left stays an advance.
 *  The database checks client / project / what is owed / what is left; the invoice's paid amount is then recalculated. */
export async function applyAdvanceToInvoice(advanceId: string, invoiceId: string, amount: number, date: string): Promise<number> {
  const { data, error } = await supabase.rpc("apply_advance", { p_advance: advanceId, p_invoice: invoiceId, p_amount: amount, p_date: date });
  if (error) throw new Error(error.message);
  await updateInvoiceAfterPayment(invoiceId);
  return Number((data as { left_on_advance: number }).left_on_advance);
}

export async function updateInvoiceAfterPayment(invoiceId: string) {
  // Fetch all payments for this invoice
  const payments = await fetchInvoicePayments(invoiceId);
  const totalPaid = payments.reduce((sum, p) => sum + Number(p.amount), 0);

  // Fetch invoice to get total
  const { data: invoice, error: invError } = await supabase
    .from("client_invoices")
    .select("total_amount, due_date")
    .eq("id", invoiceId)
    .single();

  if (invError) throw invError;

  const balanceDue = Number(invoice.total_amount) - totalPaid;
  const isOverdue = new Date(invoice.due_date) < new Date() && balanceDue > 0;

  let status: ClientInvoice["status"] = "draft";
  if (balanceDue <= 0) {
    status = "paid";
  } else if (totalPaid > 0) {
    status = "partial";
  } else if (isOverdue) {
    status = "overdue";
  } else {
    status = "sent";
  }

  // Update invoice
  const { data, error } = await supabase
    .from("client_invoices")
    .update({
      amount_paid: totalPaid,
      balance_due: balanceDue,
      status,
      paid_date: balanceDue <= 0 ? new Date().toISOString().split("T")[0] : null,
    })
    .eq("id", invoiceId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function fetchSupplierInvoices(companyId: string) {
  // suppliers' real name column is supplier_name, not name (confirmed
  // against the live migration) — the previous suppliers(name) embed
  // requested a nonexistent column, which PostgREST rejects outright.
  const { data, error } = await supabase
    .from("supplier_invoices")
    .select("*, suppliers(supplier_name), projects(name), purchase_orders(po_number)")
    .eq("company_id", companyId)
    .order("invoice_date", { ascending: false });

  if (error) throw error;
  return data;
}

export async function createSupplierInvoice(invoice: Partial<SupplierInvoice>) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from("supplier_invoices")
    .insert([
      {
        ...invoice,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data as SupplierInvoice;
}

export async function approveSupplierInvoice(id: string) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from("supplier_invoices")
    .update({
      status: "approved",
      approved_by: user?.id,
      approved_at: new Date().toISOString(),
    })
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function fetchExpenses(companyId: string) {
  const { data, error } = await supabase
    .from("expenses")
    .select("*, projects(name), workers(first_name, last_name), expense_categories(name)")
    .eq("company_id", companyId)
    .order("expense_date", { ascending: false });

  if (error) throw error;
  return data;
}

export async function createExpense(expense: Partial<Expense>) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from("expenses")
    .insert([
      {
        ...expense,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data as Expense;
}

export async function approveExpense(id: string, markAsPaid: boolean = false) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data: expense, error: fetchError } = await supabase
    .from("expenses")
    .select("*")
    .eq("id", id)
    .single();

  if (fetchError) throw fetchError;

  const updateData: any = {
    status: markAsPaid ? "reimbursed" : "approved",
    approved_by: user?.id,
    approved_at: new Date().toISOString(),
  };

  if (markAsPaid) {
    updateData.reimbursed_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from("expenses")
    .update(updateData)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;

  if (expense && expense.project_id) {
    const { data: category } = await supabase
      .from("expense_categories")
      .select("category_type")
      .eq("id", expense.category_id)
      .maybeSingle();

    const categoryType = category?.category_type || "other";
    let costType: "material" | "labor" | "equipment" | "other" = "other";

    if (categoryType === "materials") {
      costType = "material";
    } else if (categoryType === "labor") {
      costType = "labor";
    } else if (categoryType === "equipment") {
      costType = "equipment";
    }

    const { error: costError } = await supabase
      .from("project_costs")
      .insert({
        project_id: expense.project_id,
        cost_type: costType,
        source_id: id,
        source_type: "expense",
        description: expense.description,
        amount: expense.amount,
        cost_date: expense.expense_date,
        notes: `Auto-created from approved expense${expense.vendor ? ` - ${expense.vendor}` : ""}`,
      });

    if (costError) {
      console.error("Error creating project_cost from expense:", costError);
    }
  }

  if (markAsPaid) {
    const { data: worker } = expense.worker_id
      ? await supabase
          .from("workers")
          .select("first_name, last_name")
          .eq("id", expense.worker_id)
          .maybeSingle()
      : { data: null };

    const workerName = worker
      ? `${worker.first_name} ${worker.last_name}`
      : "Employee";

    const description = expense.worker_id
      ? `Expense reimbursement to ${workerName} - ${expense.description}`
      : `Expense payment - ${expense.description}${expense.vendor ? ` (${expense.vendor})` : ""}`;

    const { error: cashError } = await supabase
      .from("cash_transactions")
      .insert({
        company_id: expense.company_id,
        transaction_date: new Date().toISOString().split("T")[0],
        transaction_type: "expense",
        category: expense.worker_id ? "expense_reimbursement" : "expense_payment",
        amount: expense.amount,
        description,
        expense_id: id,
        created_by: user?.id,
      });

    if (cashError) {
      console.error("Error creating cash transaction from expense:", cashError);
    }
  }

  return data;
}

export async function reimburseExpense(id: string) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data: expense, error: fetchError } = await supabase
    .from("expenses")
    .select("*")
    .eq("id", id)
    .single();

  if (fetchError) throw fetchError;

  const { data, error } = await supabase
    .from("expenses")
    .update({
      status: "reimbursed",
      reimbursed_at: new Date().toISOString(),
    })
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;

  if (expense) {
    const { data: worker } = expense.worker_id
      ? await supabase
          .from("workers")
          .select("first_name, last_name")
          .eq("id", expense.worker_id)
          .maybeSingle()
      : { data: null };

    const workerName = worker
      ? `${worker.first_name} ${worker.last_name}`
      : "Employee";

    const description = expense.worker_id
      ? `Expense reimbursement to ${workerName} - ${expense.description}`
      : `Expense payment - ${expense.description}${expense.vendor ? ` (${expense.vendor})` : ""}`;

    const { error: cashError } = await supabase
      .from("cash_transactions")
      .insert({
        company_id: expense.company_id,
        transaction_date: new Date().toISOString().split("T")[0],
        transaction_type: "expense",
        category: expense.worker_id ? "expense_reimbursement" : "expense_payment",
        amount: expense.amount,
        description,
        expense_id: id,
        created_by: user?.id,
      });

    if (cashError) {
      console.error("Error creating cash transaction from expense:", cashError);
    }
  }

  return data;
}

export async function createBankAccount(account: {
  account_name: string;
  account_type: "checking" | "savings" | "credit" | "line_of_credit";
  bank_name?: string;
  account_number_last_4?: string;
  current_balance?: number;
  available_balance?: number;
  is_primary?: boolean;
  chart_account_id?: string | null;
}) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("user_profiles")
    .select("company_id")
    .eq("id", user?.id)
    .single();

  if (!profile?.company_id) {
    throw new Error("No company found for current user");
  }

  const { data, error } = await supabase
    .from("bank_accounts")
    .insert([
      {
        company_id: profile.company_id,
        account_name: account.account_name,
        account_type: account.account_type,
        bank_name: account.bank_name || null,
        account_number_last_4: account.account_number_last_4 || null,
        current_balance: account.current_balance ?? 0,
        available_balance: account.available_balance ?? account.current_balance ?? 0,
        is_primary: account.is_primary ?? false,
        is_active: true,
        // Empty = the database creates its account in the Chart of Accounts automatically.
        chart_account_id: account.chart_account_id || null,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data as BankAccount;
}

export async function updateBankAccount(id: string, updates: Partial<BankAccount>) {
  const { data, error } = await supabase
    .from("bank_accounts")
    .update(updates)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as BankAccount;
}

export async function deactivateBankAccount(id: string) {
  const { data, error } = await supabase
    .from("bank_accounts")
    .update({ is_active: false })
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as BankAccount;
}

/** The bank / cash (asset) and credit (liability) accounts in the chart, with their books balance, for linking bank accounts. */
export interface BankLedgerAccount { id: string; code: string; name: string; type: string; is_active: boolean | null; current_balance: number | null; subtype?: string | null; parent_id?: string | null }

export async function fetchBankLedgerAccounts(companyId: string): Promise<BankLedgerAccount[]> {
  const { data, error } = await supabase
    .from("chart_of_accounts")
    .select("id, code, name, type, is_active, current_balance, subtype, parent_id")
    .eq("company_id", companyId)
    .in("type", ["asset", "liability"])
    .order("code");
  if (error) throw error;
  return (data || []) as BankLedgerAccount[];
}

/** "Create in chart" for a bank account that isn't in the books yet. Returns the new account's id. */
export async function createChartAccountForBank(bankAccountId: string): Promise<string> {
  const { data, error } = await supabase.rpc("bank_account_create_chart_account", { p_bank: bankAccountId });
  if (error) throw error;
  return data as string;
}

export async function fetchBankAccounts(companyId: string) {
  const { data, error } = await supabase
    .from("bank_accounts")
    .select("*")
    .eq("company_id", companyId)
    .order("is_primary", { ascending: false });

  if (error) throw error;
  return data as BankAccount[];
}

export async function fetchCashTransactions(companyId: string, startDate?: string, endDate?: string) {
  let query = supabase
    .from("cash_transactions")
    .select("*, bank_accounts(account_name)")
    .eq("company_id", companyId);

  if (startDate) query = query.gte("transaction_date", startDate);
  if (endDate) query = query.lte("transaction_date", endDate);

  const { data, error } = await query.order("transaction_date", { ascending: false });

  if (error) throw error;
  return data;
}

export async function getCashFlowSummary(companyId: string, startDate: string, endDate: string) {
  const { data, error } = await supabase
    .from("cash_transactions")
    .select("transaction_type, amount")
    .eq("company_id", companyId)
    .gte("transaction_date", startDate)
    .lte("transaction_date", endDate);

  if (error) throw error;

  const income = data
    ?.filter((t) => t.transaction_type === "income")
    .reduce((sum, t) => sum + Number(t.amount), 0) || 0;

  const expenses = data
    ?.filter((t) => t.transaction_type === "expense")
    .reduce((sum, t) => sum + Number(t.amount), 0) || 0;

  return {
    income,
    expenses,
    netCashFlow: income - expenses,
  };
}

export async function getARSummary(companyId: string) {
  const { data, error } = await supabase
    .from("client_invoices")
    .select("status, balance_due")
    .eq("company_id", companyId)
    .neq("status", "cancelled");

  if (error) throw error;

  const totalOutstanding = data?.reduce((sum, inv) => sum + Number(inv.balance_due), 0) || 0;
  const overdue = data?.filter((inv) => inv.status === "overdue").length || 0;

  return {
    totalOutstanding,
    overdueCount: overdue,
  };
}

export async function getAPSummary(companyId: string) {
  const { data, error } = await supabase
    .from("supplier_invoices")
    .select("status, balance_due")
    .eq("company_id", companyId)
    .in("status", ["pending", "approved", "partial"]);

  if (error) throw error;

  const totalDue = data?.reduce((sum, inv) => sum + Number(inv.balance_due), 0) || 0;
  const pendingApproval = data?.filter((inv) => inv.status === "pending").length || 0;

  return {
    totalDue,
    pendingApprovalCount: pendingApproval,
  };
}

export interface SupplierPayment {
  id: string;
  company_id: string;
  supplier_id?: string | null;
  invoice_id?: string | null;
  payment_number: string;
  payment_date: string;
  amount: number;
  payment_method: "check" | "ach" | "wire" | "credit_card" | "cash" | "other";
  check_number?: string | null;
  reference_number?: string | null;
  notes?: string | null;
  created_at?: string;
  created_by?: string | null;
}

export interface ProjectFinanceSummary {
  project_id: string;
  company_id: string;
  project_name: string;
  project_status: string;
  budget_total: number;
  committed_total: number;
  actual_total: number;
  billed_total: number;
  received_total: number;
  ar_outstanding: number;
  ap_outstanding: number;
  budget_variance: number;
  committed_variance: number;
  projected_margin: number;
  margin_percent: number;
  cost_completion_percent: number;
  billing_completion_percent: number;
  collection_percent: number;
  created_at?: string;
  updated_at?: string;
}

export async function fetchProjectFinanceSummary(projectId: string) {
  const { data, error } = await supabase
    .from("v_project_finance_summary")
    .select("*")
    .eq("project_id", projectId)
    .maybeSingle();

  if (error) throw error;
  return data as ProjectFinanceSummary | null;
}

export async function fetchAllProjectsFinanceSummary(companyId: string) {
  // v_project_finance_summary has no company_id column (confirmed live via
  // information_schema.columns — see DashboardPage.tsx/ReportsPage.tsx for
  // the same fix) — filter by project_id instead, scoped to this company's
  // own project ids.
  const { data: projects, error: projError } = await supabase
    .from("projects")
    .select("id")
    .eq("company_id", companyId);
  if (projError) throw projError;
  const projectIds = (projects || []).map(p => p.id);
  if (projectIds.length === 0) return [];

  const { data, error } = await supabase
    .from("v_project_finance_summary")
    .select("*")
    .in("project_id", projectIds)
    .order("project_name", { ascending: true });

  if (error) throw error;
  return data as ProjectFinanceSummary[];
}

export async function fetchSupplierInvoiceLineItems(invoiceId: string) {
  const { data, error } = await supabase
    .from("supplier_invoice_line_items")
    .select("*")
    .eq("supplier_invoice_id", invoiceId)
    .order("line_no", { ascending: true });

  if (error) throw error;
  return data as SupplierInvoiceLineItem[];
}

export async function createSupplierInvoiceLineItem(lineItem: Partial<SupplierInvoiceLineItem>) {
  const { data, error } = await supabase
    .from("supplier_invoice_line_items")
    .insert([lineItem])
    .select()
    .single();

  if (error) throw error;
  return data as SupplierInvoiceLineItem;
}

export async function updateSupplierInvoiceLineItem(id: string, updates: Partial<SupplierInvoiceLineItem>) {
  const { data, error } = await supabase
    .from("supplier_invoice_line_items")
    .update(updates)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as SupplierInvoiceLineItem;
}

export async function deleteSupplierInvoiceLineItem(id: string) {
  const { error } = await supabase
    .from("supplier_invoice_line_items")
    .delete()
    .eq("id", id);

  if (error) throw error;
}

export async function performThreeWayMatch(invoiceId: string): Promise<ThreeWayMatchResult> {
  const { data, error } = await supabase.rpc("perform_three_way_match", {
    p_supplier_invoice_id: invoiceId,
  });

  if (error) throw error;

  if (!data || data.length === 0) {
    throw new Error("No match result returned");
  }

  return {
    match_status: data[0].match_status,
    match_details: data[0].match_details,
    can_auto_approve: data[0].can_auto_approve,
  };
}

export async function autoApproveMatchedInvoice(invoiceId: string): Promise<boolean> {
  const { data, error } = await supabase.rpc("auto_approve_matched_invoice", {
    p_supplier_invoice_id: invoiceId,
  });

  if (error) throw error;
  return data as boolean;
}

export interface ContractBillingItem {
  id?: string;
  company_id: string;
  contract_id: string;
  boq_item_id?: string | null;
  line_no: number;
  description: string;
  unit: string;
  contract_quantity: number;
  contract_rate: number;
  contract_amount: number;
  percent_complete: number;
  quantity_completed: number;
  previously_billed_amount: number;
  previously_billed_quantity: number;
  retainage_percent: number;
  total_retainage_held: number;
  current_amount_due: number;
  remaining_contract_balance: number;
  is_active: boolean;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface ContractMilestone {
  id?: string;
  company_id: string;
  contract_id: string;
  milestone_no: number;
  milestone_name: string;
  description?: string | null;
  milestone_amount: number;
  percent_complete: number;
  is_completed: boolean;
  scheduled_date?: string | null;
  completion_date?: string | null;
  billed_amount: number;
  retainage_percent: number;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface ContractBillingCalculation {
  billing_item_id: string;
  boq_item_id: string | null;
  line_no: number;
  description: string;
  unit: string;
  contract_quantity: number;
  contract_rate: number;
  contract_amount: number;
  percent_complete: number;
  quantity_completed: number;
  previously_billed_amount: number;
  current_billing_quantity: number;
  current_billing_amount: number;
  retainage_percent: number;
  retainage_amount: number;
  net_amount_due: number;
  remaining_balance: number;
}

export interface ContractBillingSummary {
  contract_amount: number;
  total_billed_to_date: number;
  total_retainage_held: number;
  total_paid: number;
  total_outstanding: number;
  remaining_contract_balance: number;
  percent_billed: number;
  percent_complete: number;
}

export async function fetchContractBillingItems(contractId: string) {
  const { data, error } = await supabase
    .from("contract_billing_items")
    .select("*")
    .eq("contract_id", contractId)
    .eq("is_active", true)
    .order("line_no", { ascending: true });

  if (error) throw error;
  return data as ContractBillingItem[];
}

export async function fetchContractMilestones(contractId: string) {
  const { data, error } = await supabase
    .from("contract_milestones")
    .select("*")
    .eq("contract_id", contractId)
    .order("milestone_no", { ascending: true });

  if (error) throw error;
  return data as ContractMilestone[];
}

export async function createContractBillingItem(item: Partial<ContractBillingItem>) {
  const { data, error } = await supabase
    .from("contract_billing_items")
    .insert([item])
    .select()
    .single();

  if (error) throw error;
  return data as ContractBillingItem;
}

export async function updateContractBillingItem(id: string, updates: Partial<ContractBillingItem>) {
  const { data, error } = await supabase
    .from("contract_billing_items")
    .update(updates)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as ContractBillingItem;
}

export async function createContractMilestone(milestone: Partial<ContractMilestone>) {
  const { data, error } = await supabase
    .from("contract_milestones")
    .insert([milestone])
    .select()
    .single();

  if (error) throw error;
  return data as ContractMilestone;
}

export async function updateContractMilestone(id: string, updates: Partial<ContractMilestone>) {
  const { data, error } = await supabase
    .from("contract_milestones")
    .update(updates)
    .eq("id", id)
    .select()
    .single();

  if (error) throw error;
  return data as ContractMilestone;
}

export async function calculateContractBilling(
  contractId: string,
  billingDate?: string
): Promise<ContractBillingCalculation[]> {
  const { data, error } = await supabase.rpc("calculate_contract_billing", {
    p_contract_id: contractId,
    p_billing_date: billingDate || new Date().toISOString().split("T")[0],
  });

  if (error) throw error;
  return (data || []) as ContractBillingCalculation[];
}

export async function getContractBillingSummary(contractId: string): Promise<ContractBillingSummary> {
  const { data, error } = await supabase.rpc("get_contract_billing_summary", {
    p_contract_id: contractId,
  });

  if (error) throw error;

  if (!data || data.length === 0) {
    return {
      contract_amount: 0,
      total_billed_to_date: 0,
      total_retainage_held: 0,
      total_paid: 0,
      total_outstanding: 0,
      remaining_contract_balance: 0,
      percent_billed: 0,
      percent_complete: 0,
    };
  }

  return data[0] as ContractBillingSummary;
}

export async function syncBOQToBillingItems(contractId: string): Promise<number> {
  const { data, error } = await supabase.rpc("sync_boq_to_billing_items", {
    p_contract_id: contractId,
  });

  if (error) throw error;
  return data as number;
}

export async function updateBillingItemAfterInvoice(
  billingItemId: string,
  billedAmount: number,
  billedQuantity: number,
  retainageAmount: number
): Promise<void> {
  const { error } = await supabase.rpc("update_billing_item_after_invoice", {
    p_billing_item_id: billingItemId,
    p_billed_amount: billedAmount,
    p_billed_quantity: billedQuantity,
    p_retainage_amount: retainageAmount,
  });

  if (error) throw error;
}

export async function createSupplierPayment(payment: Partial<SupplierPayment>) {
  const { data: { user } } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from("supplier_payments")
    .insert([
      {
        ...payment,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (error) throw error;

  if (data) {
    let projectId: string | null = null;
    let supplierName = "Supplier";

    if (data.invoice_id) {
      const { data: invoice } = await supabase
        .from("supplier_invoices")
        .select("project_id, suppliers(name)")
        .eq("id", data.invoice_id)
        .maybeSingle();

      if (invoice) {
        projectId = invoice.project_id;
        const suppliers = invoice.suppliers as any;
        supplierName = suppliers?.name || supplierName;
      }
    } else if (data.supplier_id) {
      const { data: supplier } = await supabase
        .from("suppliers")
        .select("name")
        .eq("id", data.supplier_id)
        .maybeSingle();

      if (supplier) {
        supplierName = supplier.name;
      }
    }

    const refInfo = data.check_number ? `Check #${data.check_number}` : data.reference_number ? `Ref: ${data.reference_number}` : "";
    const description = `Payment to ${supplierName}${refInfo ? ` (${refInfo})` : ""}`;

    const { error: cashError } = await supabase
      .from("cash_transactions")
      .insert({
        company_id: data.company_id,
        transaction_date: data.payment_date,
        transaction_type: "expense",
        category: "supplier_payment",
        amount: data.amount,
        description,
        reference_number: data.reference_number || data.check_number,
        supplier_payment_id: data.id,
        created_by: user?.id,
      });

    if (cashError) {
      console.error("Error creating cash transaction from supplier payment:", cashError);
    }

    if (data.invoice_id) {
      const { data: invoice, error: invError } = await supabase
        .from("supplier_invoices")
        .select("total_amount")
        .eq("id", data.invoice_id)
        .single();

      if (!invError && invoice) {
        const { data: allPayments } = await supabase
          .from("supplier_payments")
          .select("amount")
          .eq("invoice_id", data.invoice_id);

        const totalPaid = allPayments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
        const balanceDue = Number(invoice.total_amount) - totalPaid;

        let status: SupplierInvoice["status"] = "approved";
        if (balanceDue <= 0) {
          status = "paid";
        } else if (totalPaid > 0) {
          status = "partial";
        }

        await supabase
          .from("supplier_invoices")
          .update({
            amount_paid: totalPaid,
            balance_due: balanceDue,
            status,
          })
          .eq("id", data.invoice_id);
      }
    }
  }

  return data as SupplierPayment;
}
export async function transferFunds(params: {
  fromAccountId: string;
  toAccountId: string;
  amount: number;
  description?: string;
  date?: string;
}) {
  if (params.fromAccountId === params.toAccountId) {
    throw new Error("Cannot transfer to the same account");
  }
  if (params.amount <= 0) {
    throw new Error("Transfer amount must be greater than zero");
  }

  const { data: { user } } = await supabase.auth.getUser();

  const [{ data: fromAccount, error: fromErr }, { data: toAccount, error: toErr }] = await Promise.all([
    supabase.from("bank_accounts").select("*").eq("id", params.fromAccountId).single(),
    supabase.from("bank_accounts").select("*").eq("id", params.toAccountId).single(),
  ]);

  if (fromErr || !fromAccount) throw new Error("Source account not found");
  if (toErr || !toAccount) throw new Error("Destination account not found");

  const txDate = params.date || new Date().toISOString().split("T")[0];
  const desc = params.description || `Transfer to ${toAccount.account_name}`;
  const descIn = params.description || `Transfer from ${fromAccount.account_name}`;
  const transferRef = `XFER-${Date.now()}`;

  const newFromBalance = Number(fromAccount.current_balance) - params.amount;
  const newToBalance = Number(toAccount.current_balance) + params.amount;

  const { data: outTxn, error: outErr } = await supabase
    .from("cash_transactions")
    .insert([
      {
        company_id: fromAccount.company_id,
        bank_account_id: params.fromAccountId,
        transaction_date: txDate,
        transaction_type: "transfer",
        category: "Transfer Out",
        amount: -Math.abs(params.amount),
        balance_after: newFromBalance,
        description: desc,
        reference_number: transferRef,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (outErr) throw outErr;

  const { data: inTxn, error: inErr } = await supabase
    .from("cash_transactions")
    .insert([
      {
        company_id: toAccount.company_id,
        bank_account_id: params.toAccountId,
        transaction_date: txDate,
        transaction_type: "transfer",
        category: "Transfer In",
        amount: Math.abs(params.amount),
        balance_after: newToBalance,
        description: descIn,
        reference_number: transferRef,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (inErr) {
    await supabase.from("cash_transactions").delete().eq("id", outTxn.id);
    throw inErr;
  }

  const [{ error: updFromErr }, { error: updToErr }] = await Promise.all([
    supabase.from("bank_accounts").update({ current_balance: newFromBalance, available_balance: newFromBalance }).eq("id", params.fromAccountId),
    supabase.from("bank_accounts").update({ current_balance: newToBalance, available_balance: newToBalance }).eq("id", params.toAccountId),
  ]);

  if (updFromErr || updToErr) {
    throw new Error("Transfer recorded but balance update failed - check account balances manually");
  }

  return { outTxn, inTxn };
}

export async function withdrawFunds(params: {
  accountId: string;
  amount: number;
  reason: string;
  category?: string;
  date?: string;
}) {
  if (params.amount <= 0) {
    throw new Error("Withdrawal amount must be greater than zero");
  }

  const { data: { user } } = await supabase.auth.getUser();

  const { data: account, error: accErr } = await supabase
    .from("bank_accounts")
    .select("*")
    .eq("id", params.accountId)
    .single();

  if (accErr || !account) throw new Error("Account not found");

  const txDate = params.date || new Date().toISOString().split("T")[0];
  const newBalance = Number(account.current_balance) - params.amount;

  const { data: txn, error: txnErr } = await supabase
    .from("cash_transactions")
    .insert([
      {
        company_id: account.company_id,
        bank_account_id: params.accountId,
        transaction_date: txDate,
        transaction_type: "expense",
        category: params.category || "Withdrawal",
        amount: -Math.abs(params.amount),
        balance_after: newBalance,
        description: params.reason,
        created_by: user?.id,
      },
    ])
    .select()
    .single();

  if (txnErr) throw txnErr;

  const { error: updErr } = await supabase
    .from("bank_accounts")
    .update({ current_balance: newBalance, available_balance: newBalance })
    .eq("id", params.accountId);

  if (updErr) {
    throw new Error("Withdrawal recorded but balance update failed - check account balance manually");
  }

  return txn;
}

/** Money received on client invoices since a date (part payments and advances used on invoices included). */
export async function fetchPaidOnInvoicesSince(companyId: string, since: string): Promise<number> {
  const { data, error } = await supabase.from("client_payments").select("amount")
    .eq("company_id", companyId).not("invoice_id", "is", null).gte("payment_date", since);
  if (error) throw error;
  return ((data || []) as { amount: number | null }[]).reduce((t, p) => t + Number(p.amount || 0), 0);
}

/** Cancel a client advance (director or supervisor only; refused while part of it is used on an invoice). Migration 20260984. */
export async function cancelClientAdvance(advanceId: string, reason: string): Promise<void> {
  const { error } = await supabase.rpc("cancel_client_advance", { p_id: advanceId, p_reason: reason.trim() });
  if (error) throw new Error(error.message);
}
