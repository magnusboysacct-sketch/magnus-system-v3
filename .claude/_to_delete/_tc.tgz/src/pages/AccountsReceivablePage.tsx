﻿import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { companyDisplayName } from "../lib/companyName";
import { FileText, Plus, DollarSign, CircleAlert as AlertCircle, CircleCheck as CheckCircle, X, Trash2, Eye, Bell, MessageCircle, Mail, Save, Pencil, Printer } from "lucide-react";
import {
  fetchClientInvoices,
  createClientInvoice,
  fetchInvoiceLineItems,
  createInvoiceLineItems,
  deleteInvoiceLineItem,
  fetchInvoicePayments,
  createClientPayment,
  updateInvoiceAfterPayment,
  updateClientInvoice,
  recordAdvancePayment,
  fetchUnappliedAdvances,
  applyAdvanceToInvoice
} from "../lib/finance";
import type { ClientInvoice, ClientInvoiceLineItem, ClientPayment } from "../lib/finance";
import { fetchMoneyAccounts, type MoneyAccount } from "../lib/banking";
import { cancelClientAdvance, fetchPaidOnInvoicesSince } from "../lib/finance";

// Banking step 3b: which bank / cash account a client payment went into. Empty = the primary bank account
// (or Undeposited Funds when there is none), chosen by the database, so every way of recording a payment is in the books.
function DepositedToSelect({ value, onChange, accounts }: { value: string; onChange: (v: string) => void; accounts: MoneyAccount[] }) {
  const banks = accounts.filter(a => a.type === "asset" && a.isBank);
  const other = accounts.filter(a => a.type === "asset" && !a.isBank);
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Deposited to</label>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100">
        <option value="">My primary bank account (automatic)</option>
        {banks.length > 0 && <optgroup label="Bank accounts">{banks.map(a => <option key={a.id} value={a.id}>{a.code} - {a.name}</option>)}</optgroup>}
        {other.length > 0 && <optgroup label="Cash, petty cash and funds">{other.map(a => <option key={a.id} value={a.id}>{a.code} - {a.name}</option>)}</optgroup>}
      </select>
      <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">Where the money went. It goes into your books straight away.</p>
    </div>
  );
}
import ContractProgressBilling from "../components/ContractProgressBilling";
import { useFinanceAccess } from "../hooks/useFinanceAccess";
import { FinanceAccessDenied } from "../components/FinanceAccessDenied";
import { useProjectContext } from "../context/ProjectContext";
import { Send } from "lucide-react";
import SendToClientModal from "../components/SendToClientModal";
import MarkAsSentModal from "../components/MarkAsSentModal";
import { canMarkSent, canUndoMarkedSent, isMarkedSent, markedSentDetails, markedSentLine } from "../lib/invoiceMarkSent";
import { undoMarkedSent } from "../lib/invoiceMarkSentApi";
import { printInvoiceFresh } from "../components/InvoiceDocument";
import { isSharedNow, formatJamaicaDateTime, shareViaLabel } from "../lib/portalShare";
import { SeenBadge, SeenDetail } from "../components/PortalSeen";
import { useItemViews } from "../lib/useItemViews";
import { copyToClipboard, createReceiptLink, errorMessage, findReceiptLink, openEmail, openWhatsApp, receiptUrl, revokeReceiptLink, withReceiptLink } from "../lib/receiptLinks";

const fmtAdvance = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "JMD", minimumFractionDigits: 2 }).format(n);

interface LineItem {
  id?: string;
  description: string;
  quantity: string;
  unit: string;
  rate: string;
  amount: number;
}

export default function AccountsReceivablePage() {
  const financeAccess = useFinanceAccess();
  const [searchParams, setSearchParams] = useSearchParams();
  const { userRole } = useProjectContext();
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "draft" | "sent" | "partial" | "overdue" | "paid">("all");
  const [showModal, setShowModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [printingInvoice, setPrintingInvoice] = useState(false);
  const [invoiceLineItems, setInvoiceLineItems] = useState<ClientInvoiceLineItem[]>([]);
  const [invoicePayments, setInvoicePayments] = useState<ClientPayment[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [companySettings, setCompanySettings] = useState<any>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [showThankYouModal, setShowThankYouModal] = useState(false);
  const [thankYouData, setThankYouData] = useState<{client: any; amount: number; invoiceNumber: string; paymentId?: string} | null>(null);
  const [receiptLinkNote, setReceiptLinkNote] = useState("");
  const [reminderForm, setReminderForm] = useState({ reminder_enabled: true, reminder_days_before: 3, reminder_repeat_days: 7 });
  const [savingReminder, setSavingReminder] = useState(false);
  const [reminderSent, setReminderSent] = useState(false);
  const [projects, setProjects] = useState<any[]>([]);
  const [contracts, setContracts] = useState<any[]>([]);
  const [companyId, setCompanyId] = useState<string>("");
  const [paidYtd, setPaidYtd] = useState(0);
  useEffect(() => {
    if (!companyId) return;
    let alive = true;
    const start = `${new Date().getFullYear()}-01-01`;
    fetchPaidOnInvoicesSince(companyId, start).then((n) => { if (alive) setPaidYtd(n); }).catch(() => undefined);
    return () => { alive = false; };
  }, [companyId, invoices]);
  const [showProgressBilling, setShowProgressBilling] = useState(false);
  const [selectedContract, setSelectedContract] = useState<any>(null);
  const [showSendModal, setShowSendModal] = useState(false);
  const [markTarget, setMarkTarget] = useState<{ invoice: any; clientName: string | null; clientHasPortal: boolean } | null>(null);
  const [sendClient, setSendClient] = useState<any>(null);
  // Advance payments: money received for a project before any invoice exists (client_payments with project_id, no invoice_id).
  const [advances, setAdvances] = useState<ClientPayment[]>([]);
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [savingAdvance, setSavingAdvance] = useState(false);
  const [advanceError, setAdvanceError] = useState("");
  const [advanceForm, setAdvanceForm] = useState({
    project_id: "",
    amount: "",
    payment_date: new Date().toISOString().split("T")[0],
    payment_method: "check" as ClientPayment["payment_method"],
    reference_number: "",
    notes: "",
    deposit_account_id: "",
  });
  const [moneyAccounts, setMoneyAccounts] = useState<MoneyAccount[]>([]);
  const [savingPayment, setSavingPayment] = useState(false);
  // Banking step 3c: "Apply to invoice" on an unapplied advance.
  const [applying, setApplying] = useState<ClientPayment | null>(null);
  const [applyForm, setApplyForm] = useState({ invoiceId: "", amount: "", date: new Date().toISOString().split("T")[0] });
  const [applyBusy, setApplyBusy] = useState(false);
  const [applyError, setApplyError] = useState("");
  const [paymentError, setPaymentError] = useState("");

  const [formData, setFormData] = useState({
    invoice_number: "",
    client_id: "",
    project_id: "",
    invoice_date: new Date().toISOString().split("T")[0],
    due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    tax_rate: "0",
    notes: "",
    terms: "Net 30",
  });

  const [lineItems, setLineItems] = useState<LineItem[]>([
    { description: "", quantity: "1", unit: "ea", rate: "", amount: 0 },
  ]);

  const [paymentData, setPaymentData] = useState({
    payment_date: new Date().toISOString().split("T")[0],
    amount: "",
    payment_method: "check" as const,
    reference_number: "",
    notes: "",
    deposit_account_id: "",
  });

  const [editingInvoice, setEditingInvoice] = useState<ClientInvoice | null>(null);
  const [editForm, setEditForm] = useState({
    invoice_date: "",
    due_date: "",
    tax_rate: 0,
    notes: "",
    terms: "",
    status: "",
    project_id: "",
  });

  useEffect(() => {
    loadInvoices();
    loadClientsAndProjects();
    loadContracts();
  }, []);

  // Arriving with ?invoice=<id> (e.g. from "Generate Invoice" on the BOQ page) opens that invoice's details once the list
  // has loaded, then drops the parameter so a refresh doesn't reopen it.
  const deepLinkInvoiceId = searchParams.get("invoice");
  useEffect(() => {
    if (!deepLinkInvoiceId || loading) return;
    const inv = invoices.find(i => i.id === deepLinkInvoiceId);
    if (inv) openDetailModal(inv);
    setSearchParams({}, { replace: true });
  }, [deepLinkInvoiceId, loading, invoices]);

  useEffect(() => {
    if (companyId) fetchMoneyAccounts().then(setMoneyAccounts).catch(() => setMoneyAccounts([]));
  }, [companyId]);

  useEffect(() => {
    if (companyId) loadAdvances();
  }, [companyId]);

  // "Opened by client" data for the shared invoices, in one batched query.
  const invoiceViews = useItemViews(
    "invoice",
    invoices.filter(i => i.status !== "cancelled" && isSharedNow(i.shared_at, i.withdrawn_at)).map(i => i.id)
  );

  if (financeAccess.loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white dark:bg-slate-950">
        <div className="text-slate-500 dark:text-slate-400">Loading...</div>
      </div>
    );
  }

  if (!financeAccess.canViewCompanyReports) {
    return <FinanceAccessDenied />;
  }

  async function loadInvoices() {
    try {
      const { supabase } = await import("../lib/supabase");
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from("user_profiles")
        .select("company_id")
        .eq("id", user.id)
        .single();

      if (!profile?.company_id) return;

      setCompanyId(profile.company_id);
      const data = await fetchClientInvoices(profile.company_id);
      setInvoices(data);
    } catch (error) {
      console.error("Error loading invoices:", error);
    } finally {
      setLoading(false);
    }
  }

  async function loadContracts() {
    try {
      const { supabase } = await import("../lib/supabase");
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from("user_profiles")
        .select("company_id")
        .eq("id", user.id)
        .single();

      if (!profile?.company_id) return;

      const { data } = await supabase
        .from("client_contracts")
        .select("*, projects(name), clients(name)")
        .eq("company_id", profile.company_id)
        .eq("status", "active")
        .order("created_at", { ascending: false });

      if (data) setContracts(data);
    } catch (error) {
      console.error("Error loading contracts:", error);
    }
  }

  async function loadClientsAndProjects() {
    try {
      const { supabase } = await import("../lib/supabase");
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from("user_profiles")
        .select("company_id")
        .eq("id", user.id)
        .single();

      if (!profile?.company_id) return;

      const [clientsData, projectsData, companyData] = await Promise.all([
        supabase.from("clients").select("id, name, contact_name, email, phone").eq("company_id", profile.company_id).order("name"),
        supabase.from("projects").select("id, name, client_id").eq("company_id", profile.company_id).order("name"),
        supabase.from("company_settings").select("company_name,logo_url,phone,email,payment_notifications_enabled").eq("company_id", profile.company_id).maybeSingle(),
      ]);

      if (clientsData.data) setClients(clientsData.data);
      if (companyData.data) { setCompanySettings(companyData.data); setNotificationsEnabled(companyData.data.payment_notifications_enabled !== false); }
      if (projectsData.data) setProjects(projectsData.data);
    } catch (error) {
      console.error("Error loading clients/projects:", error);
    }
  }

  function openCreateModal() {
    setFormData({
      invoice_number: `INV-${Date.now()}`,
      client_id: "",
      project_id: "",
      invoice_date: new Date().toISOString().split("T")[0],
      due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      tax_rate: "0",
      notes: "",
      terms: "Net 30",
    });
    setLineItems([{ description: "", quantity: "1", unit: "ea", rate: "", amount: 0 }]);
    setShowModal(true);
  }

  function addLineItem() {
    setLineItems([...lineItems, { description: "", quantity: "1", unit: "ea", rate: "", amount: 0 }]);
  }

  function removeLineItem(index: number) {
    setLineItems(lineItems.filter((_, i) => i !== index));
  }

  function updateLineItem(index: number, field: keyof LineItem, value: string) {
    const updated = [...lineItems];
    updated[index] = { ...updated[index], [field]: value };

    if (field === "quantity" || field === "rate") {
      const qty = parseFloat(updated[index].quantity) || 0;
      const rate = parseFloat(updated[index].rate) || 0;
      updated[index].amount = qty * rate;
    }

    setLineItems(updated);
  }

  function calculateTotals() {
    const subtotal = lineItems.reduce((sum, item) => sum + item.amount, 0);
    const taxRate = parseFloat(formData.tax_rate) || 0;
    const taxAmount = subtotal * (taxRate / 100);
    const total = subtotal + taxAmount;

    return { subtotal, taxAmount, total };
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    try {
      if (!companyId) return;

      const { subtotal, taxAmount, total } = calculateTotals();

      const invoice = await createClientInvoice({
        company_id: companyId,
        client_id: formData.client_id || null,
        project_id: formData.project_id || null,
        invoice_number: formData.invoice_number,
        invoice_date: formData.invoice_date,
        due_date: formData.due_date,
        subtotal: subtotal,
        tax_rate: parseFloat(formData.tax_rate),
        tax_amount: taxAmount,
        total_amount: total,
        balance_due: total,
        amount_paid: 0,
        status: "draft",
        notes: formData.notes,
        terms: formData.terms,
      });

      // Create line items
      const lineItemsToCreate = lineItems
        .filter(item => item.description && item.rate)
        .map((item, index) => ({
          invoice_id: invoice.id,
          company_id: companyId,
          line_number: index + 1,
          description: item.description,
          quantity: parseFloat(item.quantity),
          unit: item.unit,
          rate: parseFloat(item.rate),
          amount: item.amount,
        }));

      if (lineItemsToCreate.length > 0) {
        await createInvoiceLineItems(lineItemsToCreate);
      }

      setShowModal(false);
      loadInvoices();
    } catch (error) {
      console.error("Error creating invoice:", error);
      alert("Failed to create invoice");
    }
  }

  async function openDetailModal(invoice: any) {
    try {
      setSelectedInvoice(invoice);
      setReminderForm({ reminder_enabled: invoice.reminder_enabled !== false, reminder_days_before: invoice.reminder_days_before ?? 3, reminder_repeat_days: invoice.reminder_repeat_days ?? 7 });
      const [items, payments] = await Promise.all([
        fetchInvoiceLineItems(invoice.id),
        fetchInvoicePayments(invoice.id),
      ]);
      setInvoiceLineItems(items);
      setInvoicePayments(payments);
      setShowDetailModal(true);
    } catch (error) {
      console.error("Error loading invoice details:", error);
    }
  }

  // -- Send to Client (invoice) -------------------------------------------
  // The page's clients list doesn't carry portal_enabled/portal_token, so the
  // modal's client row is fetched on demand here.
  async function openSendModal(invoice: any) {
    if (!invoice?.client_id) {
      alert("This invoice has no client assigned. Edit the invoice and choose a client first.");
      return;
    }
    try {
      const { supabase } = await import("../lib/supabase");
      const { data, error } = await supabase
        .from("clients")
        .select("id, name, contact_name, phone, email, portal_enabled, portal_token")
        .eq("id", invoice.client_id)
        .maybeSingle();
      if (error || !data) throw new Error(error?.message || "Client not found.");
      setSendClient(data);
      setShowSendModal(true);
    } catch (e: any) {
      alert("Could not open Send to Client: " + (e?.message || "unknown error"));
    }
  }

  // -- Mark as sent (invoice handed over / never sent: recorded for the books, nothing is emailed) ------------------------
  async function openMarkSentModal(invoice: any) {
    try {
      let clientHasPortal = false;
      if (invoice?.client_id) {
        const { supabase } = await import("../lib/supabase");
        const { data } = await supabase.from("clients").select("portal_enabled").eq("id", invoice.client_id).maybeSingle();
        clientHasPortal = !!data?.portal_enabled;
      }
      setMarkTarget({ invoice, clientName: invoice?.clients?.name ?? null, clientHasPortal });
    } catch (e: any) {
      alert("Could not open Mark as sent: " + (e?.message || "unknown error"));
    }
  }

  async function handleMarkedSent() {
    setMarkTarget(null);
    await refreshSharedState();
  }

  async function undoMarkSent(invoice: any) {
    if (!window.confirm(`Take Invoice #${invoice.invoice_number} back to draft?\n\nIt will stop counting as sent (receivables and aging) and leave the client portal. Nothing has been paid on it.`)) return;
    try {
      await undoMarkedSent(invoice.id);
      await refreshSharedState();
    } catch (e: any) {
      alert(e?.message || "Could not take the invoice back to draft.");
    }
  }

  // Called after a send/withdraw: pull the new share state into the open
  // invoice, then refresh the list.
  async function refreshSharedState() {
    try {
      if (selectedInvoice?.id) {
        const { supabase } = await import("../lib/supabase");
        const { data } = await supabase
          .from("client_invoices")
          .select("status, sent_date, shared_at, shared_via, shared_by, withdrawn_at, reminder_enabled, sent_method, marked_sent_at, marked_sent_by_name, marked_sent_note, marked_sent_reminders, marked_sent_portal")
          .eq("id", selectedInvoice.id)
          .maybeSingle();
        if (data) setSelectedInvoice((prev: any) => (prev ? { ...prev, ...data } : prev));
      }
      await loadInvoices();
    } catch (e) {
      console.error("Error refreshing invoice share state:", e);
    }
  }

  async function loadAdvances() {
    try {
      setAdvances(await fetchUnappliedAdvances({ companyId: companyId || undefined }));
    } catch (error) {
      console.error("Error loading advance payments:", error);
    }
  }

  function openAdvanceModal() {
    setAdvanceForm({
      project_id: "",
      amount: "",
      payment_date: new Date().toISOString().split("T")[0],
      payment_method: "check",
      reference_number: "",
      notes: "",
      deposit_account_id: "",
    });
    setAdvanceError("");
    setShowAdvanceModal(true);
  }

  async function handleAdvanceSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (savingAdvance) return;
    const project = projects.find(p => p.id === advanceForm.project_id);
    if (!project) { setAdvanceError("Choose a project."); return; }
    if (!project.client_id) { setAdvanceError("This project has no client set. Set the project's client first, then record the advance."); return; }
    setSavingAdvance(true);
    setAdvanceError("");
    try {
      await recordAdvancePayment({
        companyId,
        projectId: project.id,
        clientId: project.client_id,
        amount: parseFloat(advanceForm.amount),
        paymentDate: advanceForm.payment_date,
        method: advanceForm.payment_method,
        referenceNumber: advanceForm.reference_number,
        notes: advanceForm.notes,
        depositAccountId: advanceForm.deposit_account_id || null,
      });
      setShowAdvanceModal(false);
      await loadAdvances();
    } catch (error: any) {
      setAdvanceError(error?.message || "The advance could not be recorded.");
    } finally {
      setSavingAdvance(false);
    }
  }

  function openPaymentModal(invoice: any) {
    setSelectedInvoice(invoice);
    setPaymentData({
      payment_date: new Date().toISOString().split("T")[0],
      amount: invoice.balance_due.toString(),
      payment_method: "check",
      reference_number: "",
      notes: "",
      deposit_account_id: "",
    });
    setPaymentError("");
    setShowPaymentModal(true);
  }

  // Invoices an advance can be applied to: same client, issued, something still owed, same project (or none).
  function invoicesForAdvance(adv: ClientPayment) {
    return invoices.filter((inv: ClientInvoice & { client_id?: string | null; project_id?: string | null }) =>
      ["sent", "partial", "overdue"].includes(inv.status) && Number(inv.balance_due || 0) > 0
      && (!adv.client_id || !inv.client_id || inv.client_id === adv.client_id)
      && (!inv.project_id || inv.project_id === adv.project_id));
  }

  function openApply(adv: ClientPayment) {
    const options = invoicesForAdvance(adv);
    const first = options[0];
    setApplyForm({
      invoiceId: first?.id || "",
      amount: first ? String(Math.min(Number(adv.amount), Number(first.balance_due || 0))) : "",
      date: new Date().toISOString().split("T")[0],
    });
    setApplyError("");
    setApplying(adv);
  }

  async function handleApplySubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!applying || applyBusy) return;
    const amount = Math.round(parseFloat(applyForm.amount) * 100) / 100;
    if (!applyForm.invoiceId) { setApplyError("Choose the invoice."); return; }
    if (!(amount > 0)) { setApplyError("Type an amount above zero."); return; }
    setApplyBusy(true);
    setApplyError("");
    try {
      await applyAdvanceToInvoice(applying.id, applyForm.invoiceId, amount, applyForm.date);
      setApplying(null);
      await loadAdvances();
      loadInvoices();
    } catch (err: unknown) {
      setApplyError(err instanceof Error ? err.message : "The advance was not applied.");
    } finally {
      setApplyBusy(false);
    }
  }

  async function handlePaymentSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (savingPayment) return;   // a second click / Enter while saving would record the payment twice
    setPaymentError("");

    try {
      if (!selectedInvoice || !companyId) return;

      // Never more than is still owed (the standard rule). Extra money is an advance.
      const fmt = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "JMD" }).format(n);
      const amount = Math.round(parseFloat(paymentData.amount) * 100) / 100;
      const owed = Math.round(Number(selectedInvoice.balance_due || 0) * 100) / 100;
      if (!(amount > 0)) { setPaymentError("Type an amount above zero."); return; }
      if (amount > owed) {
        setPaymentError(owed > 0
          ? `That is more than the ${fmt(owed)} still owed on this invoice. Record ${fmt(owed)} here, and the extra as an advance for the project.`
          : "This invoice is already fully paid. Record the money as an advance for the project instead.");
        return;
      }
      setSavingPayment(true);

      const newPayment = await createClientPayment({
        company_id: companyId,
        client_id: selectedInvoice.client_id,
        invoice_id: selectedInvoice.id,
        payment_number: `PAY-${Date.now()}`,
        payment_date: paymentData.payment_date,
        amount: parseFloat(paymentData.amount),
        payment_method: paymentData.payment_method,
        reference_number: paymentData.reference_number || null,
        notes: paymentData.notes || null,
        deposit_account_id: paymentData.deposit_account_id || null,
      });

      await updateInvoiceAfterPayment(selectedInvoice.id);

      setShowPaymentModal(false);
      if (notificationsEnabled) {
        const client = clients.find(c => c.id === selectedInvoice.client_id);
        if (client && (client.email || client.phone)) {
          setReceiptLinkNote("");
          setThankYouData({ client, amount: parseFloat(paymentData.amount), invoiceNumber: selectedInvoice.invoice_number, paymentId: newPayment?.id });
          setShowThankYouModal(true);
        }
      }
      loadInvoices();

      if (showDetailModal) {
        const payments = await fetchInvoicePayments(selectedInvoice.id);
        setInvoicePayments(payments);
      }
    } catch (error) {
      console.error("Error recording payment:", error);
      setPaymentError("The payment was not saved. Please try again.");
    } finally {
      setSavingPayment(false);
    }
  }

  // Receipt links for client payments: made only when someone presses WhatsApp / Copy receipt link / Email (create_receipt_link reuses the active link).
  function receiptLinkFailed(e: unknown) { setReceiptLinkNote(""); alert("Could not create the receipt link: " + errorMessage(e)); }
  async function copyClientReceiptLink(paymentId: string) {
    try {
      const url = receiptUrl(await createReceiptLink("client_payment", paymentId));
      setReceiptLinkNote(await copyToClipboard(url) ? "Receipt link copied." : url);
    } catch (e) { receiptLinkFailed(e); }
  }
  async function revokeClientReceiptLink(paymentId: string) {
    try {
      const token = await findReceiptLink("client_payment", paymentId);
      if (!token) { setReceiptLinkNote("There is no active receipt link for this payment."); return; }
      if (!window.confirm("Revoke the receipt link? Anyone who has it will no longer be able to open the receipt.")) return;
      await revokeReceiptLink(token);
      setReceiptLinkNote("Receipt link revoked.");
    } catch (e) { alert("Could not revoke the receipt link: " + errorMessage(e)); }
  }

  async function deleteInvoice(invoice: ClientInvoice) {
    if (!window.confirm(`Delete invoice ${invoice.invoice_number}? This cannot be undone.`)) return;
    try {
      const { supabase } = await import("../lib/supabase");
      await supabase.from("client_invoice_line_items").delete().eq("invoice_id", invoice.id);
      await supabase.from("client_payments").delete().eq("invoice_id", invoice.id);
      const { error } = await supabase.from("client_invoices").delete().eq("id", invoice.id);
      if (error) throw error;
      await loadInvoices();
      if (selectedInvoice?.id === invoice.id) setSelectedInvoice(null);
    } catch (e: any) {
      alert("Failed to delete invoice: " + e.message);
    }
  }

  function openEditInvoice(invoice: ClientInvoice) {
    setEditingInvoice(invoice);
    setEditForm({
      invoice_date: invoice.invoice_date || "",
      due_date: invoice.due_date || "",
      tax_rate: invoice.tax_rate || 0,
      notes: invoice.notes || "",
      terms: invoice.terms || "",
      status: invoice.status || "draft",
      project_id: invoice.project_id || "",
    });
  }

  async function saveEditInvoice() {
    if (!editingInvoice) return;
    try {
      await updateClientInvoice(editingInvoice.id, {
        invoice_date: editForm.invoice_date,
        due_date: editForm.due_date,
        tax_rate: editForm.tax_rate,
        notes: editForm.notes.trim() || null,
        terms: editForm.terms.trim() || null,
        status: editForm.status as ClientInvoice["status"],
        project_id: editForm.project_id || null,
      });
      await loadInvoices();
      setEditingInvoice(null);
    } catch (e: any) {
      alert("Failed to update invoice: " + e.message);
    }
  }

  // Cancel a client advance: director or supervisor only (also checked in the database), with a reason that is kept
  // on the reversal in the books. Refused while part of it is used on an invoice.
  async function handleCancelAdvance(a: { id: string; amount: number | string; project_id?: string | null }) {
    const projectName = projects.find(p => p.id === a.project_id)?.name || "this project";
    const reason = window.prompt(`Cancel the advance of ${fmtAdvance(Number(a.amount))} for ${projectName}?\n\nIt comes out of the books. Type why:`);
    if (reason === null) return;
    if (reason.trim().length < 3) { alert("Type why the advance is being cancelled."); return; }
    try {
      await cancelClientAdvance(a.id, reason);
      await loadAdvances();
      await loadInvoices();
    } catch (e: unknown) {
      alert(e instanceof Error ? e.message : "The advance was not cancelled.");
    }
  }

  async function deletePayment(paymentId: string, invoiceId: string) {
    if (!window.confirm("Delete this payment record? This cannot be undone.")) return;
    try {
      const { supabase } = await import("../lib/supabase");
      const { error } = await supabase.from("client_payments").delete().eq("id", paymentId);
      if (error) throw error;
      await updateInvoiceAfterPayment(invoiceId);
      await loadInvoices();
      if (selectedInvoice?.id === invoiceId) {
        const payments = await fetchInvoicePayments(invoiceId);
        setInvoicePayments(payments);
      }
    } catch (e: any) {
      alert("Failed to delete payment: " + e.message);
    }
  }

  function buildReminderMessage(invoice: any, client: any) {
    const fmt = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "JMD" }).format(n);
    const isOverdue = new Date(invoice.due_date) < new Date();
    return `Hi ${client.contact_name || client.name},\n\n${isOverdue ? "This is a friendly reminder that" : "This is a reminder that"} Invoice #${invoice.invoice_number} for ${fmt(Number(invoice.balance_due))} ${isOverdue ? "is now overdue" : `is due on ${new Date(invoice.due_date).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}`}.\n\nPlease arrange payment at your earliest convenience. Let us know if you have any questions.\n\nThank you,\n${companyDisplayName(companySettings?.company_name)}`;
  }

  function sendReminderWhatsApp(invoice: any) {
    const client = clients.find(c => c.id === invoice.client_id);
    if (!client?.phone) { alert("This client has no phone number on file."); return; }
    const msg = buildReminderMessage(invoice, client);
    const phone = client.phone.replace(/\D/g, "");
    window.open(`https://wa.me/${phone ? `1${phone}` : ""}?text=${encodeURIComponent(msg)}`, "_blank");
    markReminderSent(invoice.id);
  }

  function sendReminderEmail(invoice: any) {
    const client = clients.find(c => c.id === invoice.client_id);
    if (!client?.email) { alert("This client has no email on file."); return; }
    const subject = encodeURIComponent(`Payment Reminder - Invoice #${invoice.invoice_number}`);
    const body = encodeURIComponent(buildReminderMessage(invoice, client));
    window.open(`mailto:${client.email}?subject=${subject}&body=${body}`, "_blank");
    markReminderSent(invoice.id);
  }

  async function markReminderSent(invoiceId: string) {
    try {
      const { supabase } = await import("../lib/supabase");
      await supabase.from("client_invoices").update({ last_reminder_sent_at: new Date().toISOString() }).eq("id", invoiceId);
      setReminderSent(true);
      setTimeout(() => setReminderSent(false), 3000);
    } catch {}
  }

  async function saveReminderSettings(invoiceId: string) {
    setSavingReminder(true);
    try {
      const { supabase } = await import("../lib/supabase");
      await supabase.from("client_invoices").update({
        reminder_enabled: reminderForm.reminder_enabled,
        reminder_days_before: reminderForm.reminder_days_before,
        reminder_repeat_days: reminderForm.reminder_repeat_days,
      }).eq("id", invoiceId);
      setSelectedInvoice((prev: any) => prev ? { ...prev, ...reminderForm } : prev);
      loadInvoices();
    } catch (e) {
      console.error("Error saving reminder settings:", e);
    } finally {
      setSavingReminder(false);
    }
  }

  const filteredInvoices = invoices.filter((inv) => filter === "all" || inv.status === filter);

  const summary = {
    total: invoices.filter((i) => i.status !== "cancelled").reduce((sum, i) => sum + Number(i.balance_due), 0),
    overdue: invoices.filter((i) => i.status === "overdue").reduce((sum, i) => sum + Number(i.balance_due), 0),
    // Paid (YTD): money received on invoices since 1 January (part payments and advances used on invoices count too).
    // It used to add up only invoices marked fully "paid", over all years, so part-paid invoices showed $0.
    paid: paidYtd,
  };

  const totals = calculateTotals();

  return (
    <>
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-8 py-5">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Accounts Receivable</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Manage client invoices and payments</p>
        </div>
        <div className="flex items-center gap-3">
          {contracts.length > 0 && (
            <div className="flex items-center gap-2">
              <select
                value={selectedContract?.id || ""}
                onChange={(e) => {
                  const contract = contracts.find(c => c.id === e.target.value);
                  setSelectedContract(contract || null);
                  setShowProgressBilling(!!contract);
                }}
                className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
              >
                <option value="">Select Contract for Progress Billing</option>
                {contracts.map((contract) => (
                  <option key={contract.id} value={contract.id}>
                    {contract.contract_number} - {contract.projects?.name || "No Project"}
                  </option>
                ))}
              </select>
            </div>
          )}
          <button
            onClick={openAdvanceModal}
            className="flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <DollarSign size={18} />
            Record Advance
          </button>
          <button
            onClick={openCreateModal}
            className="flex items-center gap-2 rounded-xl bg-slate-800 dark:bg-slate-700 px-4 py-2.5 text-sm font-medium text-white hover:bg-slate-700 dark:hover:bg-slate-600"
          >
            <Plus size={18} />
            New Invoice
          </button>
        </div>
      </div>

      <div className="p-8">
        {showProgressBilling && selectedContract ? (
          <div className="mb-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6">
            <ContractProgressBilling
              contractId={selectedContract.id}
              companyId={companyId}
              projectId={selectedContract.project_id}
              clientId={selectedContract.client_id}
              onInvoiceCreated={() => {
                loadInvoices();
                setShowProgressBilling(false);
                setSelectedContract(null);
              }}
            />
          </div>
        ) : null}

        <div className="mb-6 grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
          <div className="min-w-0 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 sm:p-5">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-blue-50 p-2.5 flex-shrink-0">
                <DollarSign size={20} className="text-blue-600" />
              </div>
              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400 truncate">Outstanding</div>
                <div className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-slate-100 truncate">${summary.total.toLocaleString()}</div>
              </div>
            </div>
          </div>

          <div className="min-w-0 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 sm:p-5">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-red-50 p-2.5 flex-shrink-0">
                <AlertCircle size={20} className="text-red-600" />
              </div>
              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400 truncate">Overdue</div>
                <div className="text-lg sm:text-2xl font-bold text-red-600 truncate">${summary.overdue.toLocaleString()}</div>
              </div>
            </div>
          </div>

          <div className="min-w-0 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 sm:p-5 col-span-2 sm:col-span-1">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-green-50 p-2.5 flex-shrink-0">
                <CheckCircle size={20} className="text-green-600" />
              </div>
              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400 truncate">Paid (YTD)</div>
                <div className="text-lg sm:text-2xl font-bold text-green-600 truncate">${summary.paid.toLocaleString()}</div>
              </div>
            </div>
          </div>
        </div>

        {advances.length > 0 && (
          <div className="mb-6 rounded-xl border border-amber-200 dark:border-amber-500/30 bg-amber-50/60 dark:bg-amber-500/5 p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2 mb-2">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Unapplied Advances ({advances.length})</h2>
              <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                {fmtAdvance(advances.reduce((s, a) => s + Number(a.amount || 0), 0))}
              </div>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Money received for a project before it was invoiced. Tick an advance when you generate an invoice from a BOQ, or use "Apply to invoice" for an invoice you already sent (all of it, or part of it on each progress invoice).
            </p>
            <div className="space-y-1.5">
              {advances.map((a) => (
                <div key={a.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-white dark:bg-slate-900 px-3 py-2 text-sm">
                  <div className="min-w-0">
                    <div className="font-medium text-slate-900 dark:text-slate-100 truncate">
                      {projects.find(p => p.id === a.project_id)?.name || "Project"}
                      <span className="text-slate-500 dark:text-slate-400 font-normal"> · {clients.find(c => c.id === a.client_id)?.name || "Client"}</span>
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                      {a.payment_date} · {String(a.payment_method).replace("_", " ")}{a.reference_number ? ` - ${a.reference_number}` : ""}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">{fmtAdvance(Number(a.amount))}</div>
                    <button type="button" onClick={() => openApply(a)}
                      className="rounded-lg border border-amber-300 dark:border-amber-500/40 px-2.5 py-1 text-xs font-semibold text-amber-800 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-500/10">
                      Apply to invoice
                    </button>
                    {(userRole === "director" || userRole === "supervisor") && (
                      <button type="button" onClick={() => { void handleCancelAdvance(a); }}
                        className="rounded-lg border border-red-300 dark:border-red-500/40 px-2.5 py-1 text-xs font-semibold text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-500/10">
                        Cancel advance
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mb-4 flex items-center gap-3">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as any)}
            className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
          >
            <option value="all">All Invoices</option>
            <option value="draft">Draft</option>
            <option value="sent">Sent</option>
            <option value="partial">Partial</option>
            <option value="overdue">Overdue</option>
            <option value="paid">Paid</option>
          </select>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <table className="w-full" style={{ minWidth: 640 }}>
            <thead className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Invoice #
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Due Date
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Amount
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Balance
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {filteredInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50 dark:hover:bg-white/[0.03]">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <FileText size={16} className="text-slate-600 dark:text-slate-400" />
                      <span className="font-mono text-sm font-medium text-slate-900 dark:text-slate-100">{inv.invoice_number}</span>
                    </div>
                    {/* Banking step 3a: is this invoice in the books (receivable + income), and if not, why. */}
                    {inv.gl_transaction_id
                      ? <div className="mt-0.5 text-[10px] text-emerald-600 dark:text-emerald-400">In the books</div>
                      : inv.ledger_note && <div className="mt-0.5 text-[10px] text-amber-600 dark:text-amber-400 max-w-[220px]">{inv.ledger_note}</div>}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-100">{inv.clients?.name || "-"}</div>
                    {inv.projects?.name && <div className="text-xs text-slate-500 dark:text-slate-400">{inv.projects.name}</div>}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500 dark:text-slate-400">{inv.invoice_date}</td>
                  <td className="px-6 py-4 text-sm text-slate-500 dark:text-slate-400">{inv.due_date}</td>
                  <td className="px-6 py-4 text-right text-sm font-medium text-slate-900 dark:text-slate-100">
                    ${Number(inv.total_amount).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-bold text-slate-900 dark:text-slate-100">
                    ${Number(inv.balance_due).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium capitalize ${
                        inv.status === "paid"
                          ? "bg-green-50 dark:bg-green-500/10 text-green-700 dark:text-green-400"
                          : inv.status === "overdue"
                          ? "bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-400"
                          : inv.status === "partial"
                          ? "bg-yellow-50 dark:bg-yellow-500/10 text-yellow-700 dark:text-yellow-400"
                          : inv.status === "sent"
                          ? "bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500"
                      }`}
                    >
                      {inv.status}
                    </span>
                    {inv.status !== "cancelled" && (
                      isSharedNow(inv.shared_at, inv.withdrawn_at) ? (
                        <span
                          title={`Sent to client via ${shareViaLabel(inv.shared_via)} on ${formatJamaicaDateTime(inv.shared_at)}`}
                          className="ml-1.5 inline-flex rounded-full px-2 py-1 text-[10px] font-medium bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                        >
                          Sent
                        </span>
                      ) : isMarkedSent(inv) ? (
                        <span
                          title={markedSentLine(inv)}
                          className="ml-1.5 inline-flex rounded-full px-2 py-1 text-[10px] font-medium bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                        >
                          Marked sent
                        </span>
                      ) : (
                        <span
                          title="Not shared with the client yet"
                          className="ml-1.5 inline-flex rounded-full px-2 py-1 text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500"
                        >
                          Not sent
                        </span>
                      )
                    )}
                    {inv.status !== "cancelled" && (
                      <SeenBadge sharedAt={isSharedNow(inv.shared_at, inv.withdrawn_at)} viewsMap={invoiceViews} id={inv.id} />
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => openDetailModal(inv)}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-colors"
                      >
                        View
                      </button>
                      {inv.status === "draft" && canMarkSent(userRole) && (
                        <button
                          onClick={() => openMarkSentModal(inv)}
                          title="Record that this invoice was delivered without sending it from the app"
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 transition-colors"
                        >
                          Mark as sent
                        </button>
                      )}
                      <button
                        onClick={() => openEditInvoice(inv)}
                        className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                      >
                        <Pencil size={13}/>
                      </button>
                      {userRole === "director" && (
                        <button
                          onClick={() => deleteInvoice(inv)}
                          className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-500/10 text-slate-400 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={13}/>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredInvoices.length === 0 && (
            <div className="py-12 text-center">
              <FileText size={48} className="mx-auto mb-4 text-slate-700 dark:text-slate-300" />
              <div className="text-lg font-medium text-slate-900 dark:text-slate-100">No invoices found</div>
              <div className="mt-1 text-sm text-slate-500 dark:text-slate-400">Create your first client invoice to get started</div>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl">
            <h2 className="mb-6 text-xl font-bold text-slate-900 dark:text-slate-100">Create New Invoice</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Invoice Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.invoice_number}
                    onChange={(e) => setFormData({ ...formData, invoice_number: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Client *</label>
                  <select
                    required
                    value={formData.client_id}
                    onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                  >
                    <option value="">Select Client</option>
                    {clients.map((client) => (
                      <option key={client.id} value={client.id}>
                        {client.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Project (Optional)</label>
                <select
                  value={formData.project_id}
                  onChange={(e) => setFormData({ ...formData, project_id: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                >
                  <option value="">No Project</option>
                  {projects
                    .filter((p) => !formData.client_id || p.client_id === formData.client_id)
                    .map((project) => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Invoice Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.invoice_date}
                    onChange={(e) => setFormData({ ...formData, invoice_date: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Due Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
                <div className="mb-3 flex items-center justify-between">
                  <label className="text-sm font-semibold text-slate-900 dark:text-slate-100">Line Items</label>
                  <button
                    type="button"
                    onClick={addLineItem}
                    className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
                  >
                    + Add Line
                  </button>
                </div>

                <div className="space-y-2">
                  {lineItems.map((item, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2">
                      <input
                        type="text"
                        placeholder="Description"
                        value={item.description}
                        onChange={(e) => updateLineItem(index, "description", e.target.value)}
                        className="col-span-5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                      <input
                        type="number"
                        step="0.01"
                        placeholder="Qty"
                        value={item.quantity}
                        onChange={(e) => updateLineItem(index, "quantity", e.target.value)}
                        className="col-span-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                      <input
                        type="text"
                        placeholder="Unit"
                        value={item.unit}
                        onChange={(e) => updateLineItem(index, "unit", e.target.value)}
                        className="col-span-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                      <input
                        type="number"
                        step="0.01"
                        placeholder="Rate"
                        value={item.rate}
                        onChange={(e) => updateLineItem(index, "rate", e.target.value)}
                        className="col-span-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                      <div className="col-span-1 flex items-center justify-end text-sm font-medium text-slate-900 dark:text-slate-100">
                        ${item.amount.toFixed(2)}
                      </div>
                      <button
                        type="button"
                        onClick={() => removeLineItem(index)}
                        className="col-span-1 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Tax Rate (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.tax_rate}
                    onChange={(e) => setFormData({ ...formData, tax_rate: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Payment Terms</label>
                  <input
                    type="text"
                    value={formData.terms}
                    onChange={(e) => setFormData({ ...formData, terms: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                    placeholder="Net 30"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Notes</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  placeholder="Additional notes"
                />
              </div>

              <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500 dark:text-slate-400">Subtotal:</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">${totals.subtotal.toFixed(2)}</span>
                </div>
                {totals.taxAmount > 0 && (
                  <div className="mt-1 flex justify-between text-sm">
                    <span className="text-slate-500 dark:text-slate-400">Tax ({formData.tax_rate}%):</span>
                    <span className="font-medium text-slate-900 dark:text-slate-100">${totals.taxAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="mt-2 flex justify-between border-t border-slate-300 dark:border-slate-700 pt-2">
                  <span className="font-semibold text-slate-900 dark:text-slate-100">Total:</span>
                  <span className="text-lg font-bold text-slate-900 dark:text-slate-100">${totals.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-slate-800 dark:bg-slate-700 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 dark:hover:bg-slate-600"
                >
                  Create Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showDetailModal && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Invoice Details</h2>
              <button onClick={() => setShowDetailModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                <X size={24} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6 mb-6">
              <div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Invoice Number</div>
                <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">{selectedInvoice.invoice_number}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Status</div>
                <span
                  className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium capitalize ${
                    selectedInvoice.status === "paid"
                      ? "bg-green-50 dark:bg-green-500/10 text-green-700 dark:text-green-400"
                      : selectedInvoice.status === "overdue"
                      ? "bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-400"
                      : selectedInvoice.status === "partial"
                      ? "bg-yellow-50 dark:bg-yellow-500/10 text-yellow-700 dark:text-yellow-400"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500"
                  }`}
                >
                  {selectedInvoice.status}
                </span>
              </div>
              <div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Client</div>
                <div className="font-medium text-slate-900 dark:text-slate-100">{selectedInvoice.clients?.name || "-"}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Project</div>
                <div className="font-medium text-slate-900 dark:text-slate-100">{selectedInvoice.projects?.name || "-"}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Invoice Date</div>
                <div className="font-medium text-slate-900 dark:text-slate-100">{selectedInvoice.invoice_date}</div>
              </div>
              <div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Due Date</div>
                <div className="font-medium text-slate-900 dark:text-slate-100">{selectedInvoice.due_date}</div>
              </div>
            </div>

            {selectedInvoice.status !== "cancelled" && isSharedNow(selectedInvoice.shared_at, selectedInvoice.withdrawn_at) && (
              <div className="mb-4 text-xs text-slate-500 dark:text-slate-400">
                <span className="font-medium">Client portal:</span>{" "}
                <SeenDetail className="inline" sharedAt={isSharedNow(selectedInvoice.shared_at, selectedInvoice.withdrawn_at)} viewsMap={invoiceViews} id={selectedInvoice.id} />
              </div>
            )}

            {isMarkedSent(selectedInvoice) && (
              <div className="mb-4 rounded-lg border border-emerald-200 dark:border-emerald-500/20 bg-emerald-50/60 dark:bg-emerald-500/5 px-3 py-2" data-testid="marked-sent-info">
                <div className="text-sm font-medium text-emerald-800 dark:text-emerald-300">{markedSentLine(selectedInvoice)}</div>
                <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{markedSentDetails(selectedInvoice).join(" · ")}</div>
              </div>
            )}

            {selectedInvoice.notes && (
              <div className="mb-6">
                <div className="text-sm text-slate-500 dark:text-slate-400 mb-1">Notes</div>
                <div className="text-sm text-slate-900 dark:text-slate-100">{selectedInvoice.notes}</div>
              </div>
            )}

            <div className="border-t border-slate-200 dark:border-slate-800 pt-4 mb-6">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">Line Items</h3>
              {invoiceLineItems.length > 0 ? (
                <div className="space-y-2">
                  {invoiceLineItems.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <div className="flex-1">
                        <div className="font-medium text-slate-900 dark:text-slate-100">{item.description}</div>
                        {String(item.line_name ?? "").trim() && <div className="text-xs font-semibold text-teal-600 dark:text-teal-400">{String(item.line_name).trim()}</div>}
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          {item.quantity} {item.unit} × ${Number(item.rate).toFixed(2)}
                        </div>
                      </div>
                      <div className="font-medium text-slate-900 dark:text-slate-100">${Number(item.amount).toFixed(2)}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-slate-500 dark:text-slate-400">No line items</div>
              )}
            </div>

            <div className="border-t border-slate-200 dark:border-slate-800 pt-4 mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-500 dark:text-slate-400">Subtotal:</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">${Number(selectedInvoice.subtotal).toFixed(2)}</span>
              </div>
              {selectedInvoice.tax_amount > 0 && (
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-500 dark:text-slate-400">Tax ({selectedInvoice.tax_rate}%):</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">${Number(selectedInvoice.tax_amount).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold border-t border-slate-200 dark:border-slate-800 pt-2 mb-2">
                <span className="text-slate-900 dark:text-slate-100">Total:</span>
                <span className="text-slate-900 dark:text-slate-100">${Number(selectedInvoice.total_amount).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-500 dark:text-slate-400">Paid:</span>
                <span className="font-medium text-green-600 dark:text-green-400">${Number(selectedInvoice.amount_paid).toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg border-t border-slate-200 dark:border-slate-800 pt-2">
                <span className="text-slate-900 dark:text-slate-100">Balance Due:</span>
                <span className="text-blue-600 dark:text-blue-400">${Number(selectedInvoice.balance_due).toFixed(2)}</span>
              </div>
            </div>

            <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Payments</h3>
                {selectedInvoice.balance_due > 0 && (
                  <button
                    onClick={() => {
                      setShowDetailModal(false);
                      openPaymentModal(selectedInvoice);
                    }}
                    className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
                  >
                    + Record Payment
                  </button>
                )}
              </div>
              {invoicePayments.length > 0 ? (
                <div className="space-y-2">
                  {invoicePayments.map((payment) => (
                    <div key={payment.id} className="flex items-center justify-between text-sm border-b border-slate-100 dark:border-slate-800 pb-2">
                      <div>
                        <div className="font-medium text-slate-900 dark:text-slate-100">{payment.payment_date}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                          {payment.payment_method.replace("_", " ")}
                          {payment.reference_number && ` - ${payment.reference_number}`}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <div className="font-medium text-green-600 dark:text-green-400">${Number(payment.amount).toFixed(2)}</div>
                        <button onClick={() => copyClientReceiptLink(payment.id!)} title="Copy a link to this payment's receipt"
                          className="px-2 py-1 rounded-lg text-[11px] font-semibold text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                          Copy receipt link
                        </button>
                        <button onClick={() => revokeClientReceiptLink(payment.id!)} title="Stop this payment's receipt link from working"
                          className="px-2 py-1 rounded-lg text-[11px] font-semibold text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors">
                          Revoke link
                        </button>
                        {userRole === "director" && (
                          <button onClick={() => deletePayment(payment.id!, selectedInvoice.id)}
                            className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-500/10 text-slate-400 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 transition-colors">
                            <Trash2 size={12}/>
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-slate-500 dark:text-slate-400">No payments recorded</div>
              )}
              {receiptLinkNote && showDetailModal && <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 break-all">{receiptLinkNote}</div>}
            </div>

            <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
              <div className="flex items-center gap-2 mb-3">
                <Bell size={14} className="text-slate-500 dark:text-slate-400"/>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Payment Reminders</h3>
              </div>
              <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500 dark:text-slate-400">Enable reminders for this invoice</span>
                  <button onClick={()=>setReminderForm(f=>({...f, reminder_enabled: !f.reminder_enabled}))}
                    className={`w-10 h-5 rounded-full transition-colors relative ${reminderForm.reminder_enabled?"bg-blue-600":"bg-slate-300 dark:bg-slate-600"}`}>
                    <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${reminderForm.reminder_enabled?"left-5":"left-0.5"}`}/>
                  </button>
                </div>
                {reminderForm.reminder_enabled && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-slate-500 dark:text-slate-400 block mb-1">Remind before due (days)</label>
                      <input type="number" min="0" value={reminderForm.reminder_days_before}
                        onChange={e=>setReminderForm(f=>({...f, reminder_days_before: parseInt(e.target.value)||0}))}
                        className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 px-3 py-1.5 text-sm"/>
                    </div>
                    <div>
                      <label className="text-xs text-slate-500 dark:text-slate-400 block mb-1">Repeat every (days, if unpaid)</label>
                      <input type="number" min="0" value={reminderForm.reminder_repeat_days}
                        onChange={e=>setReminderForm(f=>({...f, reminder_repeat_days: parseInt(e.target.value)||0}))}
                        className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 px-3 py-1.5 text-sm"/>
                    </div>
                  </div>
                )}
                <button onClick={()=>saveReminderSettings(selectedInvoice.id)} disabled={savingReminder}
                  className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium disabled:opacity-50">
                  <Save size={12}/> {savingReminder?"Saving...":"Save Reminder Settings"}
                </button>
                {selectedInvoice.last_reminder_sent_at && (
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Last sent: {new Date(selectedInvoice.last_reminder_sent_at).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</div>
                )}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                  <button onClick={()=>sendReminderWhatsApp(selectedInvoice)}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-emerald-300 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-xs font-semibold transition">
                    <MessageCircle size={13}/> Send via WhatsApp
                  </button>
                  <button onClick={()=>sendReminderEmail(selectedInvoice)}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-blue-300 dark:border-blue-500/30 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500/20 text-blue-700 dark:text-blue-400 text-xs font-semibold transition">
                    <Mail size={13}/> Send via Email
                  </button>
                </div>
                {reminderSent && (
                  <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium text-center">Reminder marked as sent ?</div>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t border-slate-200 dark:border-slate-800 mt-6">
              <button
                disabled={printingInvoice}
                onClick={() => {
                  if (printingInvoice) return;
                  setPrintingInvoice(true);
                  printInvoiceFresh({ invoice: selectedInvoice, lineItems: invoiceLineItems, payments: invoicePayments })
                    .catch(() => alert("Could not prepare the invoice for printing. Please try again."))
                    .finally(() => setPrintingInvoice(false));
                }}
                className="flex items-center gap-2 rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-60 disabled:cursor-wait"
              >
                <Printer size={14} />
                {printingInvoice ? "Preparing…" : "Print / Save as PDF"}
              </button>
              {selectedInvoice.status === "draft" && canMarkSent(userRole) && (
                <button
                  onClick={() => openMarkSentModal(selectedInvoice)}
                  className="flex items-center gap-2 rounded-lg border border-emerald-300 dark:border-emerald-500/40 px-4 py-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 transition-colors"
                >
                  <CheckCircle size={14} />
                  Mark as sent
                </button>
              )}
              {isMarkedSent(selectedInvoice) && canUndoMarkedSent(userRole) && Number(selectedInvoice.amount_paid || 0) === 0 && invoicePayments.length === 0 && (
                <button
                  onClick={() => undoMarkSent(selectedInvoice)}
                  className="flex items-center gap-2 rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  Undo - back to draft
                </button>
              )}
              {selectedInvoice.status !== "cancelled" && (
                <button
                  onClick={() => openSendModal(selectedInvoice)}
                  className="flex items-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-500 px-4 py-2 text-sm font-semibold text-white transition-colors"
                >
                  <Send size={14} />
                  {isSharedNow(selectedInvoice.shared_at, selectedInvoice.withdrawn_at) ? "Sent to Client · Resend" : "Send to Client"}
                </button>
              )}
              <button
                onClick={() => setShowDetailModal(false)}
                className="rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <MarkAsSentModal
        open={!!markTarget}
        invoice={markTarget?.invoice ?? null}
        clientName={markTarget?.clientName}
        clientHasPortal={!!markTarget?.clientHasPortal}
        onClose={() => setMarkTarget(null)}
        onDone={() => void handleMarkedSent()}
      />

      {sendClient && selectedInvoice && (
        <SendToClientModal
          open={showSendModal}
          onClose={() => setShowSendModal(false)}
          itemType="invoice"
          itemId={selectedInvoice.id}
          itemLabel={`Invoice #${selectedInvoice.invoice_number}`}
          client={sendClient}
          sharedAt={isSharedNow(selectedInvoice.shared_at, selectedInvoice.withdrawn_at)}
          sharedVia={isSharedNow(selectedInvoice.shared_at, selectedInvoice.withdrawn_at) ? (selectedInvoice.shared_via || null) : null}
          messageText={(url) =>
            `Hello ${sendClient.contact_name || sendClient.name}, your invoice ${selectedInvoice.invoice_number} for ${new Intl.NumberFormat("en-US", { style: "currency", currency: "JMD" }).format(Number(selectedInvoice.total_amount) || 0)} is ready. View it in your client portal:\n\n${url}\n\n${companyDisplayName(companySettings?.company_name)}`
          }
          onChanged={refreshSharedState}
        />
      )}

      {showPaymentModal && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Record Payment</h2>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                <X size={24} />
              </button>
            </div>

            <div className="mb-6 rounded-lg bg-slate-50 dark:bg-slate-800 p-4">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-500 dark:text-slate-400">Invoice:</span>
                <span className="font-mono font-medium text-slate-900 dark:text-slate-100">{selectedInvoice.invoice_number}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500 dark:text-slate-400">Balance Due:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">${Number(selectedInvoice.balance_due).toFixed(2)}</span>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              {paymentError && (
                <div className="rounded-lg border border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 px-3 py-2 text-sm text-red-700 dark:text-red-300">{paymentError}</div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Payment Date *</label>
                  <input
                    type="date"
                    required
                    value={paymentData.payment_date}
                    onChange={(e) => setPaymentData({ ...paymentData, payment_date: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Amount *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={paymentData.amount}
                    onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Payment Method *</label>
                <select
                  required
                  value={paymentData.payment_method}
                  onChange={(e) => setPaymentData({ ...paymentData, payment_method: e.target.value as any })}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                >
                  <option value="check">Check</option>
                  <option value="ach">ACH</option>
                  <option value="wire">Wire Transfer</option>
                  <option value="credit_card">Credit Card</option>
                  <option value="cash">Cash</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <DepositedToSelect value={paymentData.deposit_account_id} accounts={moneyAccounts}
                onChange={(v) => setPaymentData({ ...paymentData, deposit_account_id: v })} />

              <div>
                <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Reference Number</label>
                <input
                  type="text"
                  value={paymentData.reference_number}
                  onChange={(e) => setPaymentData({ ...paymentData, reference_number: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  placeholder="Check #, Transaction ID, etc."
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Notes</label>
                <textarea
                  rows={2}
                  value={paymentData.notes}
                  onChange={(e) => setPaymentData({ ...paymentData, notes: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  placeholder="Additional payment notes"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingPayment}
                  className="rounded-lg bg-slate-800 dark:bg-slate-700 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 dark:hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {savingPayment ? "Saving..." : "Record Payment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Advance Payment Modal */}
      {applying && (() => {
        const options = invoicesForAdvance(applying);
        const inv = options.find((o) => o.id === applyForm.invoiceId);
        const amt = Number(applyForm.amount) || 0;
        const left = Number(applying.amount) - amt;
        const field = "w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100";
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <div className="w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl">
              <div className="mb-2 flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Apply advance to an invoice</h2>
                <button onClick={() => setApplying(null)} className="text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                  <X size={24} />
                </button>
              </div>
              <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
                {projects.find(p => p.id === applying.project_id)?.name || "Project"} · advance of {fmtAdvance(Number(applying.amount))} received {applying.payment_date}.
                Use all of it, or part of it on each progress invoice. What you don't use stays as an advance.
              </p>
              <form onSubmit={handleApplySubmit} className="space-y-4">
                {applyError && (
                  <div className="rounded-lg border border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 px-3 py-2 text-sm text-red-700 dark:text-red-300">{applyError}</div>
                )}
                {options.length === 0 ? (
                  <div className="rounded-lg bg-amber-50 dark:bg-amber-500/10 px-3 py-2 text-sm text-amber-800 dark:text-amber-300">
                    There is no issued invoice for this client and project with money still owed. Create and send the invoice first.
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Invoice *</label>
                      <select value={applyForm.invoiceId} className={field}
                        onChange={(e) => {
                          const o = options.find((x) => x.id === e.target.value);
                          setApplyForm({ ...applyForm, invoiceId: e.target.value,
                            amount: o ? String(Math.min(Number(applying.amount), Number(o.balance_due || 0))) : applyForm.amount });
                        }}>
                        {options.map((o) => (
                          <option key={o.id} value={o.id}>{o.invoice_number} · {o.invoice_date} · still owed {fmtAdvance(Number(o.balance_due || 0))}</option>
                        ))}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Amount to apply *</label>
                        <input type="number" step="0.01" min="0" value={applyForm.amount} className={field}
                          onChange={(e) => setApplyForm({ ...applyForm, amount: e.target.value })} />
                        {inv && (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {[10, 20, 25, 50].map((pct) => {
                              const v = Math.min(Number(applying.amount), Number(inv.balance_due || 0), Math.round(Number(inv.total_amount || 0) * pct) / 100);
                              return (
                                <button key={pct} type="button" onClick={() => setApplyForm({ ...applyForm, amount: String(v) })}
                                  className="rounded border border-slate-300 dark:border-slate-700 px-1.5 py-0.5 text-[11px] text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800">
                                  {pct}% of invoice
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Date applied</label>
                        <input type="date" value={applyForm.date} className={field}
                          onChange={(e) => setApplyForm({ ...applyForm, date: e.target.value })} />
                      </div>
                    </div>
                    <div className="rounded-lg bg-slate-50 dark:bg-slate-800/60 px-3 py-2 text-sm text-slate-600 dark:text-slate-300">
                      {inv && <>Invoice {inv.invoice_number} still owed after this: <b>{fmtAdvance(Math.max(Number(inv.balance_due || 0) - amt, 0))}</b><br /></>}
                      Left on the advance after this: <b>{fmtAdvance(Math.max(left, 0))}</b>
                    </div>
                  </>
                )}
                <div className="flex justify-end gap-3">
                  <button type="button" onClick={() => setApplying(null)}
                    className="rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800">
                    Cancel
                  </button>
                  <button type="submit" disabled={applyBusy || options.length === 0}
                    className="rounded-lg bg-slate-800 dark:bg-slate-700 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 dark:hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed">
                    {applyBusy ? "Applying..." : "Apply"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {showAdvanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Record Advance Payment</h2>
              <button onClick={() => setShowAdvanceModal(false)} className="text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                <X size={24} />
              </button>
            </div>
            <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
              Money received for a project before it has been invoiced. You can credit it against an invoice later: tick it when you generate the invoice from the BOQ, or use "Apply to invoice" (all of it, or part on each progress invoice).
            </p>

            {(() => {
              const project = projects.find(p => p.id === advanceForm.project_id);
              const client = project ? clients.find(c => c.id === project.client_id) : null;
              return (
                <form onSubmit={handleAdvanceSubmit} className="space-y-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Project *</label>
                    <select
                      required
                      value={advanceForm.project_id}
                      onChange={(e) => setAdvanceForm({ ...advanceForm, project_id: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                    >
                      <option value="">Select a project</option>
                      {projects.map((p) => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))}
                    </select>
                    {project && (
                      <div className={`mt-1 text-xs ${project.client_id ? "text-slate-500 dark:text-slate-400" : "text-red-500"}`}>
                        {project.client_id ? `Client: ${client?.name || "—"}` : "This project has no client set, so an advance can't be recorded for it yet."}
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Date *</label>
                      <input
                        type="date"
                        required
                        value={advanceForm.payment_date}
                        onChange={(e) => setAdvanceForm({ ...advanceForm, payment_date: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Amount (JMD) *</label>
                      <input
                        type="number"
                        step="0.01"
                        min="0.01"
                        required
                        value={advanceForm.amount}
                        onChange={(e) => setAdvanceForm({ ...advanceForm, amount: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Payment Method *</label>
                    <select
                      required
                      value={advanceForm.payment_method}
                      onChange={(e) => setAdvanceForm({ ...advanceForm, payment_method: e.target.value as ClientPayment["payment_method"] })}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                    >
                      <option value="check">Check</option>
                      <option value="ach">ACH</option>
                      <option value="wire">Wire Transfer</option>
                      <option value="credit_card">Credit Card</option>
                      <option value="cash">Cash</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <DepositedToSelect value={advanceForm.deposit_account_id} accounts={moneyAccounts}
                    onChange={(v) => setAdvanceForm({ ...advanceForm, deposit_account_id: v })} />

                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Reference Number</label>
                    <input
                      type="text"
                      value={advanceForm.reference_number}
                      onChange={(e) => setAdvanceForm({ ...advanceForm, reference_number: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                      placeholder="Check #, Transaction ID, etc."
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-500 dark:text-slate-400">Notes</label>
                    <textarea
                      rows={2}
                      value={advanceForm.notes}
                      onChange={(e) => setAdvanceForm({ ...advanceForm, notes: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-slate-900 dark:text-slate-100"
                      placeholder="Additional notes"
                    />
                  </div>

                  {advanceError && <div className="text-sm text-red-500">{advanceError}</div>}

                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAdvanceModal(false)}
                      className="rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={savingAdvance || (!!project && !project.client_id)}
                      className="rounded-lg bg-slate-800 dark:bg-slate-700 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 dark:hover:bg-slate-600 disabled:opacity-50"
                    >
                      {savingAdvance ? "Saving..." : "Record Advance"}
                    </button>
                  </div>
                </form>
              );
            })()}
          </div>
        </div>
      )}

      {/* Thank You Notification Modal */}
      {showThankYouModal && thankYouData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">Payment Received</h2>
              <button onClick={() => { setShowThankYouModal(false); setThankYouData(null); }} className="text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                <X size={18}/>
              </button>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Send {thankYouData.client.contact_name || thankYouData.client.name} a thank you message?
            </p>
            <div className="rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-4 mb-4 text-sm text-slate-500 dark:text-slate-400 whitespace-pre-line">
{`Hi ${thankYouData.client.contact_name || thankYouData.client.name},

Thank you! We've received your payment of ${new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD"}).format(thankYouData.amount)} for Invoice #${thankYouData.invoiceNumber}.

We appreciate your business.

${companyDisplayName(companySettings?.company_name)}`}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {thankYouData.client.phone && (
                <button
                  onClick={() => {
                    const msg = `Hi ${thankYouData.client.contact_name||thankYouData.client.name},\n\nThank you! We've received your payment of ${new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD"}).format(thankYouData.amount)} for Invoice #${thankYouData.invoiceNumber}.\n\nWe appreciate your business.\n\n${companyDisplayName(companySettings?.company_name)}`;
                    const paymentId = thankYouData.paymentId;
                    if (!paymentId) { openWhatsApp(thankYouData.client.phone, async () => msg).catch(receiptLinkFailed); return; }
                    openWhatsApp(thankYouData.client.phone, async () => withReceiptLink(msg, await createReceiptLink("client_payment", paymentId))).catch(receiptLinkFailed);
                  }}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-emerald-300 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-sm font-semibold transition"
                >
                  WhatsApp
                </button>
              )}
              {thankYouData.client.email && (
                <button
                  onClick={() => {
                    const subject = `Payment Received - Invoice #${thankYouData.invoiceNumber}`;
                    const body = (`Hi ${thankYouData.client.contact_name||thankYouData.client.name},\n\nThank you! We've received your payment of ${new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD"}).format(thankYouData.amount)} for Invoice #${thankYouData.invoiceNumber}.\n\nWe appreciate your business.\n\n${companyDisplayName(companySettings?.company_name)}`);
                    const paymentId = thankYouData.paymentId;
                    openEmail(subject, async () => paymentId ? withReceiptLink(body, await createReceiptLink("client_payment", paymentId)) : body, thankYouData.client.email).catch(receiptLinkFailed);
                  }}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-blue-300 dark:border-blue-500/30 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500/20 text-blue-700 dark:text-blue-400 text-sm font-semibold transition"
                >
                  Email
                </button>
              )}
            </div>
            {thankYouData.paymentId && (
              <button
                onClick={() => copyClientReceiptLink(thankYouData.paymentId!)}
                className="w-full mt-2 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-sm font-semibold transition"
              >
                🔗 Copy receipt link
              </button>
            )}
            {receiptLinkNote && <div className="mt-2 text-[11px] text-center text-slate-500 dark:text-slate-400 break-all">{receiptLinkNote}</div>}
            <button
              onClick={() => { setShowThankYouModal(false); setThankYouData(null); }}
              className="w-full mt-3 py-2 text-sm text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              Skip for now
            </button>
          </div>
        </div>
      )}

      {/* Edit Invoice Modal */}
      {editingInvoice && (
        <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl w-full sm:max-w-lg flex flex-col"
            style={{ maxHeight: "90dvh" }}>
            {/* Header */}
            <div className="flex-shrink-0 flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">Edit Invoice</h3>
                <p className="text-xs text-slate-400 mt-0.5">{editingInvoice.invoice_number}</p>
              </div>
              <button onClick={() => setEditingInvoice(null)}
                className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400">
                <X size={16}/>
              </button>
            </div>
            {/* Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Invoice Date</label>
                  <input type="date" value={editForm.invoice_date}
                    onChange={e => setEditForm(f => ({ ...f, invoice_date: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Due Date</label>
                  <input type="date" value={editForm.due_date}
                    onChange={e => setEditForm(f => ({ ...f, due_date: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Status</label>
                <select value={editForm.status}
                  onChange={e => setEditForm(f => ({ ...f, status: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none">
                  <option value="draft">Draft</option>
                  <option value="sent">Sent</option>
                  <option value="partial">Partial</option>
                  <option value="paid">Paid</option>
                  <option value="overdue">Overdue</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Project</label>
                <select value={editForm.project_id}
                  onChange={e => setEditForm(f => ({ ...f, project_id: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none">
                  <option value="">No Project</option>
                  {projects
                    .filter((p) => !editingInvoice?.client_id || p.client_id === editingInvoice.client_id)
                    .map((project) => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Tax Rate (%)</label>
                <input type="number" min="0" max="100" value={editForm.tax_rate}
                  onChange={e => setEditForm(f => ({ ...f, tax_rate: Number(e.target.value) }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Terms</label>
                <input type="text" value={editForm.terms}
                  onChange={e => setEditForm(f => ({ ...f, terms: e.target.value }))}
                  placeholder="e.g. Net 30"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Notes</label>
                <textarea value={editForm.notes}
                  onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30 resize-none"/>
              </div>
            </div>
            {/* Footer */}
            <div className="flex-shrink-0 flex gap-3 px-5 py-4 border-t border-slate-200 dark:border-slate-800">
              <button onClick={() => setEditingInvoice(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                Cancel
              </button>
              <button onClick={saveEditInvoice}
                className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}