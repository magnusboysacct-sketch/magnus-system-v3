﻿// src/pages/ClientPortalPage.tsx … Secure portal with password + PWA
import React, { useEffect, useState } from "react";
import { companyDisplayName } from "../lib/companyName";
import { useParams } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { logPortalEvent } from "../lib/portalActivity";
import { useForceLightPage } from "../hooks/useForceLightPage";
import PortalBrandLogo from "../components/PortalBrandLogo";
import { functionErrorMessage } from "../lib/portalErrors";
import ContractDocument, { printContractDocument, printContractDocumentFresh, watermarkFromCompany } from "../components/ContractDocument";
import { useContractSignatureSrcs, isLegacySignatureUrl } from "../lib/contractSignatures";
import type { SignatureSrcs } from "../lib/contractSignatures";
import PortalProjectPicker from "../components/PortalProjectPicker";
import { normalizeProjects, hasMultipleProjects, filterByProject, itemProjectLabel, invoiceTotals, countUnpaid, countUnsigned, countPending, createRequestGate, readRememberedProject, rememberProject, pickRememberedProject } from "../lib/portalProjects";
import type { PortalProject } from "../lib/portalProjects";

type AuthState = "loading"|"error"|"setup"|"login"|"authenticated";
// A field officer (client contact) signing in with their own invite link. The viewer block of get_portal_data says who is looking.
interface PortalContact { id:string; name:string; email:string|null; client_name:string|null; }
type PortalViewer = {kind:"manager"}|{kind:"contact";contact_id:string;name?:string|null;title?:string|null;email?:string|null};
type Tab = "overview"|"photos"|"invoices"|"contracts"|"changes"|"feedback"|"estimates";

// No portal_password_hash — nothing in this file selects it anymore, so it
// was removed from the type rather than left declared-but-always-undefined.
interface Client { id:string; name:string; contact_name:string|null; email:string|null; phone?:string|null; portal_email:string|null; portal_activated_at:string|null; company_id?:string|null; }
interface Project { id:string; name:string; status:string; start_date:string|null; end_date:string|null; site_address:string|null; }
interface Invoice { id:string; invoice_number:string|null; total_amount:number; status:string; issue_date:string|null; due_date:string|null; project_id?:string|null; project_name?:string|null; }
interface ChangeOrder { id:string; title:string; description:string|null; amount:number; status:string; created_at:string; }
interface Comment { id:string; message:string; created_at:string; sender_type?:string; project_id?:string|null; }
interface Photo { id:string; url?:string; public_url?:string; publicUrl?:string; caption?:string; created_at:string; }
interface Co { company_name:string|null; logo_url:string|null; phone:string|null; email:string|null; address_line1:string|null; address_line2?:string|null; parish?:string|null; tagline?:string|null; city?:string|null; watermark_url?:string|null; watermark_enabled?:boolean|null; watermark_opacity?:number|null; watermark_size?:number|null; }

const fmt = (n:number) => new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD"}).format(n);
// Date-only values (YYYY-MM-DD) are calendar dates: parsing them as UTC midnight and
// formatting in Jamaica time showed them a day early, so format those in UTC (no shift).
// Full timestamps display in Jamaica time.
const fmtDate = (d:string|null) => {
  if(!d)return "…";
  const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
  const dt=m?new Date(Date.UTC(+m[1],+m[2]-1,+m[3])):new Date(d);
  return dt.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric",timeZone:m?"UTC":"America/Jamaica"});
};
const timeAgo = (d:string) => { const s=Math.floor((Date.now()-new Date(d).getTime())/1000); if(s<60)return "just now"; if(s<3600)return `${Math.floor(s/60)}m ago`; if(s<86400)return `${Math.floor(s/3600)}h ago`; return fmtDate(d); };

// Whole-dollar JMD, matching how the printed proposal shows estimate prices.
const fmt0 = (n:number) => new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD",minimumFractionDigits:0,maximumFractionDigits:0}).format(n);
// Same date-only handling as fmtDate, but keeps the weekday format Site Updates uses.
const fmtLogDay = (d:string) => {
  const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
  const dt=m?new Date(Date.UTC(+m[1],+m[2]-1,+m[3])):new Date(d);
  return dt.toLocaleDateString("en-JM",{weekday:"short",month:"short",day:"numeric",timeZone:m?"UTC":"America/Jamaica"});
};

// Read-only view of a shared estimate snapshot (client-facing prices only). A summary
// snapshot has no line items at all, so none are rendered for it. No print/share/copy.
function PortalEstimateCard({es}:{es:any}) {
  const sn=es?.snapshot||{};
  const full=sn.detail_level==="full";
  const cats:any[]=Array.isArray(sn.categories)?sn.categories:[];
  const n=(v:any)=>Number(v)||0;
  const th:React.CSSProperties={fontSize:10,fontWeight:700,color:"#64748b",textTransform:"uppercase",padding:"6px 8px",borderBottom:"1px solid #e2e8f0",whiteSpace:"nowrap"};
  const td:React.CSSProperties={fontSize:12,color:"#334155",padding:"7px 8px",borderBottom:"1px solid #f1f5f9",verticalAlign:"top"};
  return <div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:12,marginBottom:4}}>
      <div style={{fontSize:15,fontWeight:700,color:"#0f172a"}}>{sn.title||es?.title||"Estimate"}</div>
      <span style={{fontSize:10,padding:"3px 10px",borderRadius:20,fontWeight:700,background:"rgba(59,130,246,0.12)",color:"#2563eb",whiteSpace:"nowrap"}}>v{sn.version??es?.version??1}</span>
    </div>
    <div style={{fontSize:11,color:"#64748b"}}>Prepared for {sn.client_name||"you"}{sn.prepared_date?` · ${fmtDate(sn.prepared_date)}`:""}</div>
    {sn.project_name&&<div style={{fontSize:11,color:"#64748b",marginTop:2}}>Project: {sn.project_name}</div>}
    {sn.valid_until&&<div style={{fontSize:11,color:"#64748b",marginTop:2}}>Valid until {fmtDate(sn.valid_until)}</div>}
    <div style={{marginTop:14}}>
      {cats.length===0&&<div style={{fontSize:12,color:"#94a3b8"}}>No items to show.</div>}
      {!full&&cats.map((c:any,i:number)=><div key={i} style={{display:"flex",justifyContent:"space-between",gap:12,padding:"9px 0",borderBottom:"1px solid #f1f5f9"}}>
        <span style={{fontSize:13,color:"#334155",fontWeight:600}}>{c?.name}</span>
        <span style={{fontSize:13,color:"#0f172a",fontWeight:700}}>{fmt0(n(c?.total))}</span>
      </div>)}
      {full&&cats.map((c:any,i:number)=><div key={i} style={{marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",gap:12,padding:"6px 0"}}>
          <span style={{fontSize:13,fontWeight:700,color:"#0f172a"}}>{c?.name}</span>
          <span style={{fontSize:13,fontWeight:700,color:"#0f172a"}}>{fmt0(n(c?.total))}</span>
        </div>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",minWidth:420}}>
            <thead><tr>
              <th style={{...th,textAlign:"left"}}>Item</th>
              <th style={{...th,textAlign:"right"}}>Qty</th>
              <th style={{...th,textAlign:"left"}}>Unit</th>
              <th style={{...th,textAlign:"right"}}>Unit price</th>
              <th style={{...th,textAlign:"right"}}>Amount</th>
            </tr></thead>
            <tbody>
              {(Array.isArray(c?.items)?c.items:[]).map((it:any,j:number)=><tr key={j}>
                <td style={td}><div style={{fontWeight:600}}>{it?.item}</div></td>
                <td style={{...td,textAlign:"right"}}>{n(it?.qty).toLocaleString(undefined,{maximumFractionDigits:4})}</td>
                <td style={td}>{it?.unit}</td>
                <td style={{...td,textAlign:"right"}}>{fmt(n(it?.rate))}</td>
                <td style={{...td,textAlign:"right",fontWeight:600}}>{fmt0(n(it?.amount))}</td>
              </tr>)}
            </tbody>
          </table>
        </div>
      </div>)}
    </div>
    <div style={{marginTop:6,paddingTop:10,borderTop:"2px solid #e2e8f0"}}>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:"#475569",padding:"3px 0"}}><span>Subtotal</span><span>{fmt0(n(sn.subtotal))}</span></div>
      {n(sn.contingency_amount)>0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:"#475569",padding:"3px 0"}}><span>Contingency allowance</span><span>{fmt0(n(sn.contingency_amount))}</span></div>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:6,padding:"12px 14px",background:"#0f172a",borderRadius:12}}>
        <span style={{fontSize:13,fontWeight:700,color:"#ffffff"}}>Total</span>
        <span style={{fontSize:17,fontWeight:800,color:"#ffffff"}}>{fmt0(n(sn.total))}</span>
      </div>
    </div>
    {sn.company?.name&&<div style={{fontSize:10,color:"#94a3b8",marginTop:10}}>Prepared by {sn.company.name}</div>}
  </div>;
}

function ProgressRing({pct}:{pct:number}) {
  const r=28,circ=2*Math.PI*r;
  const [off,setOff]=useState(circ);
  useEffect(()=>{setTimeout(()=>setOff(circ-(pct/100)*circ),400);},[pct]);
  return <svg width={72} height={72} style={{transform:"rotate(-90deg)"}}>
    <circle cx={36} cy={36} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={6}/>
    <circle cx={36} cy={36} r={r} fill="none" stroke="#3b82f6" strokeWidth={6} strokeDasharray={circ} strokeDashoffset={off} strokeLinecap="round" style={{transition:"stroke-dashoffset 1.2s ease"}}/>
  </svg>;
}

function Stars({value,onChange}:{value:number;onChange:(n:number)=>void}) {
  const [hover,setHover]=useState(0);
  return <div style={{display:"flex",gap:4,justifyContent:"center"}}>
    {[1,2,3,4,5].map(s=><button key={s} onMouseEnter={()=>setHover(s)} onMouseLeave={()=>setHover(0)} onClick={()=>onChange(s)} style={{fontSize:34,background:"none",border:"none",cursor:"pointer",color:s<=(hover||value)?"#f59e0b":"#cbd5e1",transition:"all 0.15s",transform:s<=(hover||value)?"scale(1.2)":"scale(1)"}}>★</button>)}
  </div>;
}

function Toast({msg,type="success",onDone}:{msg:string;type?:"success"|"error";onDone:()=>void}) {
  useEffect(()=>{const t=setTimeout(onDone,3000);return()=>clearTimeout(t);},[]);
  return <div style={{position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",background:type==="success"?"#1e293b":"#450a0a",border:`1px solid ${type==="success"?"rgba(34,197,94,0.3)":"rgba(239,68,68,0.3)"}`,borderRadius:12,padding:"12px 20px",color:type==="success"?"#4ade80":"#fca5a5",fontSize:13,fontWeight:600,zIndex:9999,boxShadow:"0 8px 32px rgba(0,0,0,0.5)",whiteSpace:"nowrap"}}>
    {type==="success"?"?":"?"} {msg}
  </div>;
}
function AuthScreen({client,company,mode,token,onSuccess,contact}:{client:Client;company:Co|null;mode:"setup"|"login";token:string;onSuccess:()=>void;contact?:PortalContact|null}) {
  // With a contact this is a field officer's own invite link: their own actions, greeting and session key. Otherwise unchanged.
  const sessionKey=contact?`portal_contact_${contact.id}`:`portal_${client.id}`;
  const setupAction=contact?"contactLinkSetup":"magicLinkSetup";
  const loginAction=contact?"contactLinkLogin":"magicLinkLogin";
  const displayName=contact?contact.name:(client.contact_name||client.name);
  const loginEmail=contact?contact.email:(client.portal_email||client.email);
  const [email,setEmail]=useState((contact?contact.email:(client.portal_email||client.email))||"");
  const [password,setPassword]=useState("");
  const [confirm,setConfirm]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");
  const [showPass,setShowPass]=useState(false);
  const [view,setView]=useState<"auth"|"forgot"|"resetSent">("auth");
  const [forgotLoading,setForgotLoading]=useState(false);
  const [forgotError,setForgotError]=useState("");

  // Identity for both actions below is anchored on the magic-link token
  // (portalToken), not the typed email — see client-portal-login's header
  // comment for why: keying by email here would let someone set up a
  // *different* client's account by typing their email during this one's
  // setup flow.
  async function handleSetup() {
    if(!email.trim()){setError("Please enter your email address.");return;}
    if(password.length<6){setError("Password must be at least 6 characters.");return;}
    if(password!==confirm){setError("Passwords do not match.");return;}
    setLoading(true);setError("");
    const {data,error:invokeError}=await supabase.functions.invoke("client-portal-login",
      {body:{action:setupAction,portalToken:token,email:email.trim(),password}});
    if(invokeError||data?.error){setError(await functionErrorMessage(invokeError,data,invokeError?.message||"Failed to set up account."));setLoading(false);return;}
    localStorage.setItem(sessionKey,data.sessionToken);
    onSuccess();setLoading(false);
  }

  async function handleForgotPassword() {
    setForgotLoading(true);
    setForgotError("");
    try {
      const { data, error: invokeError } = await supabase.functions.invoke(
        "client-password-reset",
        { body: { action: "request", email: email.trim() } }
      );
      if (invokeError) {
        setForgotError(await functionErrorMessage(invokeError, data, invokeError.message || "Failed to send reset email."));
        setForgotLoading(false);
        return;
      }
      if (data?.error) {
        setForgotError(String(data.error));
        setForgotLoading(false);
        return;
      }
      setView("resetSent");
    } catch {
      setForgotError("Something went wrong. Please try again.");
    }
    setForgotLoading(false);
  }

  async function handleLogin() {
    if(!password){setError("Please enter your password.");return;}
    setLoading(true);setError("");
    const {data,error:invokeError}=await supabase.functions.invoke("client-portal-login",
      {body:{action:loginAction,portalToken:token,password}});
    if(invokeError||data?.error){setError(await functionErrorMessage(invokeError,data,invokeError?.message||"Login failed. Please try again."));setLoading(false);return;}
    localStorage.setItem(sessionKey,data.sessionToken);
    onSuccess();setLoading(false);
  }

  const S={
    page:{minHeight:"100vh",background:"#f8fafc",display:"flex",alignItems:"center",justifyContent:"center",padding:20} as React.CSSProperties,
    card:{width:"100%",maxWidth:400,background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:20,padding:28,boxShadow:"0 10px 30px rgba(0,0,0,0.08)"} as React.CSSProperties,
    input:{width:"100%",background:"#ffffff",border:"1px solid #cbd5e1",borderRadius:10,padding:"11px 14px",fontSize:14,color:"#0f172a",boxSizing:"border-box" as "border-box",outline:"none"},
    label:{fontSize:12,color:"#64748b",fontWeight:600,display:"block",marginBottom:6} as React.CSSProperties,
    btn:{width:"100%",padding:"13px 0",background:"#0891b2",border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer",marginTop:4} as React.CSSProperties,
  };

  return <div style={S.page}>
    <div style={{width:"100%",maxWidth:400}}>
      <div style={{textAlign:"center",marginBottom:28}}>
        <PortalBrandLogo logoUrl={company?.logo_url} companyName={company?.company_name}/>
        <div style={{fontSize:17,fontWeight:800,color:"#0f172a",marginBottom:3}}>{companyDisplayName(company?.company_name)}</div>
        <div style={{fontSize:12,color:"#64748b"}}>{contact?`${contact.client_name||"Client"} · Field officer portal`:"Client Portal"}</div>
      </div>
      <div style={S.card}>
        <h2 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 6px"}}>{mode==="setup"?"Activate Your Account":"Welcome Back"}</h2>
        <p style={{fontSize:13,color:"#475569",margin:"0 0 20px",lineHeight:1.6}}>
          {mode==="setup"?`Hello ${displayName}! Create a password to access your project portal.`:`Sign in to view your project updates.`}
        </p>
        {error&&<div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:10,padding:"10px 14px",fontSize:13,color:"#dc2626",marginBottom:14}}>⚠ {error}</div>}
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {mode==="setup"&&<div>
            <label style={S.label}>EMAIL ADDRESS</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="your@email.com" style={S.input}/>
          </div>}
          {mode==="login"&&<div style={{background:"#eff6ff",border:"1px solid #bfdbfe",borderRadius:10,padding:"10px 14px",fontSize:13,color:"#1d4ed8"}}>
            📧 Signing in as: <strong>{loginEmail}</strong>
          </div>}
          <div>
            <label style={S.label}>{mode==="setup"?"CREATE PASSWORD":"PASSWORD"}</label>
            <div style={{position:"relative"}}>
              <input value={password} onChange={e=>setPassword(e.target.value)} type={showPass?"text":"password"}
                placeholder={mode==="setup"?"Minimum 6 characters":"Enter your password"}
                onKeyDown={e=>e.key==="Enter"&&(mode==="setup"?handleSetup():handleLogin())}
                style={{...S.input,paddingRight:44}}/>
              <button onClick={()=>setShowPass(!showPass)} style={{position:"absolute",right:12,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",color:"#475569",cursor:"pointer",fontSize:16}}>
                {showPass?"🙈":"👁"}
              </button>
            </div>
          </div>
          {mode==="setup"&&<div>
            <label style={S.label}>CONFIRM PASSWORD</label>
            <input value={confirm} onChange={e=>setConfirm(e.target.value)} type={showPass?"text":"password"}
              placeholder="Repeat your password" onKeyDown={e=>e.key==="Enter"&&handleSetup()} style={S.input}/>
          </div>}
          <button onClick={mode==="setup"?handleSetup:handleLogin} disabled={loading} style={{...S.btn,opacity:loading?0.6:1}}>
            {loading?"Please wait…":mode==="setup"?"Activate Account ?":"Sign In ?"}
          </button>
          {mode==="login"&&view==="auth"&&(
            <button onClick={()=>{setView("forgot");setForgotError("");}}
              style={{width:"100%",marginTop:12,background:"transparent",border:"none",color:"#0284c7",fontSize:13,fontWeight:600,cursor:"pointer"}}>
              Forgot password?
            </button>
          )}
          {view==="forgot"&&(
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:15,fontWeight:700,color:"#0f172a",marginBottom:8}}>Reset your password</div>
              <div style={{fontSize:13,color:"#475569",marginBottom:16}}>
                We'll send a reset link to <strong>{email}</strong>
              </div>
              {forgotError&&(
                <div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:8,padding:"8px 12px",fontSize:12,color:"#dc2626",marginBottom:12}}>
                  {forgotError}
                </div>
              )}
              <button onClick={handleForgotPassword} disabled={forgotLoading}
                style={{width:"100%",padding:"13px 0",background:"#d97706",border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer"}}>
                {forgotLoading?"Sending...":"Send Reset Link"}
              </button>
              <button onClick={()=>setView("auth")}
                style={{width:"100%",marginTop:10,background:"transparent",border:"none",color:"#64748b",fontSize:13,cursor:"pointer"}}>
                Back to login
              </button>
            </div>
          )}
          {view==="resetSent"&&(
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:15,fontWeight:700,color:"#0f172a",marginBottom:8}}>Check your email</div>
              <div style={{fontSize:13,color:"#475569",marginBottom:16}}>
                If an account exists for <strong>{email}</strong>, a reset link is on its way.
              </div>
              <button onClick={()=>setView("auth")}
                style={{width:"100%",padding:"13px 0",background:"#0891b2",border:"none",borderRadius:12,color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer"}}>
                Back to login
              </button>
            </div>
          )}
        </div>
      </div>
      <div style={{textAlign:"center",marginTop:16,fontSize:11,color:"#1e293b"}}>🔒 Secured by {companyDisplayName(company?.company_name)}</div>
    </div>
  </div>;
}

// ---- Contract viewing (read-only) ----------------------------------------------------------
// The contract is shown with the SAME shared document staff see (src/components/ContractDocument.tsx), so
// a signed contract looks identical to everyone. The internal `notes` field is never shown.
// The contract's payment schedule comes from the session-validated get_portal_contract_schedule
// function (the table itself is never read from the browser). Any failure just means "no schedule":
// nothing is shown and no error is surfaced to the client.
function useContractSchedule(contractId:string|undefined,sessionToken:string|null):any[]{
  const [rows,setRows]=useState<any[]>([]);
  useEffect(()=>{
    let cancelled=false;
    (async()=>{
      try{
        if(!contractId||!sessionToken){if(!cancelled)setRows([]);return;}
        const {data,error}=await supabase.rpc("get_portal_contract_schedule",{p_session_token:sessionToken,p_contract_id:contractId});
        if(error||!Array.isArray(data)){if(!cancelled)setRows([]);return;}
        const sorted=[...data].sort((a:any,b:any)=>(Number(a?.sort_order)||0)-(Number(b?.sort_order)||0));
        if(!cancelled)setRows(sorted);
      }catch{if(!cancelled)setRows([]);}
    })();
    return()=>{cancelled=true;};
  },[contractId,sessionToken]);
  return rows;
}
// Contract signatures are stored as storage paths in a private bucket. Portal visitors have no Supabase session, so the
// portal-contract-signature-urls function (session-validated) signs them. Older contracts hold a permanent public URL,
// which is used as-is, and a signature that was JUST saved arrives with a fresh signed URL (client_signature_src) so
// it shows without another request. force = true (used right before printing) always asks for fresh URLs.
async function resolvePortalSignatures(contract:any,sessionToken:string|null,force:boolean):Promise<SignatureSrcs>{
  const out:SignatureSrcs={contractor:null,client:null};
  const sides:Array<["contractor"|"client",string|null|undefined,string|null|undefined]>=[
    ["contractor",contract?.contractor_signature_url,contract?.contractor_signature_src],
    ["client",contract?.client_signature_url,contract?.client_signature_src],
  ];
  const needServer:Array<"contractor"|"client">=[];
  for(const [side,stored,pre] of sides){
    if(!stored)continue;
    if(isLegacySignatureUrl(stored)){out[side]=String(stored);continue;}
    if(!force&&pre){out[side]=pre;continue;}
    needServer.push(side);
  }
  if(needServer.length&&sessionToken&&contract?.id){
    const {data,error}=await supabase.functions.invoke("portal-contract-signature-urls",{body:{sessionToken,contractId:contract.id}});
    if(!error&&data&&!data.error){
      if(needServer.includes("contractor"))out.contractor=data.contractorSignatureUrl||null;
      if(needServer.includes("client"))out.client=data.clientSignatureUrl||null;
    }
  }
  return out;
}
// Read-only contract viewer. Print / Save as PDF is offered ONLY once the client has signed; an unsigned
// contract cannot be printed or downloaded from here.
function PortalContractViewer({contract,company,sessionToken,onClose}:{contract:any;company:Co|null;sessionToken:string|null;onClose:()=>void}) {
  const signed=!!contract.client_signed_at;
  const schedule=useContractSchedule(contract.id,sessionToken);
  const {srcs:sigSrcs,refresh:refreshSigs}=useContractSignatureSrcs(contract,(c,o)=>resolvePortalSignatures(c,sessionToken,o.force));
  const [printing,setPrinting]=useState(false);
  function printCopy(){
    if(printing)return;
    setPrinting(true);
    // Re-signs the signatures right before printing (a viewer left open for a while must not print an expired link), then opens the in-app print preview.
    printContractDocumentFresh({variant:"print",title:`${contract.contract_number||"Contract"} - ${contract.contract_name||""}`,watermark:watermarkFromCompany(company),tagline:company?.tagline,refreshSignatures:refreshSigs})
      .catch(()=>alert("Could not prepare the contract for printing. Please try again."))
      .finally(()=>setPrinting(false));
  }
  return <div style={{position:"fixed",inset:0,background:"rgba(15,23,42,0.6)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:16}} onClick={onClose}>
    <div onClick={e=>e.stopPropagation()} style={{background:"#f8fafc",borderRadius:16,width:"100%",maxWidth:900,maxHeight:"92vh",display:"flex",flexDirection:"column",boxShadow:"0 20px 60px rgba(0,0,0,0.35)"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,padding:"14px 18px",borderBottom:"1px solid #e2e8f0"}}>
        <div>
          <div style={{fontSize:14,fontWeight:700,color:"#0f172a"}}>Contract</div>
          <div style={{fontSize:11,color:"#64748b"}}>{contract.contract_name}{contract.contract_number?` · #${contract.contract_number}`:""}</div>
        </div>
        <button onClick={onClose} aria-label="Close" style={{background:"none",border:"none",fontSize:22,lineHeight:1,color:"#64748b",cursor:"pointer",padding:4}}>×</button>
      </div>
      <div style={{flex:1,minHeight:0,overflowY:"auto",background:"#f3f4f6",padding:16}}>
        <ContractDocument contract={contract} schedule={schedule} company={company} signRecord={null} contractorSignatureSrc={sigSrcs.contractor} clientSignatureSrc={sigSrcs.client}/>
      </div>
      <div style={{display:"flex",gap:8,padding:"12px 18px",borderTop:"1px solid #e2e8f0"}}>
        {signed&&<button onClick={printCopy} disabled={printing} style={{flex:1.4,padding:"11px 0",background:"#0891b2",border:"none",borderRadius:10,color:"#fff",fontSize:13,fontWeight:700,cursor:printing?"wait":"pointer",opacity:printing?0.7:1}}>{printing?"Preparing…":"Print / Save as PDF"}</button>}
        <button onClick={onClose} style={{flex:1,padding:"11px 0",background:"#ffffff",border:"1px solid #cbd5e1",borderRadius:10,color:"#475569",fontSize:13,fontWeight:600,cursor:"pointer"}}>Close</button>
      </div>
    </div>
  </div>;
}
function SignatureModal({contract,client,company,sessionToken,saving,onSign,onCancel}:{contract:any;client:any;company?:any;sessionToken?:string|null;saving:boolean;onSign:(dataUrl:string)=>void;onCancel:()=>void}){
  const canvasRef=React.useRef<HTMLCanvasElement|null>(null);
  const [hasDrawn,setHasDrawn]=React.useState(false);
  const [mode,setMode]=React.useState<"draw"|"upload">("draw");
  const [uploadPreview,setUploadPreview]=React.useState<string|null>(null);
  const drawing=React.useRef(false);
  // The contract is read first, then signed; Submit stays disabled until the agreement box is ticked.
  const [step,setStep]=React.useState<"read"|"sign">("read");
  const [agreed,setAgreed]=React.useState(false);
  const schedule=useContractSchedule(contract?.id,sessionToken||null);
  const {srcs:sigSrcs}=useContractSignatureSrcs(contract,(c,o)=>resolvePortalSignatures(c,sessionToken||null,o.force));

  function getPos(e:any,canvas:HTMLCanvasElement){
    const rect=canvas.getBoundingClientRect();
    const clientX=e.touches?e.touches[0].clientX:e.clientX;
    const clientY=e.touches?e.touches[0].clientY:e.clientY;
    return{x:clientX-rect.left,y:clientY-rect.top};
  }
  function start(e:any){
    drawing.current=true;
    const canvas=canvasRef.current; if(!canvas)return;
    const ctx=canvas.getContext("2d"); if(!ctx)return;
    const{x,y}=getPos(e,canvas);
    ctx.beginPath();ctx.moveTo(x,y);
  }
  function move(e:any){
    if(!drawing.current)return;
    const canvas=canvasRef.current; if(!canvas)return;
    const ctx=canvas.getContext("2d"); if(!ctx)return;
    const{x,y}=getPos(e,canvas);
    ctx.lineTo(x,y);ctx.strokeStyle="#1a1a1a";ctx.lineWidth=2.5;ctx.lineCap="round";ctx.stroke();
    setHasDrawn(true);
  }
  function end(){drawing.current=false;}
  function clear(){
    const canvas=canvasRef.current; if(!canvas)return;
    const ctx=canvas.getContext("2d"); if(!ctx)return;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    setHasDrawn(false);
  }
  function submit(){
    if(mode==="upload"&&uploadPreview){onSign(uploadPreview);return;}
    const canvas=canvasRef.current; if(!canvas||!hasDrawn)return;
    onSign(canvas.toDataURL("image/png"));
  }
  function handleUpload(e:any){
    const f=e.target.files?.[0]; if(!f)return;
    const reader=new FileReader();
    reader.onload=ev=>{if(ev.target?.result)setUploadPreview(ev.target.result as string);};
    reader.readAsDataURL(f);
  }

  const canSubmit=(mode==="draw"?hasDrawn:!!uploadPreview)&&agreed;

  if(step==="read")return(
    <div style={{background:"#0d1117",border:"1px solid rgba(255,255,255,0.1)",borderRadius:16,padding:20,width:"100%",maxWidth:700,maxHeight:"92vh",display:"flex",flexDirection:"column"}}>
      <div style={{fontWeight:700,fontSize:15,color:"#f1f5f9",marginBottom:4}}>Read Contract</div>
      <div style={{fontSize:12,color:"#64748b",marginBottom:12}}>Please read the whole contract before you sign it.</div>
      <div style={{flex:1,minHeight:0,overflowY:"auto",borderRadius:12,background:"#f3f4f6",padding:12}}>
        <ContractDocument contract={contract} schedule={schedule} company={company||null} signRecord={null} contractorSignatureSrc={sigSrcs.contractor} clientSignatureSrc={sigSrcs.client}/>
      </div>
      <div style={{display:"flex",gap:8,marginTop:14}}>
        <button onClick={onCancel} style={{flex:1,padding:"10px 0",borderRadius:10,border:"1px solid rgba(255,255,255,0.1)",background:"transparent",color:"#94a3b8",fontSize:13,fontWeight:600,cursor:"pointer"}}>Cancel</button>
        <button onClick={()=>setStep("sign")} style={{flex:1.4,padding:"10px 0",borderRadius:10,border:"none",background:"#22c55e",color:"white",fontSize:13,fontWeight:700,cursor:"pointer"}}>Continue to sign</button>
      </div>
    </div>
  );

  return(
    <div style={{background:"#0d1117",border:"1px solid rgba(255,255,255,0.1)",borderRadius:16,padding:20,width:"100%",maxWidth:420,maxHeight:"90vh",overflowY:"auto"}}>
      <div style={{fontWeight:700,fontSize:15,color:"#f1f5f9",marginBottom:4}}>Sign Contract</div>
      <div style={{fontSize:12,color:"#64748b",marginBottom:14}}>{contract.contract_name} · {contract.contract_number}</div>

      <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:10,padding:12,marginBottom:14,maxHeight:160,overflowY:"auto",fontSize:11,color:"#94a3b8",lineHeight:1.6}}>
        By signing below, I, <strong style={{color:"#f1f5f9"}}>{client?.contact_name||client?.name}</strong>, agree to the terms, payment schedule, and scope of work outlined in this contract.
      </div>

      <div style={{display:"flex",gap:8,marginBottom:14}}>
        <button onClick={()=>{setMode("draw");setUploadPreview(null);}} style={{flex:1,padding:"8px 0",borderRadius:10,border:"1px solid",fontSize:12,fontWeight:700,cursor:"pointer",background:mode==="draw"?"#3b82f6":"transparent",borderColor:mode==="draw"?"#3b82f6":"rgba(255,255,255,0.1)",color:mode==="draw"?"#fff":"#94a3b8"}}>✍ Draw Signature</button>
        <button onClick={()=>{setMode("upload");clear();}} style={{flex:1,padding:"8px 0",borderRadius:10,border:"1px solid",fontSize:12,fontWeight:700,cursor:"pointer",background:mode==="upload"?"#3b82f6":"transparent",borderColor:mode==="upload"?"#3b82f6":"rgba(255,255,255,0.1)",color:mode==="upload"?"#fff":"#94a3b8"}}>📷 Upload / Camera</button>
      </div>

      {mode==="draw"&&<>
        <div style={{fontSize:11,color:"#64748b",marginBottom:6}}>Draw your signature below:</div>
        <canvas ref={canvasRef} width={360} height={140}
          onMouseDown={start} onMouseMove={move} onMouseUp={end} onMouseLeave={end}
          onTouchStart={start} onTouchMove={move} onTouchEnd={end}
          style={{width:"100%",height:140,background:"white",borderRadius:10,border:"2px dashed rgba(255,255,255,0.15)",touchAction:"none",cursor:"crosshair"}}/>
      </>}

      {mode==="upload"&&<>
        <div style={{fontSize:11,color:"#64748b",marginBottom:8}}>Take a photo of your signature or upload an image:</div>
        <label style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:8,padding:20,borderRadius:12,border:"2px dashed rgba(255,255,255,0.15)",cursor:"pointer",background:"rgba(255,255,255,0.02)",minHeight:120}}>
          {uploadPreview
            ?<img src={uploadPreview} style={{maxHeight:120,maxWidth:"100%",borderRadius:8,objectFit:"contain"}}/>
            :<><div style={{fontSize:32}}>📷</div><div style={{fontSize:12,color:"#64748b",textAlign:"center"}}>Tap to take photo or choose file<br/><span style={{fontSize:11,color:"#334155"}}>JPG, PNG accepted</span></div></>}
          <input type="file" accept="image/*" capture="environment" onChange={handleUpload} style={{display:"none"}}/>
        </label>
        {uploadPreview&&<button onClick={()=>setUploadPreview(null)} style={{marginTop:8,width:"100%",padding:"6px 0",borderRadius:8,border:"1px solid rgba(239,68,68,0.3)",background:"transparent",color:"#ef4444",fontSize:12,cursor:"pointer"}}>Remove Photo</button>}
      </>}

      <label style={{display:"flex",alignItems:"flex-start",gap:8,marginTop:14,fontSize:12,color:"#cbd5e1",lineHeight:1.5,cursor:"pointer"}}>
        <input type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)} style={{marginTop:2,width:16,height:16,accentColor:"#22c55e",cursor:"pointer"}}/>
        <span>I have read and agree to this contract</span>
      </label>
      <button onClick={()=>setStep("read")} style={{marginTop:8,background:"none",border:"none",padding:0,color:"#60a5fa",fontSize:11,cursor:"pointer"}}>&larr; Read the contract again</button>

      <div style={{display:"flex",gap:8,marginTop:14}}>
        {mode==="draw"&&<button onClick={clear} style={{flex:1,padding:"10px 0",borderRadius:10,border:"1px solid rgba(255,255,255,0.1)",background:"transparent",color:"#94a3b8",fontSize:13,fontWeight:600,cursor:"pointer"}}>Clear</button>}
        <button onClick={onCancel} style={{flex:1,padding:"10px 0",borderRadius:10,border:"1px solid rgba(255,255,255,0.1)",background:"transparent",color:"#94a3b8",fontSize:13,fontWeight:600,cursor:"pointer"}}>Cancel</button>
        <button onClick={submit} disabled={!canSubmit||saving} style={{flex:1.4,padding:"10px 0",borderRadius:10,border:"none",background:canSubmit?"#22c55e":"rgba(255,255,255,0.06)",color:canSubmit?"white":"#475569",fontSize:13,fontWeight:700,cursor:canSubmit?"pointer":"not-allowed"}}>{saving?"Saving…":"Sign & Submit"}</button>
      </div>
    </div>
  );
}

// Contract signing goes through the portal-sign-contract edge function, which only accepts a small
// PNG. The drawn signature is already one; a photo uploaded from a phone (any image type, often
// several MB) is redrawn smaller as a PNG first. If that fails the original is sent unchanged
// and the server explains what is wrong.
async function normalizeSignature(dataUrl:string):Promise<string>{
  try{
    if(dataUrl.startsWith("data:image/png")&&dataUrl.length<600000)return dataUrl;
    const img=await new Promise<HTMLImageElement>((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=()=>rej(new Error("image"));i.src=dataUrl;});
    const scale=Math.min(1,800/Math.max(img.width,img.height));
    const cv=document.createElement("canvas");
    cv.width=Math.max(1,Math.round(img.width*scale));cv.height=Math.max(1,Math.round(img.height*scale));
    const ctx=cv.getContext("2d");
    if(!ctx)return dataUrl;
    ctx.fillStyle="#ffffff";ctx.fillRect(0,0,cv.width,cv.height);
    ctx.drawImage(img,0,0,cv.width,cv.height);
    return cv.toDataURL("image/png");
  }catch{return dataUrl;}
}

export default function ClientPortalPage() {
  useForceLightPage(); // the login/setup/invite screens and the portal are always light, whatever the device's dark-mode setting
  // Two distinct, unrelated ways to arrive here: /portal/:token is the
  // magic-link flow (token compared against clients.portal_token — an
  // intentional separate feature, left as-is below); /client-portal/session/
  // :sessionToken is the email+password flow from ClientLoginPage.tsx,
  // compared against client_portal_sessions.session_token instead. They
  // used to collide on one route (/client-portal/:clientId) with a param
  // named "token" that the session flow never actually populated correctly.
  const {token}=useParams<{token:string}>();
  const {sessionToken}=useParams<{sessionToken:string}>();
  // /portal/contact/:contactToken: a field officer's own invite link (their personal login, scoped to their projects).
  const {contactToken}=useParams<{contactToken:string}>();
  const [authState,setAuthState]=useState<AuthState>("loading");
  const [client,setClient]=useState<Client|null>(null);
  // Who is looking, from get_portal_data's viewer block. Missing/null means the client's own (manager) login, exactly as before.
  const [viewer,setViewer]=useState<PortalViewer|null>(null);
  const [contactInfo,setContactInfo]=useState<PortalContact|null>(null);
  // The real credential client_comments' new RPC functions validate —
  // NOT the magic-link `token` param. Both login paths (magic-link and
  // email+password) converge on a client_portal_sessions.session_token
  // before loadData() ever runs; see the lock-down migration's own header
  // comment for the full reasoning. Threaded through explicitly to
  // loadData() at every call site below rather than read from this state
  // inside loadData() itself, to avoid a stale-closure read immediately
  // after the setState call that establishes it.
  const [portalSessionToken,setPortalSessionToken]=useState<string|null>(null);
  const [project,setProject]=useState<Project|null>(null);
  const [company,setCompany]=useState<Co|null>(null);
  const [invoices,setInvoices]=useState<Invoice[]>([]);
  const [changes,setChanges]=useState<ChangeOrder[]>([]);
  const [comments,setComments]=useState<Comment[]>([]);
  const [photos,setPhotos]=useState<Photo[]>([]);
  const [contracts,setContracts]=useState<any[]>([]);
  const [estimates,setEstimates]=useState<any[]>([]);
  const [signingContract,setSigningContract]=useState<any|null>(null);
  const [savingSignature,setSavingSignature]=useState(false);
  const [viewingContract,setViewingContract]=useState<any|null>(null);
  const [tab,setTab]=useState<Tab>("overview");
  const [progress,setProgress]=useState(0);
  const [newComment,setNewComment]=useState("");
  const [rating,setRating]=useState(0);
  const [reviewText,setReviewText]=useState("");
  const [reviewedProjectIds,setReviewedProjectIds]=useState<string[]>([]);
  const [toast,setToast]=useState<{msg:string;type:"success"|"error"}|null>(null);
  const [lightbox,setLightbox]=useState<Photo|null>(null);
  const [respondingTo,setRespondingTo]=useState<string|null>(null);
  const [errorMsg,setErrorMsg]=useState("");
  const [dailyLogs,setDailyLogs]=useState<any[]>([]);
  const [logsLoading,setLogsLoading]=useState(true);
  const [sitePhotos,setSitePhotos]=useState<any[]>([]);
  const [photosLoading,setPhotosLoading]=useState(true);
  const [selectedPhoto,setSelectedPhoto]=useState<any|null>(null);
  // Project picker: shown only when the client has 2+ projects. "projects" and the server's choice of project
  // come from get_portal_data; selectedProjectId is what the picker highlights and what the per-project
  // lists, messages, review and activity events use. projectGate makes only the latest switch apply.
  const [projects,setProjects]=useState<PortalProject[]>([]);
  const [selectedProjectId,setSelectedProjectId]=useState<string|null>(null);
  const [switchingProject,setSwitchingProject]=useState(false);
  const projectGate=React.useRef(createRequestGate());
  const multiProject=hasMultipleProjects(projects);
  const isContact=viewer?.kind==="contact";
  const activeProjectId=selectedProjectId||project?.id||null;
  const selectedProjectName=projects.find(p=>p.id===activeProjectId)?.name||project?.name||"";
  const reviewSubmitted=!!activeProjectId&&reviewedProjectIds.includes(activeProjectId);
  // Invoices, estimates, contracts and messages come back for the whole client; show the selected project's
  // (plus any with no project). A single-project client is never filtered, so nothing changes for them.
  const visInvoices=filterByProject(invoices,activeProjectId,multiProject);
  const visEstimates=filterByProject(estimates,activeProjectId,multiProject);
  const visContracts=filterByProject(contracts,activeProjectId,multiProject);
  const visComments=filterByProject(comments,activeProjectId,multiProject);

  useEffect(()=>{
    if(sessionToken)checkAuthViaSession(sessionToken);
    else if(contactToken)checkContactAuth();
    else if(token)checkAuth();
  },[token,sessionToken,contactToken]);

  // Portal activity logging (client_portal_activity) — fire-and-forget, see
  // src/lib/portalActivity.ts. These effects only observe existing state; they
  // never change it, and skip the initial render (no session token yet).
  useEffect(()=>{
    if(portalSessionToken)logPortalEvent(portalSessionToken,"tab_view",{entityType:"tab",entityId:tab,projectId:activeProjectId});
  },[tab]);
  useEffect(()=>{
    if(lightbox)logPortalEvent(portalSessionToken,"photo_view",{entityType:"photo",entityId:lightbox.id,projectId:activeProjectId});
  },[lightbox]);
  useEffect(()=>{
    if(selectedPhoto)logPortalEvent(portalSessionToken,"photo_view",{entityType:"photo",entityId:selectedPhoto.id,projectId:activeProjectId});
  },[selectedPhoto]);
  useEffect(()=>{
    if(signingContract)logPortalEvent(portalSessionToken,"contract_view",{entityType:"contract",entityId:signingContract.id,projectId:signingContract.project_id??activeProjectId});
  },[signingContract]);
  useEffect(()=>{
    if(viewingContract)logPortalEvent(portalSessionToken,"contract_view",{entityType:"contract",entityId:viewingContract.id,projectId:viewingContract.project_id});
  },[viewingContract]);
  // Item-level views: when a tab is opened, log a view for each item it lists. The database
  // already skips repeats within 30 minutes; the id-key deps only stop a re-fire on every render.
  useEffect(()=>{
    if(tab==="invoices"&&portalSessionToken)visInvoices.slice(0,20).forEach((inv:any)=>logPortalEvent(portalSessionToken,"invoice_view",{entityType:"invoice",entityId:inv.id,projectId:inv.project_id}));
  },[tab,visInvoices.map((i:any)=>i.id).join(",")]);
  useEffect(()=>{
    if(tab==="estimates"&&portalSessionToken)visEstimates.slice(0,20).forEach((es:any)=>logPortalEvent(portalSessionToken,"estimate_view",{entityType:"estimate",entityId:es.id,projectId:es.project_id}));
  },[tab,visEstimates.map((e:any)=>e.id).join(",")]);
  useEffect(()=>{
    if(tab==="contracts"&&portalSessionToken)visContracts.slice(0,20).forEach((ct:any)=>logPortalEvent(portalSessionToken,"contract_view",{entityType:"contract",entityId:ct.id,projectId:ct.project_id}));
  },[tab,visContracts.map((c:any)=>c.id).join(",")]);
  // The Estimates tab disappears when the selected project has none; don't leave the view on a hidden tab.
  useEffect(()=>{
    if(tab==="estimates"&&visEstimates.length===0)setTab("overview");
  },[tab,visEstimates.length]);
  // A field officer has no Estimates / Contracts / Invoices / Feedback tabs; never leave the view on one of them.
  useEffect(()=>{
    if(isContact&&(tab==="estimates"||tab==="contracts"||tab==="invoices"||tab==="feedback"))setTab("overview");
  },[isContact,tab]);

  // Session-URL route (email+password login from ClientLoginPage.tsx): the session token in the
  // URL is validated AND everything the page shows is loaded by ONE server call, get_portal_data.
  // No direct table reads happen from the browser any more.
  async function checkAuthViaSession(sessTok: string) {
    setAuthState("loading");
    try {
      const {data:d,error:dErr}=await supabase.rpc("get_portal_data",{p_session_token:sessTok});
      if(dErr||!d){setErrorMsg("This session has expired. Please sign in again.");setAuthState("error");return;}
      setPortalSessionToken(sessTok);
      logPortalEvent(sessTok,"session_resume");
      await loadData(d.client,sessTok,d);
      setAuthState("authenticated");
    } catch {setErrorMsg("Something went wrong.");setAuthState("error");}
  }

  // /portal/:token magic-link flow. get_portal_link_info identifies the client and says whether
  // this is a first-time setup or a login (it never returns anything secret); a stored session
  // is then resumed by asking get_portal_data, which returns null unless the session is valid.
  async function checkAuth() {
    setAuthState("loading");
    try {
      const {data:info}=await supabase.rpc("get_portal_link_info",{p_portal_token:token});
      if(!info||!info.client){setErrorMsg("This portal link is invalid or has been disabled.");setAuthState("error");return;}
      setClient(info.client);
      setCompany({company_name:null,logo_url:null,phone:null,email:null,address_line1:null,...(info.company||{})} as Co);
      const sess=localStorage.getItem(`portal_${info.client.id}`);
      if(sess){
        const {data:d}=await supabase.rpc("get_portal_data",{p_session_token:sess});
        if(d&&d.client?.id===info.client.id&&d.viewer?.kind!=="contact"){setPortalSessionToken(sess);logPortalEvent(sess,"session_resume");await loadData(d.client,sess,d);setAuthState("authenticated");return;}
      }
      setAuthState((info.mode||(info.client.portal_activated_at?"login":"setup"))==="setup"?"setup":"login");
    } catch {setErrorMsg("Something went wrong.");setAuthState("error");}
  }

  // /portal/contact/:contactToken. The link identifies the contact (it never returns anything secret). A stored session is
  // resumed ONLY if the server says it belongs to this very contact; otherwise the setup/login screen is shown.
  async function checkContactAuth() {
    setAuthState("loading");
    try {
      const {data:info}=await supabase.rpc("get_contact_portal_link_info",{p_portal_token:contactToken});
      if(!info||!info.contact){setErrorMsg("This invite link is invalid or has been withdrawn.");setAuthState("error");return;}
      const ct:PortalContact={id:info.contact.id,name:info.contact.name,email:info.contact.email??null,client_name:info.contact.client_name??null};
      setContactInfo(ct);
      setClient({id:"",name:ct.client_name||"",contact_name:ct.name,email:ct.email,portal_email:ct.email,portal_activated_at:null});
      setCompany({company_name:null,logo_url:null,phone:null,email:null,address_line1:null,...(info.company||{})} as Co);
      const key=`portal_contact_${ct.id}`;
      const sess=localStorage.getItem(key);
      if(sess){
        const {data:d}=await supabase.rpc("get_portal_data",{p_session_token:sess});
        if(d&&d.viewer?.kind==="contact"&&d.viewer.contact_id===ct.id){setPortalSessionToken(sess);logPortalEvent(sess,"session_resume");await loadData(d.client,sess,d);setAuthState("authenticated");return;}
        localStorage.removeItem(key); // expired, revoked, or not this contact's: forget it
      }
      setAuthState(info.mode==="setup"?"setup":"login");
    } catch {setErrorMsg("Something went wrong.");setAuthState("error");}
  }

  // Puts one get_portal_data payload into state: client, company, project, progress, photos,
  // site updates and change orders. Photo URLs are built from photo_url exactly as before.
  // As before, the project-scoped lists are only touched when the client has a project.
  function applyPortalData(d:any,fallback?:Client){
    setClient(d.client||fallback||null);
    setViewer(d.viewer?.kind==="contact"?d.viewer:null);
    setCompany(d.company||null);
    const proj=d.project||null;
    setProject(proj);
    setProjects(normalizeProjects(d.projects));
    setSelectedProjectId(proj?.id??null);
    if(proj){
      const newest=(a:any,b:any)=>String(b.created_at||"").localeCompare(String(a.created_at||""));
      const ph=[...(d.photos||[])].sort(newest);
      setPhotos(ph.map((photo:any)=>{
        const{data:urlData}=supabase.storage.from("project-photos").getPublicUrl(photo.photo_url);
        return{...photo,url:urlData.publicUrl};
      }));
      setSitePhotos(ph.slice(0,20).map((photo:any)=>{
        const{data:urlData}=supabase.storage.from("project-photos").getPublicUrl(photo.photo_url);
        return{...photo,publicUrl:urlData.publicUrl};
      }));
      setDailyLogs([...(d.daily_logs||[])].sort((a:any,b:any)=>String(b.log_date||"").localeCompare(String(a.log_date||""))).slice(0,10));
      setChanges([...(d.change_orders||[])].sort(newest));
      setProgress(Math.round(Number(d.progress_pct)||0));
      setLogsLoading(false);
      setPhotosLoading(false);
    }
  }

  // The first get_portal_data answer already lists this client's projects and says which one the server chose.
  // If this tab remembers another of them, load that one instead. The remembered id is only ever a request: it
  // must be in the server's own list, and get_portal_data still applies its ownership check on the way.
  async function withRememberedProject(d:any,sessionTok:string){
    try{
      const wanted=pickRememberedProject(readRememberedProject(d?.viewer?.kind==="contact"?`contact_${d.viewer.contact_id}`:d?.client?.id),normalizeProjects(d?.projects),d?.project?.id??null);
      if(!wanted)return d;
      const {data:d2,error}=await supabase.rpc("get_portal_data",{p_session_token:sessionTok,p_project_id:wanted});
      return !error&&d2?d2:d;
    }catch{return d;}
  }

  async function loadData(c:Client,sessionTok:string,prefetched?:any,projectId?:string|null) {
    try {
      const ticket=projectGate.current.current();
      let d=prefetched??(await supabase.rpc("get_portal_data",projectId?{p_session_token:sessionTok,p_project_id:projectId}:{p_session_token:sessionTok})).data;
      if(!d)return;
      const contactView=d?.viewer?.kind==="contact";
      if(prefetched&&!projectId)d=await withRememberedProject(d,sessionTok);
      if(projectGate.current.isCurrent(ticket))applyPortalData(d,c);
      const proj=d.project||null;
      const {data:cm,error:cmErr}=await supabase.rpc("get_portal_comments",{p_session_token:sessionTok});
      if(cmErr)console.error("get_portal_comments failed:",cmErr);
      setComments(cm||[]);
      // Shared estimates come back per client, so this sits outside the if(proj) block.
      if(!contactView)try{
        const {data:es,error:esErr}=await supabase.rpc("get_portal_estimates",{p_session_token:sessionTok});
        if(esErr)console.error("get_portal_estimates failed:",esErr);
        setEstimates(Array.isArray(es)?es:[]);
      }catch(e){console.error("get_portal_estimates failed:",e);}
      // Contracts the contractor has sent (per client, like estimates), so also outside if(proj).
      if(!contactView)try{
        const {data:cts,error:ctErr}=await supabase.rpc("get_portal_contracts",{p_session_token:sessionTok});
        if(ctErr)console.error("get_portal_contracts failed:",ctErr);
        else setContracts(Array.isArray(cts)?cts:[]);
      }catch(e){console.error("get_portal_contracts failed:",e);}
      if(proj&&!contactView){
        const inv=await supabase.rpc("get_portal_invoices",{p_session_token:sessionTok});
        setInvoices(inv.data||[]);
        if(inv.error)console.error("get_portal_invoices failed:",inv.error);
      }
    } catch(e){console.error(e);}
  }

  async function onAuthSuccess(){
    // AuthScreen already wrote the freshly-minted session token to localStorage under this
    // client's key immediately before calling onSuccess(), so it is present here, not a race.
    const sessTok=contactInfo?localStorage.getItem(`portal_contact_${contactInfo.id}`):(client?localStorage.getItem(`portal_${client.id}`):null);
    if(sessTok){
      const {data:d}=await supabase.rpc("get_portal_data",{p_session_token:sessTok});
      // A contact link only ever opens that contact's own view.
      const okForThisLink=contactInfo?(d?.viewer?.kind==="contact"&&d.viewer.contact_id===contactInfo.id):true;
      if(d&&okForThisLink){setPortalSessionToken(sessTok);await loadData(d.client,sessTok,d);}
    }
    setAuthState("authenticated");
    setToast({msg:"Welcome to your project portal!",type:"success"});
  }
  // Pick another project: reload its progress, photos, site updates and change orders through get_portal_data.
  // Only the most recent pick may apply its response (a slower earlier one is ignored), the current tab is
  // kept, and a failed load puts the picker back on the project that is actually on screen.
  async function selectProject(id:string){
    if(!portalSessionToken||!client||id===activeProjectId)return;
    const ticket=projectGate.current.next();
    const previousId=project?.id||null;
    setSelectedProjectId(id);setSwitchingProject(true);
    setNewComment("");setRating(0);setReviewText("");
    setLogsLoading(true);setPhotosLoading(true);
    try{
      const {data:d,error}=await supabase.rpc("get_portal_data",{p_session_token:portalSessionToken,p_project_id:id});
      if(!projectGate.current.isCurrent(ticket))return;
      if(error||!d)throw new Error(error?.message||"No data returned");
      applyPortalData(d,client);
      rememberProject(viewer?.kind==="contact"?`contact_${viewer.contact_id}`:client.id,d.project?.id||id);
    }catch(e){
      if(!projectGate.current.isCurrent(ticket))return;
      console.error("get_portal_data (project switch) failed:",e);
      setSelectedProjectId(previousId);
      setLogsLoading(false);setPhotosLoading(false);
      setToast({msg:"Could not load that project. Please try again.",type:"error"});
    }
    if(projectGate.current.isCurrent(ticket))setSwitchingProject(false);
  }
  async function submitComment(){
    if(!newComment.trim()||!client||!portalSessionToken) return;

    // Replaces the direct client_comments INSERT — client_id is never
    // sent from the browser now; the RPC derives it server-side from the
    // validated session, same as get_portal_comments above.
    const { error } = await supabase.rpc("insert_portal_comment", {
      p_session_token: portalSessionToken,
      p_project_id: activeProjectId,
      p_message: newComment,
    });

    if (error) {
      setToast({ msg: "Failed to send message. Please try again.", type: "error" });
      console.error("insert_portal_comment error:", error);
      return;
    }

    setNewComment("");
    logPortalEvent(portalSessionToken,"comment_sent",{projectId:activeProjectId});
    setToast({ msg: "Message sent!", type: "success" });
    loadData(client,portalSessionToken,undefined,activeProjectId);
  }

  async function submitReview(){
    if(!rating||!client||!activeProjectId)return;
    try{
      if(!portalSessionToken)throw new Error("Your session has expired. Please sign in again.");
      const {error}=await supabase.rpc("submit_portal_review",{p_session_token:portalSessionToken,p_project_id:activeProjectId,p_rating:rating,p_comment:reviewText});
      if(error)throw new Error(error.message);
      setReviewedProjectIds(prev=>[...prev,activeProjectId]);setToast({msg:"Thank you for your review!",type:"success"});
    }catch(e:any){setToast({msg:e?.message||"Could not submit your review. Please try again.",type:"error"});}
  }
  function getWeatherEmoji(desc:string) {
    if(!desc)return"🌤️";
    const d=desc.toLowerCase();
    if(d.includes("sun")||d.includes("clear"))return"☀️";
    if(d.includes("cloud"))return"⛅";
    if(d.includes("rain")||d.includes("shower"))return"🌧️";
    if(d.includes("storm")||d.includes("thunder"))return"⛈️";
    if(d.includes("wind"))return"💨";
    if(d.includes("fog")||d.includes("mist"))return"🌫️";
    return"🌤️";
  }

  async function downloadPhoto(photo:any,e:React.MouseEvent) {
    e.stopPropagation();
    try {
      // Photos are public URLs (that is how they are displayed), so fetch the image directly.
      const src=photo.publicUrl||photo.url||photo.public_url;
      const resp=src?await fetch(src):null;
      if(!resp||!resp.ok){alert("Failed to download photo.");return;}
      const data=await resp.blob();
      const url=URL.createObjectURL(data);
      const a=document.createElement("a");
      a.href=url;
      a.download=photo.caption?`${photo.caption.replace(/\s+/g,"-")}.jpg`:`site-photo-${photo.id}.jpg`;
      document.body.appendChild(a);a.click();document.body.removeChild(a);
      URL.revokeObjectURL(url);
      logPortalEvent(portalSessionToken,"photo_download",{entityType:"photo",entityId:photo.id,projectId:activeProjectId});
    } catch {alert("Failed to download photo.");}
  }

  // Approve / reject a change order through the server function, which checks the order is this
  // client's and still unanswered, and logs change_approve / change_reject itself.
  async function respondChange(id:string,resp:"approved"|"rejected"){
    setRespondingTo(id);
    try{
      if(!portalSessionToken)throw new Error("Your session has expired. Please sign in again.");
      const {data,error}=await supabase.rpc("respond_portal_change_order",{p_session_token:portalSessionToken,p_change_order_id:id,p_response:resp});
      if(error)throw new Error(error.message);
      setChanges(prev=>prev.map(c=>c.id===id?{...c,status:resp,...(data&&typeof data==="object"?data:{})}:c));
      setToast({msg:resp==="approved"?"Change approved!":"Change rejected.",type:resp==="approved"?"success":"error"});
    }catch(e:any){setToast({msg:e?.message||"Could not save your response. Please try again.",type:"error"});}
    finally{setRespondingTo(null);}
  }

  // Sign out: end the session on the server (portal_logout logs "logout" and deletes the
  // session row), fire-and-forget, then clear it locally exactly as before.
  function signOut(){
    try{
      if(portalSessionToken)void Promise.resolve(supabase.rpc("portal_logout",{p_session_token:portalSessionToken})).then(()=>{},()=>{});
    }catch{}
    if(isContact){
      // A field officer: forget only THEIR session key (a manager's session on this device is untouched).
      const cid=(viewer&&viewer.kind==="contact"?viewer.contact_id:null)||contactInfo?.id;
      if(cid)localStorage.removeItem(`portal_contact_${cid}`);
      setPortalSessionToken(null);
      if(contactToken&&contactInfo){setViewer(null);setAuthState("login");return;} // back to this contact's own login screen
      window.location.assign("/client-login");
      return;
    }
    if(client)localStorage.removeItem(`portal_${client.id}`);
    setAuthState("login");
  }
  // The shared contract document expects the staff-shaped contract (client + project details). The portal
  // builds them from what the server sends: client_name / client_address / project_name / project_site_address from
  // get_portal_contracts (those take precedence, so a contract on any project matches the staff copy), falling back
  // to get_portal_data's project only if a field is missing.
  function docContract(ct:any){
    const proj=project&&ct?.project_id&&project.id===ct.project_id?project:null;
    return {...ct,
      client:{name:ct?.client_name??client?.name,contact_name:client?.contact_name??null,address:ct?.client_address??null},
      project:{name:ct?.project_name??proj?.name??null,site_address:ct?.project_site_address??proj?.site_address??null}};
  }

  const {totalInvoiced,totalPaid,balanceDue}=invoiceTotals(visInvoices);
  const pendingChanges=countPending(changes);

  const G=`@keyframes spin{to{transform:rotate(360deg)}} @keyframes fadeIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}} *{box-sizing:border-box} body{margin:0} input::placeholder,textarea::placeholder{color:#94a3b8} input:focus,textarea:focus{border-color:#0891b2!important} ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:4px}`;

  if(authState==="loading")return <div style={{minHeight:"100vh",background:"#f8fafc",display:"flex",alignItems:"center",justifyContent:"center"}}><style>{G}</style><div style={{textAlign:"center"}}><div style={{width:44,height:44,border:"3px solid #0891b2",borderTopColor:"transparent",borderRadius:"50%",animation:"spin 0.8s linear infinite",margin:"0 auto 14px"}}/><p style={{color:"#64748b",fontSize:14}}>Loading portal…</p></div></div>;

  if(authState==="error")return <div style={{minHeight:"100vh",background:"#f8fafc",display:"flex",alignItems:"center",justifyContent:"center",padding:24}}><style>{G}</style><div style={{textAlign:"center",maxWidth:360}}><div style={{fontSize:52,marginBottom:14}}>🔒</div><h2 style={{color:"#0f172a",fontSize:20,fontWeight:700,marginBottom:8}}>Access Denied</h2><p style={{color:"#64748b",fontSize:14,lineHeight:1.6}}>{errorMsg}</p></div></div>;

  if(authState==="setup"||authState==="login")return <><style>{G}</style><AuthScreen client={client!} company={company} mode={authState} token={(contactInfo?contactToken:token)!} contact={contactInfo} onSuccess={onAuthSuccess}/></>;

  if(!client||authState!=="authenticated")return null;

  // A field officer with nothing assigned (or whose projects were reassigned): a plain message instead of empty tabs.
  if(isContact&&!project)return <div style={{minHeight:"100vh",background:"#f8fafc",color:"#0f172a",fontFamily:"system-ui,sans-serif"}}>
    <style>{G}</style>
    <div style={{maxWidth:860,margin:"0 auto",padding:"12px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,borderBottom:"1px solid #e2e8f0"}}>
      <div style={{fontWeight:700,fontSize:13}}>{companyDisplayName(company?.company_name)}</div>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <div style={{textAlign:"right"}}>
          <div style={{fontSize:12,fontWeight:600}}>{viewer&&viewer.kind==="contact"?viewer.name:""}</div>
          <div style={{fontSize:10,color:"#64748b"}}>{client.name} · field officer view</div>
        </div>
        <button onClick={signOut} style={{padding:"6px 12px",background:"#f1f5f9",border:"1px solid #e2e8f0",borderRadius:8,color:"#475569",fontSize:11,cursor:"pointer",fontWeight:600}}>Sign Out</button>
      </div>
    </div>
    <div style={{maxWidth:520,margin:"60px auto",padding:"0 20px",textAlign:"center"}}>
      <div style={{fontSize:44,marginBottom:12}}>📋</div>
      <h2 style={{fontSize:18,fontWeight:700,margin:"0 0 8px"}}>No projects assigned</h2>
      <p style={{fontSize:14,color:"#64748b",lineHeight:1.6,margin:0}}>No projects are assigned to you right now. Contact {companyDisplayName(company?.company_name)}.</p>
    </div>
  </div>;

  const sColor:Record<string,string>={active:"#22c55e",planning:"#3b82f6",on_hold:"#f59e0b",completed:"#94a3b8",cancelled:"#ef4444"};
  const TABS:ReadonlyArray<{id:string;label:string;emoji:string;badge?:number}>=isContact
    ?[{id:"overview",label:"Overview",emoji:"📋"},{id:"photos",label:"Photos",emoji:"📸",badge:photos.length||undefined},{id:"changes",label:"Changes",emoji:"⚠️",badge:pendingChanges||undefined}]
    :[{id:"overview",label:"Overview",emoji:"📋"},...(visEstimates.length?[{id:"estimates",label:"Estimates",emoji:"📐",badge:visEstimates.length}]:[]),{id:"contracts",label:"Contracts",emoji:"📝",badge:countUnsigned(visContracts)||undefined},{id:"photos",label:"Photos",emoji:"📸",badge:photos.length||undefined},{id:"invoices",label:"Invoices",emoji:"🧾",badge:countUnpaid(visInvoices)||undefined},{id:"changes",label:"Changes",emoji:"⚠️",badge:pendingChanges||undefined},{id:"feedback",label:"Feedback",emoji:"⭐"}];

  return <div style={{minHeight:"100vh",background:"#f8fafc",color:"#0f172a",fontFamily:"system-ui,sans-serif"}}>
    <style>{G}</style>

    <div style={{position:"sticky",top:0,zIndex:100,background:"rgba(248,250,252,0.95)",backdropFilter:"blur(16px)",borderBottom:"1px solid #e2e8f0"}}>
      <div style={{maxWidth:860,margin:"0 auto",padding:"12px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          {company?.logo_url?<img src={company.logo_url} style={{display:"block",width:"auto",height:"auto",maxHeight:34,maxWidth:120,objectFit:"contain"}}/>
            :<div style={{width:34,height:34,borderRadius:8,background:"linear-gradient(135deg,#0891b2,#06b6d4)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:"#fff"}}>{(company?.company_name||"M")[0]}</div>}
          <div>
            <div style={{fontWeight:700,fontSize:13,color:"#0f172a"}}>{companyDisplayName(company?.company_name)}</div>
            <div style={{fontSize:10,color:"#64748b"}}>{isContact?"Field officer portal":"Client Portal"}</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{textAlign:"right"}}>
            <div style={{fontSize:12,fontWeight:600,color:"#0f172a"}}>{viewer&&viewer.kind==="contact"?(viewer.name||client.contact_name||client.name):(client.contact_name||client.name)}</div>
            <div style={{fontSize:10,color:"#64748b"}}>{isContact?`${client.name} · field officer view`:(client.portal_email||client.email)}</div>
          </div>
          <button onClick={signOut} style={{padding:"6px 12px",background:"#f1f5f9",border:"1px solid #e2e8f0",borderRadius:8,color:"#475569",fontSize:11,cursor:"pointer",fontWeight:600}}>Sign Out</button>
        </div>
      </div>
    </div>

    {multiProject&&<PortalProjectPicker projects={projects} selectedId={activeProjectId} onSelect={selectProject}/>}

    <div style={{maxWidth:860,margin:"0 auto",padding:"20px 20px 60px",display:"flex",flexDirection:"column",gap:16,...(switchingProject?{opacity:0.55,transition:"opacity 0.2s"}:{})}}>

      <div style={{background:"linear-gradient(135deg,#eff6ff,#ecfeff)",border:"1px solid #bae6fd",borderRadius:20,padding:"22px 24px",display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:16,flexWrap:"wrap",animation:"fadeIn 0.4s ease"}}>
        <div style={{flex:1,minWidth:180}}>
          <div style={{fontSize:10,color:"#0284c7",fontWeight:700,letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>Your Project</div>
          <h1 style={{fontSize:24,fontWeight:800,color:"#0f172a",margin:"0 0 6px"}}>{project?.name||"No project assigned"}</h1>
          {project?.site_address&&<div style={{fontSize:12,color:"#64748b",marginBottom:10}}>📍 {project.site_address}</div>}
          <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
            {project?.status&&<span style={{fontSize:11,padding:"4px 12px",borderRadius:20,fontWeight:700,background:`${sColor[project.status]||"#3b82f6"}18`,color:sColor[project.status]||"#3b82f6",border:`1px solid ${sColor[project.status]||"#3b82f6"}40`,textTransform:"capitalize"}}>● {project.status.replace("_"," ")}</span>}
            {project?.start_date&&<span style={{fontSize:11,color:"#475569"}}>Started {fmtDate(project.start_date)}</span>}
            {project?.end_date&&<span style={{fontSize:11,color:"#475569"}}>Est. done {fmtDate(project.end_date)}</span>}
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
          <div style={{position:"relative",width:72,height:72}}>
            <ProgressRing pct={progress}/>
            <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:800,color:"#0f172a"}}>{progress}%</div>
          </div>
          <div style={{fontSize:10,color:"#475569"}}>Complete</div>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:`repeat(${isContact?1:3},1fr)`,gap:10}}>
        {[...(isContact?[]:[{l:"Paid",v:fmt(totalPaid),c:"#22c55e"},{l:"Balance Due",v:fmt(balanceDue),c:balanceDue>0?"#ef4444":"#22c55e"}]),{l:"Pending",v:`${pendingChanges}`,c:pendingChanges>0?"#f59e0b":"#64748b"}].map((s,i)=>(
          <div key={i} style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:14,padding:"14px 16px",textAlign:"center"}}>
            <div style={{fontSize:18,fontWeight:800,color:s.c}}>{s.v}</div>
            <div style={{fontSize:10,color:"#475569",marginTop:3}}>{s.l}</div>
          </div>
        ))}
      </div>

      <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:2}}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id as Tab)}
            style={{display:"flex",alignItems:"center",gap:6,padding:"8px 16px",borderRadius:12,border:"1px solid",fontSize:13,fontWeight:600,whiteSpace:"nowrap",cursor:"pointer",transition:"all 0.2s",background:tab===t.id?"#0891b2":"#f1f5f9",borderColor:tab===t.id?"#0891b2":"#e2e8f0",color:tab===t.id?"#fff":"#64748b"}}>
            {t.emoji} {t.label}
            {"badge" in t && t.badge?<span style={{fontSize:10,padding:"1px 6px",borderRadius:10,background:tab===t.id?"rgba(255,255,255,0.25)":"#dbeafe",color:tab===t.id?"#fff":"#1d4ed8",fontWeight:700}}>{t.badge}</span>:null}
          </button>
        ))}
      </div>

      {tab==="overview"&&<div style={{display:"flex",flexDirection:"column",gap:14,animation:"fadeIn 0.3s ease"}}>
        <div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
            <span style={{fontSize:13,fontWeight:700,color:"#374151"}}>Project Progress</span>
            <span style={{fontSize:14,fontWeight:800,color:"#3b82f6"}}>{progress}%</span>
          </div>
          <div style={{height:8,background:"#e2e8f0",borderRadius:8,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${progress}%`,background:"linear-gradient(90deg,#3b82f6,#06b6d4)",borderRadius:8,transition:"width 1.5s ease"}}/>
          </div>
        </div>
        {/* Daily Logs */}
        <div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
          <div style={{fontSize:13,fontWeight:700,color:"#374151",marginBottom:14}}>📋 Site Updates</div>
          {logsLoading?(
            <div style={{textAlign:"center",padding:"24px 0",color:"#94a3b8",fontSize:13}}>Loading...</div>
          ):dailyLogs.length===0?(
            <div style={{textAlign:"center",padding:"24px 0",color:"#94a3b8",fontSize:13}}>No site updates yet</div>
          ):(
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              {dailyLogs.map(log=>(
                <div key={log.id} style={{padding:"14px 16px",borderRadius:12,background:"#f8fafc",border:"1px solid #f1f5f9"}}>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:6}}>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <span style={{fontSize:16}}>{getWeatherEmoji(log.weather||log.weather_condition||"")}</span>
                      <span style={{fontSize:13,fontWeight:700,color:"#374151"}}>
                        {fmtLogDay(log.log_date)}
                      </span>
                    </div>
                    <span style={{fontSize:11,color:"#64748b"}}>👷 {log.workers_count??0} workers</span>
                  </div>
                  {log.work_performed&&<p style={{fontSize:13,color:"#475569",margin:"0 0 4px",lineHeight:1.6}}>{log.work_performed}</p>}
                  {log.deliveries&&<p style={{fontSize:11,color:"#94a3b8",margin:0}}>📦 {log.deliveries}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Site Photos */}
        <div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
          <div style={{fontSize:13,fontWeight:700,color:"#374151",marginBottom:14}}>📸 Site Photos</div>
          {photosLoading?(
            <div style={{textAlign:"center",padding:"24px 0",color:"#94a3b8",fontSize:13}}>Loading...</div>
          ):sitePhotos.length===0?(
            <div style={{textAlign:"center",padding:"24px 0",color:"#94a3b8",fontSize:13}}>No photos yet</div>
          ):(
            <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10}}>
              {sitePhotos.map(photo=>(
                <div key={photo.id} style={{borderRadius:16,overflow:"hidden",border:"1px solid #e2e8f0",background:"#ffffff"}}>
                  <div onClick={()=>setSelectedPhoto(photo)} style={{aspectRatio:"1",overflow:"hidden",background:"#f1f5f9",cursor:"zoom-in"}}>
                    <img src={photo.publicUrl} alt={photo.caption||"Site photo"} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                  </div>
                  {photo.caption&&<div style={{padding:"4px 8px",borderTop:"1px solid #f1f5f9"}}><p style={{fontSize:11,color:"#64748b",margin:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{photo.caption}</p></div>}
                  <div style={{borderTop:"1px solid #f1f5f9"}}>
                    <button onClick={(e)=>downloadPhoto(photo,e)} style={{width:"100%",display:"flex",alignItems:"center",justifyContent:"center",gap:6,padding:"10px 0",background:"transparent",border:"none",fontSize:11,fontWeight:600,color:"#64748b",cursor:"pointer"}}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                      Download
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Photo Lightbox */}
        {selectedPhoto&&(
          <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.90)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:20}} onClick={()=>setSelectedPhoto(null)}>
            <button onClick={()=>setSelectedPhoto(null)} style={{position:"absolute",top:16,right:16,padding:8,borderRadius:"50%",background:"rgba(255,255,255,0.1)",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
            <div style={{position:"absolute",top:16,left:16}} onClick={e=>e.stopPropagation()}>
              <button onClick={(e)=>downloadPhoto(selectedPhoto,e)} style={{display:"flex",alignItems:"center",gap:6,padding:"6px 12px",borderRadius:8,background:"rgba(255,255,255,0.1)",border:"none",color:"#ffffff",fontSize:12,fontWeight:600,cursor:"pointer"}}>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Download
              </button>
            </div>
            <img src={selectedPhoto.publicUrl} alt={selectedPhoto.caption||"Site photo"} style={{maxWidth:"100%",maxHeight:"80vh",borderRadius:12,objectFit:"contain"}}/>
            {selectedPhoto.caption&&<div style={{position:"absolute",bottom:24,left:0,right:0,textAlign:"center"}}><span style={{fontSize:13,color:"#ffffff",background:"rgba(0,0,0,0.5)",padding:"6px 16px",borderRadius:20}}>{selectedPhoto.caption}</span></div>}
          </div>
        )}

        <div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
          <div style={{fontSize:13,fontWeight:700,color:"#374151",marginBottom:14}}>💬 Messages</div>
          {visComments.length>0&&<div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:16,maxHeight:280,overflowY:"auto"}}>
            {visComments.map(c=>{
              const isStaff=c.sender_type==="staff";
              return <div key={c.id} style={{display:"flex",justifyContent:isStaff?"flex-end":"flex-start"}}>
                <div style={{maxWidth:"75%",background:isStaff?"#0891b2":"#eff6ff",border:isStaff?"none":"1px solid #bfdbfe",borderRadius:10,padding:"10px 14px"}}>
                  <p style={{fontSize:13,color:isStaff?"#fff":"#1e3a5f",margin:"0 0 4px",lineHeight:1.5}}>{c.message}</p>
                  <span style={{fontSize:10,color:isStaff?"#e0f2fe":"#475569"}}>{isStaff?"Contractor":"You"} · {timeAgo(c.created_at)}</span>
                </div>
              </div>;
            })}
          </div>}
          {multiProject&&<div style={{fontSize:11,color:"#64748b",marginBottom:6}}>About: {selectedProjectName}</div>}
          <textarea value={newComment} onChange={e=>setNewComment(e.target.value)} placeholder="Send a message to your contractor…"
            style={{width:"100%",background:"#ffffff",border:"1px solid #cbd5e1",borderRadius:10,padding:"11px 14px",fontSize:13,color:"#0f172a",resize:"none",height:76,outline:"none"}}/>
          <button onClick={submitComment} disabled={!newComment.trim()}
            style={{marginTop:10,padding:"10px 20px",background:newComment.trim()?"#0891b2":"#f1f5f9",border:"none",borderRadius:10,color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer"}}>
            Send Message
          </button>
        </div>
        <div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
          <div style={{fontSize:13,fontWeight:700,color:"#374151",marginBottom:12}}>📞 Contact</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {company?.phone&&<a href={`tel:${company.phone}`} style={{fontSize:13,color:"#0284c7",textDecoration:"none"}}>📞 {company.phone}</a>}
            {company?.email&&<a href={`mailto:${company.email}`} style={{fontSize:13,color:"#0284c7",textDecoration:"none"}}>✉️ {company.email}</a>}
            {company?.address_line1&&<div style={{fontSize:13,color:"#64748b"}}>📍 {company.address_line1}</div>}
          </div>
        </div>
      </div>}
      {tab==="contracts"&&<div style={{display:"flex",flexDirection:"column",gap:12,animation:"fadeIn 0.3s ease"}}>
        {visContracts.length===0
          ?<div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:48,textAlign:"center"}}><div style={{fontSize:40,marginBottom:12}}>📝</div><p style={{color:"#64748b"}}>No contracts have been sent for signing yet.</p></div>
          :visContracts.map((ct:any)=>
            <div key={ct.id} style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:20}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:12,marginBottom:12}}>
                <div>
                  <div style={{fontSize:15,fontWeight:700,color:"#0f172a",marginBottom:4}}>{ct.contract_name}</div>
                  <div style={{fontSize:11,color:"#64748b"}}>#{ct.contract_number}</div>
                  {multiProject&&<div style={{fontSize:10,color:"#94a3b8",marginTop:2}}>{itemProjectLabel(ct,projects,multiProject)}</div>}
                </div>
                <span style={{fontSize:10,padding:"3px 10px",borderRadius:20,fontWeight:700,background:ct.client_signed_at?"rgba(34,197,94,0.15)":"rgba(245,158,11,0.15)",color:ct.client_signed_at?"#22c55e":"#f59e0b"}}>{ct.client_signed_at?"Signed":"Awaiting Signature"}</span>
              </div>
              {ct.scope_of_work&&<p style={{fontSize:12,color:"#64748b",margin:"0 0 14px",lineHeight:1.6}}>{ct.scope_of_work}</p>}
              <div style={{display:"flex",gap:8,paddingTop:12,borderTop:"1px solid #f1f5f9"}}>
                <div style={{flex:1,fontSize:11,padding:"6px 10px",borderRadius:8,textAlign:"center",fontWeight:600,background:ct.contractor_signed_at?"rgba(34,197,94,0.1)":"#f8fafc",color:ct.contractor_signed_at?"#22c55e":"#475569"}}>Contractor {ct.contractor_signed_at?"✓":"Pending"}</div>
                <div style={{flex:1,fontSize:11,padding:"6px 10px",borderRadius:8,textAlign:"center",fontWeight:600,background:ct.client_signed_at?"rgba(34,197,94,0.1)":"#f8fafc",color:ct.client_signed_at?"#22c55e":"#475569"}}>You {ct.client_signed_at?"✓ Signed":"Pending"}</div>
              </div>
              <button onClick={()=>setViewingContract(ct)} style={{width:"100%",marginTop:12,padding:"10px 0",background:"#f1f5f9",border:"1px solid #e2e8f0",borderRadius:12,color:"#0f172a",fontSize:13,fontWeight:700,cursor:"pointer"}}>Read contract</button>
              {!ct.client_signed_at&&ct.contractor_signed_at&&<button onClick={()=>setSigningContract(ct)} style={{width:"100%",marginTop:12,padding:"12px 0",background:"#22c55e",border:"none",borderRadius:12,color:"#fff",fontSize:14,fontWeight:700,cursor:"pointer"}}>Sign This Contract</button>}
              {!ct.contractor_signed_at&&<div style={{marginTop:12,padding:"10px 14px",background:"rgba(245,158,11,0.07)",border:"1px solid rgba(245,158,11,0.2)",borderRadius:10,fontSize:12,color:"#f59e0b"}}>Waiting for contractor signature before you can sign.</div>}
            </div>
          )
        }
        {viewingContract&&<PortalContractViewer contract={docContract(viewingContract)} company={company} sessionToken={portalSessionToken} onClose={()=>setViewingContract(null)}/>}
        {signingContract&&<div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.8)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
          <SignatureModal contract={docContract(signingContract)} client={client} company={company} sessionToken={portalSessionToken} saving={savingSignature} onCancel={()=>setSigningContract(null)} onSign={async(dataUrl)=>{
            setSavingSignature(true);
            try{
              if(!portalSessionToken)throw new Error("Your session has expired. Please sign in again.");
              const signaturePng=await normalizeSignature(dataUrl);
              const{data:signed,error:signErr}=await supabase.functions.invoke("portal-sign-contract",{body:{sessionToken:portalSessionToken,contractId:signingContract.id,signaturePng}});
              if(signErr||signed?.error||!signed?.ok)throw new Error(await functionErrorMessage(signErr,signed,"Failed to save signature."));
              setContracts(prev=>prev.map(c=>c.id===signingContract.id?{...c,client_signed_at:signed.client_signed_at,client_signature_url:signed.client_signature_url,client_signature_src:signed.client_signature_signed_url||null}:c));
              setSigningContract(null);
              setToast({msg:"Contract signed successfully!",type:"success"});
            }catch(e:any){setToast({msg:e?.message||"Failed to save signature.",type:"error"});}
            finally{setSavingSignature(false);}
          }}/>
        </div>}
      </div>}

      {tab==="photos"&&<div style={{animation:"fadeIn 0.3s ease"}}>
        {photos.length===0?<div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:60,textAlign:"center"}}><div style={{fontSize:48,marginBottom:12}}>📸</div><p style={{color:"#64748b"}}>No site photos yet.</p></div>
          :<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:10}}>
            {photos.map(p=><div key={p.id} onClick={()=>setLightbox(p)} style={{aspectRatio:"1",borderRadius:12,overflow:"hidden",background:"#f1f5f9",border:"1px solid #e2e8f0",cursor:"zoom-in",position:"relative"}}>
              <img src={p.url||p.public_url||p.publicUrl||""} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
              {p.caption&&<div style={{position:"absolute",bottom:0,left:0,right:0,background:"linear-gradient(transparent,rgba(0,0,0,0.75))",padding:"16px 8px 8px",fontSize:11,color:"#e2e8f0"}}>{p.caption}</div>}
            </div>)}
          </div>}
      </div>}

      {tab==="invoices"&&<div style={{display:"flex",flexDirection:"column",gap:12,animation:"fadeIn 0.3s ease"}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
          {[{l:"Total",v:fmt(totalInvoiced),c:"#0f172a"},{l:"Paid",v:fmt(totalPaid),c:"#22c55e"},{l:"Balance Due",v:fmt(balanceDue),c:balanceDue>0?"#ef4444":"#22c55e"}].map((s,i)=>(
            <div key={i} style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:12,padding:14,textAlign:"center"}}>
              <div style={{fontSize:16,fontWeight:800,color:s.c}}>{s.v}</div>
              <div style={{fontSize:10,color:"#64748b",marginTop:3}}>{s.l}</div>
            </div>
          ))}
        </div>
        {visInvoices.length===0?<div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:48,textAlign:"center"}}><div style={{fontSize:40,marginBottom:12}}>🧾</div><p style={{color:"#64748b"}}>No invoices yet.</p></div>
          :visInvoices.map(inv=><div key={inv.id} style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:14,padding:"16px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}>
            <div>
              <div style={{fontSize:14,fontWeight:700,color:"#0f172a",marginBottom:4}}>Invoice #{inv.invoice_number||inv.id.slice(0,8).toUpperCase()}</div>
              <div style={{fontSize:11,color:"#64748b"}}>Issued {fmtDate(inv.issue_date)} … Due {fmtDate(inv.due_date)}</div>
              {multiProject&&<div style={{fontSize:10,color:"#94a3b8",marginTop:3}}>{itemProjectLabel(inv,projects,multiProject)}</div>}
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:16,fontWeight:800,color:"#0f172a",marginBottom:4}}>{fmt(Number(inv.total_amount||0))}</div>
              <span style={{fontSize:10,padding:"3px 10px",borderRadius:20,fontWeight:700,textTransform:"capitalize",background:inv.status==="paid"?"rgba(34,197,94,0.15)":inv.status==="overdue"?"rgba(239,68,68,0.15)":"rgba(245,158,11,0.15)",color:inv.status==="paid"?"#22c55e":inv.status==="overdue"?"#ef4444":"#f59e0b",border:`1px solid ${inv.status==="paid"?"rgba(34,197,94,0.3)":inv.status==="overdue"?"rgba(239,68,68,0.3)":"rgba(245,158,11,0.3)"}`}}>{inv.status}</span>
            </div>
          </div>)}
      </div>}

      {tab==="estimates"&&<div style={{display:"flex",flexDirection:"column",gap:12,animation:"fadeIn 0.3s ease"}}>
        {visEstimates.map((es:any)=><PortalEstimateCard key={es.id} es={es}/>)}
      </div>}

      {tab==="changes"&&<div style={{display:"flex",flexDirection:"column",gap:12,animation:"fadeIn 0.3s ease"}}>
        <div style={{background:"rgba(245,158,11,0.07)",border:"1px solid rgba(245,158,11,0.2)",borderRadius:12,padding:"12px 16px",fontSize:13,color:"#f59e0b"}}>{isContact?"Changes are approved by your organisation's portal manager.":"⚠️ Change orders need your approval before work begins."}</div>
        {changes.length===0?<div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:48,textAlign:"center"}}><div style={{fontSize:40,marginBottom:12}}>⚠️</div><p style={{color:"#64748b"}}>No change orders at this time.</p></div>
          :changes.map(co=><div key={co.id} style={{background:"#ffffff",border:`1px solid ${co.status==="approved"?"rgba(34,197,94,0.3)":co.status==="rejected"?"rgba(239,68,68,0.2)":"#e2e8f0"}`,borderRadius:16,padding:20}}>
            <div style={{fontSize:15,fontWeight:700,color:"#0f172a",marginBottom:4}}>{co.title}</div>
            {co.description&&<p style={{fontSize:13,color:"#475569",margin:"0 0 10px",lineHeight:1.6}}>{co.description}</p>}
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:co.status==="pending"?14:6}}>
              <span style={{fontSize:17,fontWeight:800,color:"#0f172a"}}>{fmt(Number(co.amount||0))}</span>
              <span style={{fontSize:10,padding:"3px 10px",borderRadius:20,fontWeight:700,textTransform:"capitalize",background:co.status==="approved"?"rgba(34,197,94,0.15)":co.status==="rejected"?"rgba(239,68,68,0.15)":"rgba(245,158,11,0.15)",color:co.status==="approved"?"#22c55e":co.status==="rejected"?"#ef4444":"#f59e0b"}}>{co.status}</span>
            </div>
            {co.status==="pending"&&!isContact&&<div style={{display:"flex",gap:10}}>
              <button onClick={()=>respondChange(co.id,"approved")} disabled={respondingTo===co.id} style={{flex:1,padding:"11px 0",background:"#16a34a",border:"none",borderRadius:10,color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer",opacity:respondingTo===co.id?0.6:1}}>✅ Approve</button>
              <button onClick={()=>respondChange(co.id,"rejected")} disabled={respondingTo===co.id} style={{flex:1,padding:"11px 0",background:"rgba(239,68,68,0.12)",border:"1px solid rgba(239,68,68,0.25)",borderRadius:10,color:"#ef4444",fontSize:13,fontWeight:700,cursor:"pointer"}}>✗ Reject</button>
            </div>}
            {co.status==="approved"&&<div style={{fontSize:12,color:"#22c55e",fontWeight:600}}>{isContact?"✅ Approved":"✅ You approved this change"}</div>}
            {co.status==="rejected"&&<div style={{fontSize:12,color:"#ef4444",fontWeight:600}}>{isContact?"✗ Rejected":"✗ You rejected this change"}</div>}
          </div>)}
      </div>}

      {tab==="feedback"&&<div style={{animation:"fadeIn 0.3s ease"}}>
        {reviewSubmitted?<div style={{background:"rgba(34,197,94,0.07)",border:"1px solid rgba(34,197,94,0.2)",borderRadius:16,padding:48,textAlign:"center"}}><div style={{fontSize:48,marginBottom:12}}>🌟</div><div style={{fontSize:18,fontWeight:700,color:"#22c55e",marginBottom:6}}>Thank you!</div><p style={{color:"#475569",fontSize:14}}>Your feedback means a lot to us.</p></div>
          :<div style={{background:"#ffffff",border:"1px solid #e2e8f0",borderRadius:16,padding:28}}>
            <div style={{fontSize:15,fontWeight:700,color:"#0f172a",marginBottom:4}}>Rate Our Work</div>
            {multiProject&&<div style={{fontSize:11,color:"#64748b",marginBottom:6}}>Project: {selectedProjectName}</div>}
            <p style={{fontSize:13,color:"#475569",marginBottom:20}}>How satisfied are you with the project so far?</p>
            <Stars value={rating} onChange={setRating}/>
            {rating>0&&<div style={{marginTop:20}}>
              <div style={{fontSize:12,color:"#475569",marginBottom:6}}>Tell us more (optional)</div>
              <textarea value={reviewText} onChange={e=>setReviewText(e.target.value)} placeholder="What went well? What could be improved?"
                style={{width:"100%",background:"#ffffff",border:"1px solid #cbd5e1",borderRadius:10,padding:"11px 14px",fontSize:13,color:"#0f172a",resize:"none",height:90,outline:"none"}}/>
              <button onClick={submitReview} style={{width:"100%",marginTop:12,padding:"13px 0",background:"#0891b2",border:"none",borderRadius:12,color:"#fff",fontSize:14,fontWeight:700,cursor:"pointer"}}>Submit Review</button>
            </div>}
          </div>}
      </div>}
    </div>

    <div style={{borderTop:"1px solid #e2e8f0",padding:"16px 0",textAlign:"center",fontSize:11,color:"#94a3b8"}}>
      {companyDisplayName(company?.company_name)} … Secured Portal … Powered by Magnus Boy&apos;s System
    </div>

    {lightbox&&<div onClick={()=>setLightbox(null)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.93)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:20,cursor:"zoom-out"}}>
      <img src={lightbox.url||lightbox.public_url||lightbox.publicUrl||""} style={{maxWidth:"100%",maxHeight:"90vh",borderRadius:12,objectFit:"contain"}}/>
    </div>}

    {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setToast(null)}/>}
  </div>;
}