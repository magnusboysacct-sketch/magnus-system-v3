﻿// src/pages/ProjectDashboardPage.tsx — v4: Milestones + Tasks + full project management
import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "../lib/supabase";
import FieldOfficerPortalCard from "../components/FieldOfficerPortalCard";
import CopyMilestoneForBasesModal from "../components/CopyMilestoneForBasesModal";
import { SaveAsTemplateModal, MilestoneTemplatesModal } from "../components/MilestoneTemplates";
import BoqToMilestonesModal from "../components/BoqToMilestonesModal";
import {
  Ruler, ShoppingCart, Wallet, FileText, BarChart3,
  ArrowRight, DollarSign, Users, Package, Receipt,
  Clock, CheckCircle2, AlertCircle, TrendingUp,
  TrendingDown, Building2, RefreshCw, ChevronLeft,
  Plus, X, Save, ListTodo, Trash2, Edit2, Flag,
  Calendar, Target, Layers, Map, Copy, BookmarkPlus, LayoutTemplate, FolderOpen
} from "lucide-react";

function fmtJMD(n: number) {
  return new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD",maximumFractionDigits:0}).format(n);
}
function fmtShort(n: number) {
  if(n>=1000000)return `J$${(n/1000000).toFixed(1)}M`;
  if(n>=1000)return `J$${(n/1000).toFixed(0)}K`;
  return fmtJMD(n);
}
function fmtTime(d: string) {
  const diff=Date.now()-new Date(d).getTime();
  const mins=Math.floor(diff/60000);
  if(mins<60)return `${mins}m ago`;
  const hrs=Math.floor(mins/60);
  if(hrs<24)return `${hrs}h ago`;
  return `${Math.floor(hrs/24)}d ago`;
}
function daysBetween(a: string, b: string) {
  return Math.round((new Date(b).getTime()-new Date(a).getTime())/(1000*60*60*24));
}
function daysFromNow(d: string) {
  const diff=new Date(d).getTime()-Date.now();
  const days=Math.round(diff/(1000*60*60*24));
  if(days<0)return `${Math.abs(days)} days overdue`;
  if(days===0)return "Due today";
  return `${days} days left`;
}

type Tab = "overview"|"milestones"|"tasks"|"financials"|"costplan"|"team"|"activity"|"messages";

const STATUS_CFG: Record<string,{color:string;bg:string;border:string}> = {
  active:   {color:"text-emerald-400",bg:"bg-emerald-500/10",border:"border-emerald-500/20"},
  planning: {color:"text-blue-400",   bg:"bg-blue-500/10",   border:"border-blue-500/20"},
  on_hold:  {color:"text-amber-400",  bg:"bg-amber-500/10",  border:"border-amber-500/20"},
  completed:{color:"text-purple-400", bg:"bg-purple-500/10", border:"border-purple-500/20"},
  cancelled:{color:"text-red-400",    bg:"bg-red-500/10",    border:"border-red-500/20"},
};

const MS_STATUS_CFG: Record<string,{color:string;bg:string;border:string;label:string}> = {
  planned:  {color:"text-slate-600 dark:text-slate-400",  bg:"bg-slate-500/10",  border:"border-slate-500/20",  label:"Planned"},
  active:   {color:"text-cyan-400",   bg:"bg-cyan-500/10",   border:"border-cyan-500/20",   label:"Active"},
  complete: {color:"text-emerald-400",bg:"bg-emerald-500/10",border:"border-emerald-500/20",label:"Complete"},
  on_hold:  {color:"text-amber-400",  bg:"bg-amber-500/10",  border:"border-amber-500/20",  label:"On Hold"},
};

const TASK_STATUS_CFG: Record<string,{color:string;bg:string;border:string}> = {
  planned:  {color:"text-slate-600 dark:text-slate-400",  bg:"bg-slate-500/10",  border:"border-slate-500/20"},
  active:   {color:"text-cyan-400",   bg:"bg-cyan-500/10",   border:"border-cyan-500/20"},
  complete: {color:"text-emerald-400",bg:"bg-emerald-500/10",border:"border-emerald-500/20"},
};

const TRADE_TYPES = [
  "General Labour","Mason","Carpenter","Painter","Electrician",
  "Plumber","Steel Fixer","Tiler","Welder","Equipment Operator",
  "Driver","Landscaping","Other"
];

const UNITS = ["m²","m³","m","no.","bag","block","ton","kg","L","hr","day","ls"];

// How far a task is: complete 100; otherwise its own percent; an active task with no percent counts 50; planned 0.
function taskPercent(t:{status?:string|null;percent_complete?:number|string|null}):number{
  if(t.status==="complete")return 100;
  const p=Number(t.percent_complete)||0;
  if(p>0)return Math.min(100,p);
  return t.status==="active"?50:0;
}

export default function ProjectDashboardPage() {
  const { projectId } = useParams();
  const nav = useNavigate();
  const [project, setProject] = useState<any>(null);
  const [client, setClient] = useState<any>(null);
  const [companyId, setCompanyId] = useState<string>("");
  const [stats, setStats] = useState({
    totalExpenses:0, pendingExpenses:0, openPOs:0, totalPOValue:0, activeWorkers:0,
  });
  const [activity, setActivity] = useState<any[]>([]);
  const [workers, setWorkers] = useState<any[]>([]);
  const [milestones, setMilestones] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("overview");
  const [error, setError] = useState<string|null>(null);

  // Milestone form
  const [showMSForm, setShowMSForm] = useState(false);
  const [editingMS, setEditingMS] = useState<any>(null);
  const [msForm, setMsForm] = useState({
    milestone_name:"", description:"", status:"planned",
    planned_start_date:"", planned_end_date:"",
    planned_labour_cost:"", planned_material_cost:"",
    planned_equipment_cost:"", crew_size_needed:"",
    production_rate_per_day:"", payment_amount:"",
  });
  const [savingMS, setSavingMS] = useState(false);
  // "Copy for bases…": the milestone being copied (null = modal closed)
  const [copyMS, setCopyMS] = useState<any|null>(null);
  // Milestone templates: "Save as template" (the milestone being saved), the "Add from template" picker, and the "Copy for bases now?" offer after adding
  const [saveTplMS, setSaveTplMS] = useState<any|null>(null);
  const [showTplPicker, setShowTplPicker] = useState(false);
  const [showBoqPicker, setShowBoqPicker] = useState(false);
  const [boqNote, setBoqNote] = useState<string|null>(null);
  // Task templates: the milestone the template's tasks go into (null = just manage the templates)
  const [tplTarget, setTplTarget] = useState<{id:string;milestone_name:string}|null>(null);

  // Task form
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [editingTask, setEditingTask] = useState<any>(null);
  const [selectedMilestoneId, setSelectedMilestoneId] = useState<string>("");
  const [taskForm, setTaskForm] = useState({
    task_name:"", task_description:"", trade_type:"General Labour",
    quantity:"", unit:"m²", rate_per_unit:"",
    start_date:"", end_date:"", status:"planned", milestone_id:"",
  });
  const [savingTask, setSavingTask] = useState(false);

  const hasMarkedRead = useRef(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [newReply, setNewReply] = useState("");
  const [sendingReply, setSendingReply] = useState(false);
  const [currentUser, setCurrentUser] = useState<{id:string; full_name?:string} | null>(null);
  const [userRole, setUserRole] = useState<string|null>(null);

  // Budget / cash flow
  const [contractAmount, setContractAmount] = useState(0);
  const [totalReceived, setTotalReceived] = useState(0);
  const [totalFieldPayments, setTotalFieldPayments] = useState(0);
  const [totalPOCommitments, setTotalPOCommitments] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [weeklyFieldPayments, setWeeklyFieldPayments] = useState(0);

  // Cost plan (Cost Plan tab)
  const [cpDuration, setCpDuration] = useState(6);
  const [cpTargetProfit, setCpTargetProfit] = useState(15);
  const [cpVehicles, setCpVehicles] = useState(1);
  const [cpVehicleCost, setCpVehicleCost] = useState(15000);
  const [cpOverheadPct, setCpOverheadPct] = useState(8);
  const [cpContingencyPct, setCpContingencyPct] = useState(5);
  const [cpStaff, setCpStaff] = useState<{
    workerId: string;
    name: string;
    role: string;
    monthlyRate: number;
    allocationPct: number;
  }[]>([]);
  const [availableWorkers, setAvailableWorkers] = useState<any[]>([]);
  const [addStaffId, setAddStaffId] = useState("");
  const [addStaffPct, setAddStaffPct] = useState(100);
  const [cpSaving, setCpSaving] = useState(false);
  const [cpLoaded, setCpLoaded] = useState(false);

  useEffect(()=>{ if(projectId) loadAll(); },[projectId]);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) {
        supabase.from("user_profiles").select("id, full_name, role").eq("id", data.user.id).maybeSingle()
          .then(({ data: profile }) => {
            setCurrentUser(profile);
            setUserRole(profile?.role || null);
          });
      }
    });
  }, []);

  useEffect(() => {
    if (tab !== "messages") {
      hasMarkedRead.current = false;
      return;
    }
    if (hasMarkedRead.current) return;
    const hasUnread = messages.some(m => m.sender_type === "client" && !m.read_at);
    if (!hasUnread) return;
    hasMarkedRead.current = true;
    setUnreadCount(0);
    supabase
      .from("client_comments")
      .update({ read_at: new Date().toISOString() })
      .eq("project_id", projectId!)
      .eq("sender_type", "client")
      .is("read_at", null)
      .then(() => loadMessages());
  }, [tab, messages]);

  async function loadAll() {
    setLoading(true); setError(null);
    try {
      const {data:proj,error:pe} = await supabase.from("projects")
        .select("id,name,status,client_id,start_date,end_date,notes,company_id,site_address,duration_months,target_profit_pct,overhead_budget")
        .eq("id",projectId!).maybeSingle();
      if(pe)throw pe;
      if(!proj)throw new Error("Project not found");
      setProject(proj);
      setCompanyId(proj.company_id||"");

      if(proj.client_id){
        const {data:cl}=await supabase.from("clients")
          .select("id,name,email,phone,address").eq("id",proj.client_id).maybeSingle();
        setClient(cl);
      }

      const [expRes,poRes,workerRes,msRes,taskRes,msgRes,contractRes,invoicesRes,fieldPmtRes,poItemsRes,expApprovedRes,cpWorkersRes,csRes,cpBudgetRes]=await Promise.allSettled([
        supabase.from("expenses").select("amount,description,created_at,status").eq("project_id",projectId!),
        supabase.from("purchase_orders").select("id,status,created_at,supplier_name").eq("project_id",projectId!),
        supabase.from("workers").select("id,first_name,last_name,worker_type,status").eq("company_id",proj.company_id||"").eq("status","active").limit(30),
        supabase.from("project_milestones").select("*").eq("project_id",projectId!).order("milestone_no",{ascending:true}),
        supabase.from("project_tasks").select("id,task_name,task_description,trade_type,quantity,unit,rate_per_unit,start_date,end_date,status,percent_complete,actual_quantity_completed,milestone_id").eq("project_id",projectId!).order("created_at",{ascending:true}),
        supabase.from("client_comments").select("*").eq("project_id",projectId!).order("created_at",{ascending:true}),
        // Active contract for this project (for contract value / profit view)
        supabase.from("client_contracts").select("contract_amount,retention_percent,status")
          .eq("project_id",projectId!).eq("status","active").order("created_at",{ascending:false}).limit(1),
        // Money received from client — summed via client_invoices.amount_paid, since
        // client_payments has no project_id column (only invoice_id); amount_paid is
        // kept in sync with actual payments by updateInvoiceAfterPayment().
        supabase.from("client_invoices").select("amount_paid").eq("project_id",projectId!),
        // Field payments (money out to labour). Every row is created with status
        // "signed" — there's no "approved" status on this table — so no status filter.
        supabase.from("field_payments").select("total_amount,payment_type,work_date").eq("project_id",projectId!),
        // PO commitments — amounts live on purchase_order_items, not purchase_orders itself
        supabase.from("purchase_order_items").select("total_amount,purchase_order_id,purchase_orders!inner(project_id,status)")
          .eq("purchase_orders.project_id",projectId!).neq("purchase_orders.status","cancelled"),
        supabase.from("expenses").select("amount").eq("project_id",projectId!).in("status",["approved","reimbursed"]),
        // Cost Plan: salaried/contract staff assignable as project overhead
        supabase.from("workers").select("id,first_name,last_name,pay_type,pay_rate,job_title")
          .eq("company_id",proj.company_id||"").eq("status","active").in("pay_type",["salary","contract"]),
        supabase.from("company_settings").select("company_overhead_pct,salary_period,estimate_contingency")
          .eq("company_id",proj.company_id||"").maybeSingle(),
        supabase.from("project_budgets").select("*").eq("project_id",projectId!).eq("category","overhead").eq("is_active",true).limit(1),
      ]);

      const expenses=expRes.status==="fulfilled"?expRes.value.data||[]:[];
      const pos=poRes.status==="fulfilled"?poRes.value.data||[]:[];
      const workerList=workerRes.status==="fulfilled"?workerRes.value.data||[]:[];
      const msList=msRes.status==="fulfilled"?msRes.value.data||[]:[];
      const taskList=taskRes.status==="fulfilled"?taskRes.value.data||[]:[];
      const msgList=msgRes.status==="fulfilled"?msgRes.value.data||[]:[];

      const contract=contractRes.status==="fulfilled"?(contractRes.value.data?.[0]||null):null;
      const invoices=invoicesRes.status==="fulfilled"?invoicesRes.value.data||[]:[];
      const fieldPmts=fieldPmtRes.status==="fulfilled"?fieldPmtRes.value.data||[]:[];
      const poItems=poItemsRes.status==="fulfilled"?poItemsRes.value.data||[]:[];
      const approvedExpenses=expApprovedRes.status==="fulfilled"?expApprovedRes.value.data||[]:[];

      setContractAmount(Number(contract?.contract_amount||0));
      setTotalReceived(invoices.reduce((s:number,i:any)=>s+(Number(i.amount_paid)||0),0));
      setTotalFieldPayments(fieldPmts.reduce((s:number,p:any)=>s+(Number(p.total_amount)||0),0));
      setTotalPOCommitments(poItems.reduce((s:number,p:any)=>s+(Number(p.total_amount)||0),0));
      setTotalExpenses(approvedExpenses.reduce((s:number,e:any)=>s+(Number(e.amount)||0),0));

      const oneWeekAgo=new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate()-7);
      setWeeklyFieldPayments(
        fieldPmts.filter((p:any)=>p.work_date&&new Date(p.work_date)>=oneWeekAgo)
          .reduce((s:number,p:any)=>s+(Number(p.total_amount)||0),0)
      );

      const cpWorkers=cpWorkersRes.status==="fulfilled"?cpWorkersRes.value.data||[]:[];
      setAvailableWorkers(cpWorkers);

      // Only apply saved cost-plan values once — a later manual refresh shouldn't
      // discard whatever the director is mid-editing on the Cost Plan tab.
      if(!cpLoaded){
        const cs=csRes.status==="fulfilled"?csRes.value.data:null;
        if(cs){
          setCpOverheadPct(cs.company_overhead_pct ?? 8);
          setCpContingencyPct(cs.estimate_contingency ?? 5);
        }
        setCpDuration(proj.duration_months||6);
        setCpTargetProfit(proj.target_profit_pct||15);

        const budgetRow=cpBudgetRes.status==="fulfilled"?(cpBudgetRes.value.data?.[0]||null):null;
        if(budgetRow?.description){
          try{
            const parsed=JSON.parse(budgetRow.description);
            if(Array.isArray(parsed.staff))setCpStaff(parsed.staff);
            if(parsed.vehicles!=null)setCpVehicles(Number(parsed.vehicles));
            if(parsed.vehicle_cost!=null)setCpVehicleCost(Number(parsed.vehicle_cost));
          }catch{/* description wasn't JSON — ignore, treat as no saved plan */}
        }
        setCpLoaded(true);
      }

      setWorkers(workerList);
      setMilestones(msList);
      setTasks(taskList);
      setMessages(msgList);
      setUnreadCount(msgList.filter((m:any)=>m.sender_type==="client"&&!m.read_at).length);

      setStats({
        // Approved + paid (reimbursed) only, the same as the Spend breakdown; pending shown apart; rejected never counts.
        // (It used to add up every expense, pending and rejected included.)
        totalExpenses:(expenses as {amount:number|null;status:string|null}[]).filter(e=>["approved","reimbursed"].includes(e.status||"")).reduce((s,e)=>s+(Number(e.amount)||0),0),
        pendingExpenses:(expenses as {amount:number|null;status:string|null}[]).filter(e=>e.status==="pending").reduce((s,e)=>s+(Number(e.amount)||0),0),
        openPOs:pos.filter((p:any)=>["pending","submitted","approved"].includes(p.status)).length,
        totalPOValue:0,
        activeWorkers:workerList.length,
      });

      const acts:any[]=[];
      pos.slice(0,5).forEach((p:any)=>acts.push({id:p.id,type:"po",label:`PO to ${p.supplier_name||"Supplier"}`,amount:0,time:p.created_at,status:p.status}));
      expenses.slice(0,5).forEach((e:any,i:number)=>acts.push({id:`exp-${i}`,type:"expense",label:e.description||"Expense",amount:e.amount,time:e.created_at||new Date().toISOString()}));
      acts.sort((a,b)=>new Date(b.time).getTime()-new Date(a.time).getTime());
      setActivity(acts.slice(0,8));
    } catch(e:any){setError(e.message||"Failed to load project");}
    setLoading(false);
  }

  async function loadMilestones() {
    const {data}=await supabase.from("project_milestones").select("*").eq("project_id",projectId!).order("milestone_no",{ascending:true});
    setMilestones(data||[]);
  }

  async function loadTasks() {
    const {data}=await supabase.from("project_tasks").select("id,task_name,task_description,trade_type,quantity,unit,rate_per_unit,start_date,end_date,status,percent_complete,actual_quantity_completed,milestone_id").eq("project_id",projectId!).order("created_at",{ascending:true});
    setTasks(data||[]);
  }

  async function loadMessages() {
    const { data } = await supabase
      .from("client_comments")
      .select("*")
      .eq("project_id", projectId!)
      .order("created_at", { ascending: true });
    setMessages(data || []);
    setUnreadCount((data || []).filter((m:any) => m.sender_type === "client" && !m.read_at).length);
  }

  async function sendReply() {
    if (!newReply.trim() || !currentUser) return;
    setSendingReply(true);
    const { error } = await supabase.from("client_comments").insert({
      project_id: projectId,
      client_id: project?.client_id || null,
      message: newReply,
      sender_type: "staff",
      sender_id: currentUser.id,
    });
    if (!error) { setNewReply(""); await loadMessages(); }
    setSendingReply(false);
  }

  // ── Milestone functions ──
  function openNewMS() {
    setEditingMS(null);
    setMsForm({milestone_name:"",description:"",status:"planned",planned_start_date:"",planned_end_date:"",planned_labour_cost:"",planned_material_cost:"",planned_equipment_cost:"",crew_size_needed:"",production_rate_per_day:"",payment_amount:""});
    setShowMSForm(true);
  }

  function openEditMS(ms: any) {
    setEditingMS(ms);
    setMsForm({
      milestone_name:ms.milestone_name||"",description:ms.description||"",status:ms.status||"planned",
      planned_start_date:ms.planned_start_date||"",planned_end_date:ms.planned_end_date||"",
      planned_labour_cost:String(ms.planned_labour_cost||""),planned_material_cost:String(ms.planned_material_cost||""),
      planned_equipment_cost:String(ms.planned_equipment_cost||""),crew_size_needed:String(ms.crew_size_needed||""),
      production_rate_per_day:String(ms.production_rate_per_day||""),payment_amount:String(ms.payment_amount||""),
    });
    setShowMSForm(true);
  }

  async function saveMS() {
    if(!msForm.milestone_name.trim()){alert("Milestone name required.");return;}
    setSavingMS(true);
    const labour=parseFloat(msForm.planned_labour_cost)||0;
    const material=parseFloat(msForm.planned_material_cost)||0;
    const equipment=parseFloat(msForm.planned_equipment_cost)||0;
    const payload:any={
      project_id:projectId, company_id:companyId,
      milestone_name:msForm.milestone_name.trim(),
      description:msForm.description.trim()||null,
      status:msForm.status||"planned",
      planned_start_date:msForm.planned_start_date||null,
      planned_end_date:msForm.planned_end_date||null,
      planned_labour_cost:labour,
      planned_material_cost:material,
      planned_equipment_cost:equipment,
      planned_total_cost:labour+material+equipment,
      crew_size_needed:parseFloat(msForm.crew_size_needed)||null,
      production_rate_per_day:parseFloat(msForm.production_rate_per_day)||null,
      payment_amount:parseFloat(msForm.payment_amount)||0,
      milestone_no:editingMS?editingMS.milestone_no:milestones.length+1,
    };
    if(editingMS){
      await supabase.from("project_milestones").update(payload).eq("id",editingMS.id);
    } else {
      await supabase.from("project_milestones").insert(payload);
    }
    setSavingMS(false); setShowMSForm(false);
    await loadMilestones();
  }

  async function deleteMS(id: string) {
    const n=tasks.filter(t=>t.milestone_id===id).length;
    if(!confirm(`Delete this milestone and all its tasks?${n>0?` (${n} task${n===1?"":"s"})`:""}`))return;
    const {error:taskErr}=await supabase.from("project_tasks").delete().eq("milestone_id",id);
    if(taskErr){alert("Could not delete the milestone's tasks: "+taskErr.message);await loadTasks();return;}
    const {error:msErr}=await supabase.from("project_milestones").delete().eq("id",id);
    if(msErr)alert("Could not delete the milestone: "+msErr.message);
    await loadMilestones(); await loadTasks();
  }

  async function updateMSStatus(id: string, status: string) {
    const updates:any={status};
    if(status==="active")updates.actual_start_date=new Date().toISOString().slice(0,10);
    if(status==="complete"){updates.actual_end_date=new Date().toISOString().slice(0,10);updates.percent_complete=100;}
    await supabase.from("project_milestones").update(updates).eq("id",id);
    setMilestones(prev=>prev.map(m=>m.id===id?{...m,...updates}:m));
  }

  // ── Task functions ──
  function openNewTask(milestoneId?: string) {
    setEditingTask(null);
    setTaskForm({task_name:"",task_description:"",trade_type:"General Labour",quantity:"",unit:"m²",rate_per_unit:"",start_date:"",end_date:"",status:"planned",milestone_id:milestoneId||""});
    setShowTaskForm(true);
  }

  function openEditTask(task: any) {
    setEditingTask(task);
    setTaskForm({
      task_name:task.task_name||"",task_description:task.task_description||"",
      trade_type:task.trade_type||"General Labour",quantity:String(task.quantity||""),
      unit:task.unit||"m²",rate_per_unit:String(task.rate_per_unit||""),
      start_date:task.start_date||"",end_date:task.end_date||"",
      status:task.status||"planned",milestone_id:task.milestone_id||"",
    });
    setShowTaskForm(true);
  }

  async function saveTask() {
    if(!taskForm.task_name.trim()){alert("Task name required.");return;}
    setSavingTask(true);
    const payload:any={
      project_id:projectId,
      task_name:taskForm.task_name.trim(),
      status:taskForm.status||"planned",
      start_date:taskForm.start_date||null,
      end_date:taskForm.end_date||null,
      milestone_id:taskForm.milestone_id||null,
    };
    if(taskForm.task_description.trim())payload.task_description=taskForm.task_description.trim();
    if(taskForm.trade_type)payload.trade_type=taskForm.trade_type;
    if(taskForm.quantity)payload.quantity=parseFloat(taskForm.quantity);
    if(taskForm.unit)payload.unit=taskForm.unit;
    if(taskForm.rate_per_unit)payload.rate_per_unit=parseFloat(taskForm.rate_per_unit);
    // Same mapping as the quick status buttons (complete 100, active 50, planned 0). Applied on create, whenever the status changes, and
    // always for "complete" (so it can never be complete at less than 100%); a plain edit of an active/planned task keeps its real percent.
    if(!editingTask||payload.status!==editingTask.status||payload.status==="complete"){
      payload.percent_complete=payload.status==="complete"?100:payload.status==="active"?50:0;
    }
    if(editingTask){
      await supabase.from("project_tasks").update(payload).eq("id",editingTask.id);
    } else {
      await supabase.from("project_tasks").insert(payload);
    }
    setSavingTask(false); setShowTaskForm(false);
    const {data:fresh}=await supabase.from("project_tasks").select("id,task_name,task_description,trade_type,quantity,unit,rate_per_unit,start_date,end_date,status,percent_complete,actual_quantity_completed,milestone_id").eq("project_id",projectId!).order("created_at",{ascending:true});
    setTasks(fresh||[]);
    const msIds=new Set([payload.milestone_id,editingTask?.milestone_id].filter(Boolean) as string[]);
    for(const m of msIds) await syncMilestoneFromTasks(m,fresh||[]);
  }

  async function deleteTask(id: string) {
    if(!confirm("Delete this task?"))return;
    await supabase.from("project_tasks").delete().eq("id",id);
    await loadTasks();
  }

  async function updateTaskStatus(id: string, status: string) {
    const percent_complete=status==="complete"?100:status==="active"?50:0;
    await supabase.from("project_tasks").update({status,percent_complete}).eq("id",id);
    const next=tasks.map(t=>t.id===id?{...t,status,percent_complete}:t);
    setTasks(next);
    const msId=next.find(t=>t.id===id)?.milestone_id;
    if(msId) await syncMilestoneFromTasks(msId,next);
  }

  // A milestone follows its tasks: its percent is the average of its tasks (complete 100, in progress 50 or the task's own
  // percent, planned 0). When every task is complete the milestone is complete; when one has started it is active; a
  // complete milestone whose task is reopened goes back to active. On hold is left alone.
  async function syncMilestoneFromTasks(msId: string, taskList: {milestone_id?:string|null;status?:string|null;percent_complete?:number|string|null}[]) {
    const ms=milestones.find(m=>m.id===msId);
    const list=taskList.filter(t=>t.milestone_id===msId);
    if(!ms||list.length===0)return;
    const pct=Math.round(list.reduce((s,t)=>s+taskPercent(t),0)/list.length);
    const allDone=list.every(t=>t.status==="complete");
    const anyStarted=list.some(t=>t.status==="complete"||t.status==="active"||Number(t.percent_complete)>0);
    const today=new Date().toISOString().slice(0,10);
    const updates:Record<string,unknown>={percent_complete:pct};
    if(ms.status!=="on_hold"){
      if(allDone&&ms.status!=="complete"){updates.status="complete";updates.actual_end_date=today;if(!ms.actual_start_date)updates.actual_start_date=today;}
      else if(!allDone&&ms.status==="complete"){updates.status="active";updates.actual_end_date=null;}
      else if(!allDone&&anyStarted&&ms.status==="planned"){updates.status="active";updates.actual_start_date=ms.actual_start_date||today;}
    }
    await supabase.from("project_milestones").update(updates).eq("id",msId);
    setMilestones(prev=>prev.map(m=>m.id===msId?{...m,...updates}:m));
  }if(loading)return(
    <div className="min-h-screen bg-slate-50 dark:bg-[#080b10] flex items-center justify-center">
      <div className="flex items-center gap-2.5 text-xs text-slate-500 dark:text-slate-600">
        <RefreshCw size={14} className="animate-spin text-cyan-500"/> Loading project…
      </div>
    </div>
  );

  if(error||!project)return(
    <div className="min-h-screen bg-slate-50 dark:bg-[#080b10] flex items-center justify-center p-6">
      <div className="text-center space-y-3">
        <AlertCircle size={32} className="text-red-400 mx-auto"/>
        <div className="text-sm text-slate-700 dark:text-slate-300">{error||"Project not found"}</div>
        <button onClick={()=>nav("/projects")} className="text-xs text-cyan-400 hover:text-cyan-300">← Back to Projects</button>
      </div>
    </div>
  );

  const spent=stats.totalExpenses;
  const statusCfg=STATUS_CFG[project.status]||STATUS_CFG.planning;
  const totalPlannedCost=milestones.reduce((s,m)=>s+(Number(m.planned_total_cost)||0),0);
  const totalActualCost=milestones.reduce((s,m)=>s+(Number(m.actual_total_cost)||0),0);
  const msComplete=milestones.filter(m=>m.status==="complete").length;
  // A milestone's progress: 100 when complete; otherwise from its tasks (average), else its own percent.
  const msProgress=(m:{id:string;status?:string|null;percent_complete?:number|string|null})=>{
    if(m.status==="complete")return 100;
    const list=tasks.filter(t=>t.milestone_id===m.id);
    if(list.length>0)return Math.round(list.reduce((s,t)=>s+taskPercent(t),0)/list.length);
    return Math.round(Number(m.percent_complete)||0);
  };
  // Overall = the average of the milestones' progress (it used to count only fully complete milestones, so finishing tasks never moved it).
  const overallProgress=milestones.length>0?Math.round(milestones.reduce((s,m)=>s+msProgress(m),0)/milestones.length):0;

  // Cash flow: money received from client vs money actually paid out
  const totalSpent=totalFieldPayments+totalPOCommitments+totalExpenses;
  const availableBalance=totalReceived-totalSpent;
  const stillToCollect=contractAmount-totalReceived;
  const estimatedProfit=contractAmount-totalSpent-(contractAmount*0.05); // rough estimate — 5% held back for overhead/contingency
  const balancePct=totalReceived>0?(availableBalance/totalReceived)*100:0;
  const nextWeekForecast=availableBalance-weeklyFieldPayments;

  // Cost plan: what this project actually costs to deliver, and what to charge
  const directCosts=totalSpent; // field payments + POs + expenses
  const staffCost=cpStaff.reduce((s,w)=>s+(w.monthlyRate*cpDuration*w.allocationPct/100),0);
  const vehicleCost=cpVehicles*cpVehicleCost*cpDuration;
  const overheadCost=directCosts*(cpOverheadPct/100);
  const totalOverhead=staffCost+vehicleCost+overheadCost;
  const totalProjectCost=directCosts+totalOverhead;
  const contingencyAmt=totalProjectCost*(cpContingencyPct/100);
  const totalWithContingency=totalProjectCost+contingencyAmt;
  const markupAmt=totalWithContingency*(cpTargetProfit/100);
  const recommendedPrice=totalWithContingency+markupAmt;
  const breakEvenPrice=totalWithContingency;
  const currentEstimateProfit=contractAmount-totalProjectCost;
  const currentMargin=contractAmount>0?(currentEstimateProfit/contractAmount)*100:0;

  const MODULES=[
    {label:"Site Visit",icon:<Layers size={15}/>,to:`/projects/${projectId}/site-visit`,color:"text-purple-400",bg:"bg-purple-500/10",border:"border-purple-500/20",desc:"Voice notes, photos, sketch"},
    {label:"Plans & Drawings",icon:<Map size={15}/>,to:`/projects/${projectId}/plans`,color:"text-cyan-400",bg:"bg-cyan-500/10",border:"border-cyan-500/20",desc:"Upload and view drawings"},
    {label:"BOQ Builder",icon:<FileText size={15}/>,to:`/projects/${projectId}/boq`,color:"text-blue-400",bg:"bg-blue-500/10",border:"border-blue-500/20",desc:"Bills of quantities"},
    {label:"Takeoff",icon:<Ruler size={15}/>,to:`/projects/${projectId}/takeoff`,color:"text-cyan-400",bg:"bg-cyan-500/10",border:"border-cyan-500/20",desc:"PDF measurements"},
    {label:"Procurement",icon:<ShoppingCart size={15}/>,to:`/projects/${projectId}/procurement`,color:"text-amber-400",bg:"bg-amber-500/10",border:"border-amber-500/20",desc:"Purchase orders"},
    {label:"Finance",icon:<Wallet size={15}/>,to:`/projects/${projectId}/finance`,color:"text-emerald-400",bg:"bg-emerald-500/10",border:"border-emerald-500/20",desc:"Project finances"},
    {label:"Reports",icon:<BarChart3 size={15}/>,to:`/projects/${projectId}/reports`,color:"text-violet-400",bg:"bg-violet-500/10",border:"border-violet-500/20",desc:"Analytics"},
    // the two folders for papers the client gives (ProjectFilesPage)
    {label:"Client BOQ",icon:<FolderOpen size={15}/>,to:`/projects/${projectId}/files?folder=client_boq`,color:"text-sky-400",bg:"bg-sky-500/10",border:"border-sky-500/20",desc:"The client's BOQ files"},
    {label:"Statements",icon:<FolderOpen size={15}/>,to:`/projects/${projectId}/files?folder=statement`,color:"text-lime-500",bg:"bg-lime-500/10",border:"border-lime-500/20",desc:"Payment statements"},
  ];

  const TABS:[{key:Tab;label:string;count?:number}] =[
    {key:"overview",label:"Overview"},
    {key:"milestones",label:"Milestones",count:milestones.length},
    {key:"tasks",label:"Tasks",count:tasks.length},
    {key:"financials",label:"Financials"},
    {key:"costplan",label:"Cost Plan"},
    {key:"team",label:"Team",count:stats.activeWorkers},
    {key:"activity",label:"Activity",count:activity.length},
    {key:"messages",label:"Messages",count:unreadCount},
  ] as any;

  return(
    <div className="min-h-screen bg-slate-50 dark:bg-[#080b10] text-slate-900 dark:text-slate-100">

      {/* Header */}
      <div className="border-b border-slate-200 dark:border-white/[0.06] bg-white dark:bg-[#0d1117] px-6 py-4">
        <div className="flex items-center justify-between gap-4 flex-wrap gap-y-2">
          <div className="flex items-center gap-3 min-w-0">
            <button onClick={()=>nav("/projects")} className="p-1.5 rounded-lg hover:bg-slate-200 dark:bg-white/[0.06] text-slate-500 dark:text-slate-600 hover:text-slate-700 dark:text-slate-300 transition flex-shrink-0">
              <ChevronLeft size={16}/>
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-slate-900 dark:text-slate-100 truncate">{project.name}</h1>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border capitalize ${statusCfg.color} ${statusCfg.bg} ${statusCfg.border}`}>
                  {project.status?.replace("_"," ")}
                </span>
              </div>
              <p className="text-xs text-slate-500">{client?.name||"No client assigned"}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button onClick={loadAll} className="p-2 rounded-lg bg-slate-50 dark:bg-white/[0.04] hover:bg-white/[0.07] border border-slate-200 dark:border-white/[0.08] text-slate-500 hover:text-slate-700 dark:text-slate-300 transition">
              <RefreshCw size={13}/>
            </button>
            <button onClick={()=>nav(`/projects/${projectId}/takeoff`)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.08] border border-slate-200 dark:border-white/[0.08] text-xs text-slate-700 dark:text-slate-300 font-semibold transition">
              <Ruler size={12}/> Takeoff
            </button>
            <button onClick={()=>nav(`/projects/${projectId}/boq`)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition">
              <FileText size={12}/> BOQ
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200 dark:border-white/[0.06] bg-white dark:bg-[#0d1117] px-6">
        <div className="flex gap-0 overflow-x-auto">
          {TABS.map((t:any)=>(
            <button key={t.key} onClick={()=>setTab(t.key)}
              className={`flex items-center gap-1.5 px-4 py-3 text-[11px] font-bold uppercase tracking-widest border-b-2 transition whitespace-nowrap ${tab===t.key?"border-cyan-500 text-cyan-300":"border-transparent text-slate-400 dark:text-slate-700 hover:text-slate-500"}`}>
              {t.label}
              {t.count!==undefined&&t.count>0&&(
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${tab===t.key?"bg-cyan-500/20 text-cyan-400":t.key==="messages"?"bg-red-500 text-white":"bg-slate-200 dark:bg-white/[0.06] text-slate-500 dark:text-slate-600"}`}>{t.count}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-5">{/* ── OVERVIEW ── */}
        {tab==="overview"&&(
          <>
            <FieldOfficerPortalCard projectId={projectId || ""} userRole={userRole} />
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
              {[
                {label:"Milestones",  value:`${msComplete}/${milestones.length}`, sub:"completed", color:"text-cyan-400",    bg:"bg-cyan-500/10",    border:"border-cyan-500/20",    icon:<Flag size={14}/>},
                {label:"Tasks",       value:tasks.length,                          sub:`${tasks.filter(t=>t.status==="complete").length} done`, color:"text-violet-400", bg:"bg-violet-500/10", border:"border-violet-500/20", icon:<ListTodo size={14}/>},
                {label:"Spent",       value:fmtShort(spent),                       sub:stats.pendingExpenses>0?`approved expenses · ${fmtShort(stats.pendingExpenses)} waiting`:"approved expenses", color:"text-amber-400",  bg:"bg-amber-500/10",   border:"border-amber-500/20",   icon:<Receipt size={14}/>},
                {label:"Team Size",   value:stats.activeWorkers,                   sub:"active workers", color:"text-emerald-400",bg:"bg-emerald-500/10", border:"border-emerald-500/20", icon:<Users size={14}/>},
              ].map(card=>(
                <div key={card.label} className={`rounded-xl border ${card.border} ${card.bg} p-4`}>
                  <div className={`${card.color} mb-2`}>{card.icon}</div>
                  <div className={`text-xl font-bold ${card.color}`}>{card.value}</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-600 uppercase tracking-wider font-semibold mt-0.5">{card.label}</div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-700 mt-0.5">{card.sub}</div>
                </div>
              ))}
              <div className={`rounded-xl border p-4 col-span-2 lg:col-span-1 ${
                availableBalance<0 ? "border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10" :
                balancePct<30 ? "border-amber-200 dark:border-amber-500/30 bg-amber-50 dark:bg-amber-500/10" :
                "border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10"
              }`}>
                <div className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${
                  availableBalance<0 ? "text-red-500" : balancePct<30 ? "text-amber-500" : "text-emerald-500"
                }`}>
                  {availableBalance<0 ? "🔴 Overspent" : balancePct<30 ? "🟡 Low Balance" : "🟢 Available"}
                </div>
                <div className={`text-xl font-black ${
                  availableBalance<0 ? "text-red-700 dark:text-red-400" :
                  balancePct<30 ? "text-amber-700 dark:text-amber-400" :
                  "text-emerald-700 dark:text-emerald-400"
                }`}>
                  {fmtShort(availableBalance)}
                </div>
                <div className="text-[10px] text-slate-500 dark:text-slate-600 uppercase tracking-wider font-semibold mt-0.5">Balance</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-700 mt-0.5">available to spend</div>
              </div>
            </div>

            {/* Overall Progress */}
            {milestones.length>0&&(
              <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-bold text-slate-800 dark:text-slate-200">Overall Project Progress</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-600 mt-0.5">{msComplete} of {milestones.length} milestones complete · {tasks.filter(t=>t.status==="complete").length} of {tasks.length} tasks done</div>
                  </div>
                  <div className="text-2xl font-bold text-cyan-400">{overallProgress}%</div>
                </div>
                <div className="w-full bg-slate-200 dark:bg-white/[0.06] rounded-full h-3">
                  <div className="h-3 rounded-full bg-cyan-500 transition-all" style={{width:`${overallProgress}%`}}/>
                </div>
                <div className="flex gap-2 mt-3 flex-wrap">
                  {milestones.map(m=>{
                    const cfg=MS_STATUS_CFG[m.status]||MS_STATUS_CFG.planned;
                    return(
                      <div key={m.id} className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[10px] font-semibold ${cfg.color} ${cfg.bg} ${cfg.border}`}>
                        {m.status==="complete"?<CheckCircle2 size={10}/>:<Clock size={10}/>}
                        {m.milestone_name}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Module links */}
            <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] overflow-hidden">
              <div className="px-5 py-3 border-b border-slate-200 dark:border-white/[0.06]">
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Project Modules</span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-5">
                {MODULES.map((m,i)=>(
                  <button key={m.to} onClick={()=>nav(m.to)}
                    className={`flex flex-col items-center gap-2 p-5 hover:bg-white/[0.03] transition group ${i<MODULES.length-1?"border-r border-slate-100 dark:border-white/[0.04]":""}`}>
                    <div className={`w-11 h-11 rounded-xl border flex items-center justify-center transition-transform group-hover:scale-110 ${m.bg} ${m.border}`}>
                      <span className={m.color}>{m.icon}</span>
                    </div>
                    <div className="text-center">
                      <div className="text-xs font-semibold text-slate-600 dark:text-slate-400 group-hover:text-white transition">{m.label}</div>
                      <div className="text-[9px] text-slate-400 dark:text-slate-700 mt-0.5">{m.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Project info + Client */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] p-5">
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 mb-4">Project Details</div>
                <div className="space-y-3">
                  {[
                    {label:"Status",  value:<span className={`text-xs font-bold capitalize ${statusCfg.color}`}>{project.status?.replace("_"," ")}</span>},
                    {label:"Start",   value:<span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{project.start_date?new Date(project.start_date).toLocaleDateString():"—"}</span>},
                    {label:"End",     value:<span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{project.end_date?new Date(project.end_date).toLocaleDateString():"—"}</span>},
                    {label:"Milestones",value:<span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{milestones.length}</span>},
                    {label:"Tasks",   value:<span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{tasks.length}</span>},
                    {label:"Open POs",value:<span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{stats.openPOs}</span>},
                  ].map(row=>(
                    <div key={row.label} className="flex items-center justify-between">
                      <span className="text-[11px] text-slate-500 dark:text-slate-600">{row.label}</span>
                      {row.value}
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] p-5">
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 mb-4">Client</div>
                {client?(
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                        <Building2 size={16} className="text-cyan-400"/>
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-800 dark:text-slate-200">{client.name}</div>
                        {client.email&&<div className="text-[10px] text-slate-500 dark:text-slate-600">{client.email}</div>}
                      </div>
                    </div>
                    {client.phone&&<div className="flex justify-between"><span className="text-[11px] text-slate-500 dark:text-slate-600">Phone</span><span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{client.phone}</span></div>}
                    {client.address&&<div className="flex justify-between"><span className="text-[11px] text-slate-500 dark:text-slate-600">Address</span><span className="text-xs text-slate-700 dark:text-slate-300 font-semibold truncate max-w-[160px]">{client.address}</span></div>}
                  </div>
                ):(
                  <div className="flex flex-col items-center justify-center py-6 gap-2">
                    <Building2 size={20} className="text-slate-400 dark:text-slate-700"/>
                    <p className="text-xs text-slate-500 dark:text-slate-600">No client assigned</p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}{/* ── MILESTONES ── */}
        {tab==="milestones"&&(
          <>
            {/* Milestone Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                {label:"Total",    value:milestones.length,                              color:"text-slate-700 dark:text-slate-300",   bg:"bg-slate-50 dark:bg-white/[0.04]",   border:"border-slate-200 dark:border-white/[0.07]"},
                {label:"Planned",  value:milestones.filter(m=>m.status==="planned").length,  color:"text-slate-600 dark:text-slate-400",   bg:"bg-slate-500/10",   border:"border-slate-500/20"},
                {label:"Active",   value:milestones.filter(m=>m.status==="active").length,   color:"text-cyan-400",    bg:"bg-cyan-500/10",    border:"border-cyan-500/20"},
                {label:"Complete", value:milestones.filter(m=>m.status==="complete").length, color:"text-emerald-400", bg:"bg-emerald-500/10", border:"border-emerald-500/20"},
              ].map(s=>(
                <div key={s.label} className={`rounded-xl border ${s.border} ${s.bg} p-3 text-center`}>
                  <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
                  <div className="text-[9px] text-slate-500 dark:text-slate-600 uppercase tracking-wider font-semibold mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            {/* Budget Summary */}
            {totalPlannedCost>0&&(
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  {label:"Planned Budget",  value:fmtJMD(totalPlannedCost), color:"text-blue-400",    bg:"bg-blue-500/10",    border:"border-blue-500/20"},
                  {label:"Actual Cost",     value:fmtJMD(totalActualCost),  color:"text-amber-400",   bg:"bg-amber-500/10",   border:"border-amber-500/20"},
                  {label:"Variance",        value:fmtJMD(totalPlannedCost-totalActualCost), color:totalActualCost>totalPlannedCost?"text-red-400":"text-emerald-400", bg:totalActualCost>totalPlannedCost?"bg-red-500/10":"bg-emerald-500/10", border:totalActualCost>totalPlannedCost?"border-red-500/20":"border-emerald-500/20"},
                ].map(s=>(
                  <div key={s.label} className={`rounded-xl border ${s.border} ${s.bg} p-4`}>
                    <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-600 uppercase tracking-wider font-semibold mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200">Project Milestones</span>
              <div className="flex items-center gap-2">
                <button onClick={()=>{ setTplTarget(null); setShowTplPicker(true); }}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 dark:bg-white/[0.05] border border-slate-200 dark:border-white/[0.08] text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-white/[0.09] transition">
                  <LayoutTemplate size={12}/> Task templates
                </button>
                <button onClick={()=>setShowBoqPicker(true)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 dark:bg-white/[0.05] border border-slate-200 dark:border-white/[0.08] text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-white/[0.09] transition">
                  <FileText size={12}/> Add from BOQ
                </button>
                <button onClick={openNewMS}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition">
                  <Plus size={12}/> Add Milestone
                </button>
              </div>
            </div>

            {/* Milestone Form Modal */}
            {saveTplMS&&(
              <SaveAsTemplateModal
                milestone={saveTplMS}
                taskCount={tasks.filter(t=>t.milestone_id===saveTplMS.id).length}
                onClose={()=>setSaveTplMS(null)}
                onSaved={(name)=>{
                  setSaveTplMS(null);
                  setBoqNote(`Saved to the task template "${name}". Use "Tasks from template" on any milestone to add these tasks.`);
                }}
              />
            )}
            {boqNote&&(
              <div className="flex items-start justify-between gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-800 dark:text-emerald-200">
                <span>{boqNote}</span>
                <button onClick={()=>setBoqNote(null)} className="text-emerald-700 dark:text-emerald-300">✕</button>
              </div>
            )}
            <BoqToMilestonesModal open={showBoqPicker} onClose={()=>setShowBoqPicker(false)} projectId={projectId||""} companyId={companyId||null}
              milestones={milestones} existingNames={[...milestones.map(m=>String(m.milestone_name||"")),...tasks.map(t=>String(t.task_name||""))]}
              onDone={async(msg)=>{ setBoqNote(msg); await loadMilestones(); await loadTasks(); }}/>
            {showTplPicker&&(
              <MilestoneTemplatesModal
                projectId={projectId||""}
                milestone={tplTarget}
                existingTaskNames={tplTarget?tasks.filter(t=>t.milestone_id===tplTarget.id).map(t=>String(t.task_name||"")):[]}
                onClose={()=>{ setShowTplPicker(false); setTplTarget(null); }}
                onApplied={async(added,skipped,name)=>{
                  const into=tplTarget?.milestone_name||"the milestone";
                  setShowTplPicker(false); setTplTarget(null);
                  await loadTasks(); await loadMilestones();
                  setBoqNote(added>0
                    ? `${added} task${added===1?"":"s"} from "${name}" added to "${into}".${skipped>0?` ${skipped} already there ${skipped===1?"was":"were"} skipped.`:""}`
                    : `Nothing added: all ${skipped} task${skipped===1?"":"s"} from "${name}" ${skipped===1?"is":"are"} already in "${into}".`);
                }}
              />
            )}
            {copyMS&&(
              <CopyMilestoneForBasesModal
                projectId={projectId||""}
                milestone={copyMS}
                taskCount={tasks.filter(t=>t.milestone_id===copyMS.id).length}
                existingMilestoneNames={milestones.map(m=>m.milestone_name)}
                originalHasProgress={
                  copyMS.status!=="planned"||Number(copyMS.percent_complete)>0||Number(copyMS.actual_total_cost)>0||
                  tasks.some(t=>t.milestone_id===copyMS.id&&(t.status!=="planned"||Number(t.percent_complete)>0||Number(t.actual_quantity_completed)>0))
                }
                onClose={()=>setCopyMS(null)}
                onDone={async(created,removed)=>{
                  setCopyMS(null);
                  await loadMilestones(); await loadTasks();
                  alert(`Created ${created} milestone${created===1?"":"s"} with their tasks.${removed?" The original template was removed.":""}`);
                }}
              />
            )}
            {showMSForm&&(
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0d1117] shadow-2xl max-h-[90vh] overflow-y-auto">
                  <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/[0.07] sticky top-0 bg-white dark:bg-[#0d1117]">
                    <span className="text-sm font-bold text-slate-900 dark:text-slate-100">{editingMS?"Edit Milestone":"New Milestone"}</span>
                    <button onClick={()=>setShowMSForm(false)} className="p-1.5 rounded-lg hover:bg-slate-200 dark:bg-white/[0.06] text-slate-500"><X size={14}/></button>
                  </div>
                  <div className="p-5 space-y-3">
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Milestone Name *</label>
                      <input value={msForm.milestone_name} onChange={e=>setMsForm(f=>({...f,milestone_name:e.target.value}))}
                        placeholder="e.g. Foundation Phase, Superstructure, Roofing..."
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                    </div>
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Description</label>
                      <textarea value={msForm.description} onChange={e=>setMsForm(f=>({...f,description:e.target.value}))}
                        placeholder="What does this milestone involve..." rows={2}
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50 resize-none"/>
                    </div>
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Status</label>
                      <select value={msForm.status} onChange={e=>setMsForm(f=>({...f,status:e.target.value}))}
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none [&>option]:bg-white dark:[&>option]:bg-[#111820]">
                        <option value="planned">Planned</option>
                        <option value="active">Active</option>
                        <option value="complete">Complete</option>
                        <option value="on_hold">On Hold</option>
                      </select>
                    </div>

                    {/* Timeline */}
                    <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-slate-50 dark:bg-white/[0.02] p-3 space-y-3">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Timeline</div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Planned Start</label>
                          <input type="date" value={msForm.planned_start_date} onChange={e=>setMsForm(f=>({...f,planned_start_date:e.target.value}))}
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none focus:border-cyan-500/50"/>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Planned End</label>
                          <input type="date" value={msForm.planned_end_date} onChange={e=>setMsForm(f=>({...f,planned_end_date:e.target.value}))}
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none focus:border-cyan-500/50"/>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Crew Size Needed</label>
                          <input type="number" value={msForm.crew_size_needed} onChange={e=>setMsForm(f=>({...f,crew_size_needed:e.target.value}))}
                            placeholder="e.g. 5"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Production Rate/Day</label>
                          <input type="number" value={msForm.production_rate_per_day} onChange={e=>setMsForm(f=>({...f,production_rate_per_day:e.target.value}))}
                            placeholder="e.g. 100 blocks/day"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                        </div>
                      </div>
                    </div>

                    {/* Budget */}
                    <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-slate-50 dark:bg-white/[0.02] p-3 space-y-3">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Planned Budget (JMD)</div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Labour</label>
                          <input type="number" value={msForm.planned_labour_cost} onChange={e=>setMsForm(f=>({...f,planned_labour_cost:e.target.value}))}
                            placeholder="0"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Materials</label>
                          <input type="number" value={msForm.planned_material_cost} onChange={e=>setMsForm(f=>({...f,planned_material_cost:e.target.value}))}
                            placeholder="0"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Equipment</label>
                          <input type="number" value={msForm.planned_equipment_cost} onChange={e=>setMsForm(f=>({...f,planned_equipment_cost:e.target.value}))}
                            placeholder="0"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                        </div>
                      </div>
                      {(msForm.planned_labour_cost||msForm.planned_material_cost||msForm.planned_equipment_cost)&&(
                        <div className="text-xs text-slate-500 text-center">
                          Total: <span className="text-cyan-400 font-bold">{fmtJMD((parseFloat(msForm.planned_labour_cost)||0)+(parseFloat(msForm.planned_material_cost)||0)+(parseFloat(msForm.planned_equipment_cost)||0))}</span>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Contract Payment Amount (JMD)</label>
                      <input type="number" value={msForm.payment_amount} onChange={e=>setMsForm(f=>({...f,payment_amount:e.target.value}))}
                        placeholder="Amount client pays when this milestone is complete"
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                    </div>
                  </div>
                  <div className="flex gap-2 px-5 py-4 border-t border-slate-200 dark:border-white/[0.07]">
                    <button onClick={()=>setShowMSForm(false)}
                      className="px-4 py-2 rounded-lg bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.07] text-sm text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:text-slate-200 transition">Cancel</button>
                    <button onClick={saveMS} disabled={savingMS||!msForm.milestone_name.trim()}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-semibold disabled:opacity-40 transition">
                      <Save size={13}/>{savingMS?"Saving…":editingMS?"Update Milestone":"Create Milestone"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Milestone List */}
            {milestones.length===0?(
              <div className="flex flex-col items-center justify-center py-16 gap-3 text-center rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117]">
                <Flag size={24} className="text-slate-400 dark:text-slate-700"/>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-medium">No milestones yet</p>
                <p className="text-slate-400 dark:text-slate-700 text-xs">Break your project into phases — Foundation, Superstructure, Roofing...</p>
                <button onClick={openNewMS}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition mt-1">
                  <Plus size={12}/> Add First Milestone
                </button>
              </div>
            ):(
              <div className="flex flex-col gap-4">
                {milestones.map(ms=>{
                  const cfg=MS_STATUS_CFG[ms.status]||MS_STATUS_CFG.planned;
                  const msTasks=tasks.filter(t=>t.milestone_id===ms.id);
                  const msTasksDone=msTasks.filter(t=>t.status==="complete").length;
                  const daysPlanned=ms.planned_start_date&&ms.planned_end_date?daysBetween(ms.planned_start_date,ms.planned_end_date):null;
                  const prediction=ms.planned_end_date&&ms.status!=="complete"?daysFromNow(ms.planned_end_date):null;
                  return(
                    <div key={ms.id} className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] overflow-hidden">
                      {/* Milestone Header */}
                      <div className="p-4 flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-600">#{ms.milestone_no}</span>
                            <span className="text-sm font-bold text-slate-800 dark:text-slate-200">{ms.milestone_name}</span>
                            <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold border ${cfg.color} ${cfg.bg} ${cfg.border}`}>{cfg.label}</span>
                          </div>
                          {ms.description&&<p className="text-[11px] text-slate-500 dark:text-slate-600 mb-2">{ms.description}</p>}

                          {/* Timeline info */}
                          <div className="flex flex-wrap gap-3 text-[10px] text-slate-500 dark:text-slate-600">
                            {ms.planned_start_date&&<span>📅 Start: {new Date(ms.planned_start_date).toLocaleDateString("en-US",{month:"short",day:"numeric"})}</span>}
                            {ms.planned_end_date&&<span>🏁 End: {new Date(ms.planned_end_date).toLocaleDateString("en-US",{month:"short",day:"numeric"})}</span>}
                            {daysPlanned&&<span>⏱ {daysPlanned} days planned</span>}
                            {ms.crew_size_needed&&<span>👷 {ms.crew_size_needed} workers needed</span>}
                            {prediction&&<span className={prediction.includes("overdue")?"text-red-400 font-semibold":"text-amber-400"}>⚠️ {prediction}</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button onClick={()=>openNewTask(ms.id)}
                            className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-semibold hover:bg-cyan-500/20 transition">
                            <Plus size={10}/> Task
                          </button>
                          <button onClick={()=>{ setTplTarget({id:ms.id,milestone_name:ms.milestone_name}); setShowTplPicker(true); }} title="Add tasks from a task template"
                            className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-semibold hover:bg-cyan-500/20 transition">
                            <LayoutTemplate size={10}/> Tasks from template
                          </button>
                          <button onClick={()=>setSaveTplMS(ms)} title="Save this milestone's tasks as a task template"
                            className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-slate-100 dark:bg-white/[0.05] border border-slate-200 dark:border-white/[0.08] text-slate-600 dark:text-slate-300 text-[10px] font-semibold hover:bg-slate-200 dark:hover:bg-white/[0.09] transition">
                            <BookmarkPlus size={10}/> Save tasks as template
                          </button>
                          <button onClick={()=>setCopyMS(ms)} title="Copy for bases…"
                            className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-slate-100 dark:bg-white/[0.05] border border-slate-200 dark:border-white/[0.08] text-slate-600 dark:text-slate-300 text-[10px] font-semibold hover:bg-slate-200 dark:hover:bg-white/[0.09] transition">
                            <Copy size={10}/> Copy for bases…
                          </button>
                          <button onClick={()=>openEditMS(ms)} className="p-1.5 rounded-lg hover:bg-slate-200 dark:bg-white/[0.06] text-slate-500 dark:text-slate-600 hover:text-slate-700 dark:text-slate-300 transition"><Edit2 size={12}/></button>
                          <button onClick={()=>deleteMS(ms.id)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-slate-500 dark:text-slate-600 hover:text-red-400 transition"><Trash2 size={12}/></button>
                        </div>
                      </div>

                      {/* Budget Row */}
                      {ms.planned_total_cost>0&&(
                        <div className="px-4 py-2 border-t border-slate-100 dark:border-white/[0.04] grid grid-cols-3 gap-4 bg-slate-50 dark:bg-white/[0.01]">
                          {[
                            {label:"Planned",value:fmtJMD(ms.planned_total_cost),color:"text-blue-400"},
                            {label:"Actual", value:fmtJMD(ms.actual_total_cost||0),color:"text-amber-400"},
                            {label:"Payment",value:fmtJMD(ms.payment_amount||0),color:"text-emerald-400"},
                          ].map(b=>(
                            <div key={b.label} className="text-center">
                              <div className={`text-sm font-bold ${b.color}`}>{b.value}</div>
                              <div className="text-[9px] text-slate-400 dark:text-slate-700 uppercase tracking-wider">{b.label}</div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Tasks under milestone */}
                      {msTasks.length>0&&(
                        <div className="border-t border-slate-100 dark:border-white/[0.04]">
                          <div className="px-4 py-2 flex items-center justify-between">
                            <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Tasks ({msTasksDone}/{msTasks.length} done)</span>
                          </div>
                          {msTasks.map(t=>{
                            const tcfg=TASK_STATUS_CFG[t.status]||TASK_STATUS_CFG.planned;
                            const tTotal=(parseFloat(t.quantity)||0)*(parseFloat(t.rate_per_unit)||0);
                            return(
                              <div key={t.id} className="flex items-center gap-3 px-4 py-2.5 border-t border-white/[0.03] hover:bg-slate-50 dark:bg-white/[0.02] transition">
                                <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold border ${tcfg.color} ${tcfg.bg} ${tcfg.border}`}>{t.status}</span>
                                <div className="flex-1 min-w-0">
                                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">{t.task_name}</div>
                                  {t.trade_type&&<div className="text-[9px] text-slate-500 dark:text-slate-600">{t.trade_type}</div>}
                                </div>
                                {t.quantity&&<span className="text-[10px] text-slate-500 dark:text-slate-600">{t.quantity} {t.unit||""}</span>}
                                {tTotal>0&&<span className="text-xs font-bold text-emerald-400">{fmtJMD(tTotal)}</span>}
                                <div className="flex items-center gap-1">
                                  <button onClick={()=>openEditTask(t)} className="p-1 rounded hover:bg-slate-200 dark:bg-white/[0.06] text-slate-500 dark:text-slate-600 hover:text-slate-700 dark:text-slate-300"><Edit2 size={10}/></button>
                                  <button onClick={()=>deleteTask(t.id)} className="p-1 rounded hover:bg-red-500/10 text-slate-500 dark:text-slate-600 hover:text-red-400"><Trash2 size={10}/></button>
                                  <select value={t.status} onChange={e=>updateTaskStatus(t.id,e.target.value)}
                                    className="text-[9px] bg-slate-50 dark:bg-[#080b10] border border-slate-200 dark:border-white/[0.07] rounded px-1 py-0.5 text-slate-500 outline-none">
                                    <option value="planned">Planned</option>
                                    <option value="active">Active</option>
                                    <option value="complete">Complete</option>
                                  </select>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Milestone footer - status change */}
                      <div className="px-4 py-2.5 border-t border-slate-100 dark:border-white/[0.04] flex items-center justify-between gap-3 bg-slate-50 dark:bg-white/[0.01]">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-600 mb-1">
                            <span>{msTasks.length} tasks · {msTasksDone} complete</span>
                            <span className="font-bold text-cyan-500">{msProgress(ms)}%</span>
                          </div>
                          <div className="w-full bg-slate-200 dark:bg-white/[0.06] rounded-full h-1.5">
                            <div className="h-1.5 rounded-full bg-cyan-500 transition-all" style={{width:`${msProgress(ms)}%`}}/>
                          </div>
                        </div>
                        <select value={ms.status} onChange={e=>updateMSStatus(ms.id,e.target.value)}
                          className="text-[10px] bg-slate-50 dark:bg-[#080b10] border border-slate-200 dark:border-white/[0.07] rounded px-2 py-1 text-slate-600 dark:text-slate-400 outline-none">
                          <option value="planned">Planned</option>
                          <option value="active">Active</option>
                          <option value="complete">Complete</option>
                          <option value="on_hold">On Hold</option>
                        </select>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}{/* ── TASKS ── */}
        {(tab==="tasks"||showTaskForm)&&(
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                {label:"Total",    value:tasks.length,                                color:"text-slate-700 dark:text-slate-300",   bg:"bg-slate-50 dark:bg-white/[0.04]",   border:"border-slate-200 dark:border-white/[0.07]"},
                {label:"Planned",  value:tasks.filter(t=>t.status==="planned").length, color:"text-slate-600 dark:text-slate-400",   bg:"bg-slate-500/10",   border:"border-slate-500/20"},
                {label:"Active",   value:tasks.filter(t=>t.status==="active").length,  color:"text-cyan-400",    bg:"bg-cyan-500/10",    border:"border-cyan-500/20"},
                {label:"Complete", value:tasks.filter(t=>t.status==="complete").length,color:"text-emerald-400", bg:"bg-emerald-500/10", border:"border-emerald-500/20"},
              ].map(s=>(
                <div key={s.label} className={`rounded-xl border ${s.border} ${s.bg} p-3 text-center`}>
                  <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
                  <div className="text-[9px] text-slate-500 dark:text-slate-600 uppercase tracking-wider font-semibold mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200">All Tasks</span>
              <button onClick={()=>openNewTask()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition">
                <Plus size={12}/> Add Task
              </button>
            </div>

            {/* Task Form Modal */}
            {showTaskForm&&(
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0d1117] shadow-2xl max-h-[90vh] overflow-y-auto">
                  <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/[0.07] sticky top-0 bg-white dark:bg-[#0d1117]">
                    <span className="text-sm font-bold text-slate-900 dark:text-slate-100">{editingTask?"Edit Task":"New Task"}</span>
                    <button onClick={()=>setShowTaskForm(false)} className="p-1.5 rounded-lg hover:bg-slate-200 dark:bg-white/[0.06] text-slate-500"><X size={14}/></button>
                  </div>
                  <div className="p-5 space-y-3">
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Milestone</label>
                      <select value={taskForm.milestone_id} onChange={e=>setTaskForm(f=>({...f,milestone_id:e.target.value}))}
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none [&>option]:bg-white dark:[&>option]:bg-[#111820]">
                        <option value="">No milestone</option>
                        {milestones.map(m=><option key={m.id} value={m.id}>{m.milestone_name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Task Name *</label>
                      <input value={taskForm.task_name} onChange={e=>setTaskForm(f=>({...f,task_name:e.target.value}))}
                        placeholder="e.g. Lay foundation blocks, Paint exterior walls..."
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50"/>
                    </div>
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Description</label>
                      <textarea value={taskForm.task_description} onChange={e=>setTaskForm(f=>({...f,task_description:e.target.value}))}
                        placeholder="What exactly needs to be done..." rows={2}
                        className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-700 outline-none focus:border-cyan-500/50 resize-none"/>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Trade Type</label>
                        <select value={taskForm.trade_type} onChange={e=>setTaskForm(f=>({...f,trade_type:e.target.value}))}
                          className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none [&>option]:bg-white dark:[&>option]:bg-[#111820]">
                          {TRADE_TYPES.map(t=><option key={t} value={t}>{t}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Status</label>
                        <select value={taskForm.status} onChange={e=>setTaskForm(f=>({...f,status:e.target.value}))}
                          className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none [&>option]:bg-white dark:[&>option]:bg-[#111820]">
                          <option value="planned">Planned</option>
                          <option value="active">Active</option>
                          <option value="complete">Complete</option>
                        </select>
                      </div>
                    </div>
                    <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-slate-50 dark:bg-white/[0.02] p-3 space-y-3">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Quantity & Rate (for field payments)</div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Quantity</label>
                          <input type="number" value={taskForm.quantity} onChange={e=>setTaskForm(f=>({...f,quantity:e.target.value}))} placeholder="0"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none focus:border-cyan-500/50"/>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Unit</label>
                          <select value={taskForm.unit} onChange={e=>setTaskForm(f=>({...f,unit:e.target.value}))}
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none [&>option]:bg-white dark:[&>option]:bg-[#111820]">
                            {UNITS.map(u=><option key={u} value={u}>{u}</option>)}
                          </select>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Rate/Unit (JMD)</label>
                          <input type="number" value={taskForm.rate_per_unit} onChange={e=>setTaskForm(f=>({...f,rate_per_unit:e.target.value}))} placeholder="0.00"
                            className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none focus:border-cyan-500/50"/>
                        </div>
                      </div>
                      {taskForm.quantity&&taskForm.rate_per_unit&&(
                        <div className="text-xs text-slate-500 text-center">
                          {taskForm.quantity} {taskForm.unit} × {fmtJMD(parseFloat(taskForm.rate_per_unit)||0)} = <span className="text-emerald-400 font-bold">{fmtJMD((parseFloat(taskForm.quantity)||0)*(parseFloat(taskForm.rate_per_unit)||0))}</span>
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">Start Date</label>
                        <input type="date" value={taskForm.start_date} onChange={e=>setTaskForm(f=>({...f,start_date:e.target.value}))}
                          className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none"/>
                      </div>
                      <div>
                        <label className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600 block mb-1">End Date</label>
                        <input type="date" value={taskForm.end_date} onChange={e=>setTaskForm(f=>({...f,end_date:e.target.value}))}
                          className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2.5 text-sm text-slate-800 dark:text-slate-200 outline-none"/>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 px-5 py-4 border-t border-slate-200 dark:border-white/[0.07]">
                    <button onClick={()=>setShowTaskForm(false)}
                      className="px-4 py-2 rounded-lg bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.07] text-sm text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:text-slate-200 transition">Cancel</button>
                    <button onClick={saveTask} disabled={savingTask||!taskForm.task_name.trim()}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-semibold disabled:opacity-40 transition">
                      <Save size={13}/>{savingTask?"Saving…":editingTask?"Update Task":"Create Task"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {tasks.length===0?(
              <div className="flex flex-col items-center justify-center py-16 gap-3 text-center rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117]">
                <ListTodo size={24} className="text-slate-400 dark:text-slate-700"/>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-medium">No tasks yet</p>
                <p className="text-slate-400 dark:text-slate-700 text-xs">Add milestones first, then add tasks to each milestone</p>
                <button onClick={()=>setTab("milestones")}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition mt-1">
                  <Flag size={12}/> Go to Milestones
                </button>
              </div>
            ):(
              <div className="flex flex-col gap-3">
                {tasks.map(task=>{
                  const cfg=TASK_STATUS_CFG[task.status]||TASK_STATUS_CFG.planned;
                  const totalValue=(parseFloat(task.quantity)||0)*(parseFloat(task.rate_per_unit)||0);
                  const ms=milestones.find(m=>m.id===task.milestone_id);
                  return(
                    <div key={task.id} className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] p-4">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex-1 min-w-0">
                          {ms&&<div className="text-[9px] text-cyan-600 font-bold uppercase tracking-wider mb-1">📍 {ms.milestone_name}</div>}
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-sm font-bold text-slate-800 dark:text-slate-200">{task.task_name}</span>
                            <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold border capitalize ${cfg.color} ${cfg.bg} ${cfg.border}`}>{task.status}</span>
                          </div>
                          {task.task_description&&<p className="text-[11px] text-slate-500 dark:text-slate-600 mb-1">{task.task_description}</p>}
                          {task.trade_type&&<span className="text-[10px] text-slate-500 dark:text-slate-600">🔨 {task.trade_type}</span>}
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button onClick={()=>openEditTask(task)} className="p-1.5 rounded-lg hover:bg-slate-200 dark:bg-white/[0.06] text-slate-500 dark:text-slate-600 hover:text-slate-700 dark:text-slate-300 transition"><Edit2 size={12}/></button>
                          <button onClick={()=>deleteTask(task.id)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-slate-500 dark:text-slate-600 hover:text-red-400 transition"><Trash2 size={12}/></button>
                        </div>
                      </div>
                      {task.quantity&&(
                        <div className="flex items-center gap-4 text-xs mb-2 p-2 rounded-lg bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/[0.04]">
                          <span className="text-slate-500">Qty: <span className="text-slate-700 dark:text-slate-300 font-semibold">{task.quantity} {task.unit||""}</span></span>
                          {task.rate_per_unit&&<span className="text-slate-500">Rate: <span className="text-slate-700 dark:text-slate-300 font-semibold">{fmtJMD(task.rate_per_unit)}/{task.unit||"unit"}</span></span>}
                          {totalValue>0&&<span className="text-slate-500 ml-auto">Total: <span className="text-emerald-400 font-bold">{fmtJMD(totalValue)}</span></span>}
                        </div>
                      )}
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 text-[10px] text-slate-500 dark:text-slate-600">
                          {task.start_date&&<span>📅 {new Date(task.start_date).toLocaleDateString("en-US",{month:"short",day:"numeric"})}</span>}
                          {task.end_date&&<span>→ {new Date(task.end_date).toLocaleDateString("en-US",{month:"short",day:"numeric"})}</span>}
                        </div>
                        <select value={task.status} onChange={e=>updateTaskStatus(task.id,e.target.value)}
                          className="text-[10px] bg-slate-50 dark:bg-[#080b10] border border-slate-200 dark:border-white/[0.07] rounded px-2 py-1 text-slate-600 dark:text-slate-400 outline-none">
                          <option value="planned">Planned</option>
                          <option value="active">Active</option>
                          <option value="complete">Complete</option>
                        </select>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* ── FINANCIALS ── */}
        {tab==="financials"&&(
          <>
            {/* Balance Alert Banner */}
            {availableBalance < 0 ? (
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30">
                <span className="text-2xl">🔴</span>
                <div>
                  <div className="text-sm font-bold text-red-700 dark:text-red-400">Overspent — Stop Payments!</div>
                  <div className="text-xs text-red-500">Spent JMD {Math.abs(availableBalance).toLocaleString(undefined,{maximumFractionDigits:0})} more than received. Wait for next client payment.</div>
                </div>
              </div>
            ) : balancePct < 10 ? (
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30">
                <span className="text-2xl">🔴</span>
                <div>
                  <div className="text-sm font-bold text-red-700 dark:text-red-400">Critical — Less than 10% remaining</div>
                  <div className="text-xs text-red-500">Only JMD {availableBalance.toLocaleString(undefined,{maximumFractionDigits:0})} left. Request client payment before spending more.</div>
                </div>
              </div>
            ) : balancePct < 30 ? (
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30">
                <span className="text-2xl">🟡</span>
                <div>
                  <div className="text-sm font-bold text-amber-700 dark:text-amber-400">Warning — Less than 30% remaining</div>
                  <div className="text-xs text-amber-500">JMD {availableBalance.toLocaleString(undefined,{maximumFractionDigits:0})} available. Plan next client payment soon.</div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30">
                <span className="text-2xl">🟢</span>
                <div>
                  <div className="text-sm font-bold text-emerald-700 dark:text-emerald-400">Good — Sufficient funds available</div>
                  <div className="text-xs text-emerald-500">JMD {availableBalance.toLocaleString(undefined,{maximumFractionDigits:0})} available to spend on this project.</div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                {label:"Planned Budget",  value:fmtShort(totalPlannedCost), color:"text-blue-400",    icon:<Target size={14}/>},
                {label:"Actual Cost",     value:fmtShort(totalActualCost),  color:"text-amber-400",   icon:<TrendingDown size={14}/>},
                {label:"Variance",        value:fmtShort(Math.abs(totalPlannedCost-totalActualCost)), color:totalActualCost>totalPlannedCost?"text-red-400":"text-emerald-400", icon:<TrendingUp size={14}/>},
                {label:"PO Commitments",  value:fmtShort(totalPOCommitments), color:"text-violet-400",  icon:<Package size={14}/>},
              ].map(card=>(
                <div key={card.label} className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] p-4">
                  <div className={`${card.color} mb-2`}>{card.icon}</div>
                  <div className={`text-xl font-bold ${card.color}`}>{card.value}</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-600 uppercase tracking-wider font-semibold mt-0.5">{card.label}</div>
                </div>
              ))}
            </div>

            {/* Project Balance — cash received from client vs actually spent */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200">💰 Project Balance</h3>
                <p className="text-xs text-slate-400 mt-0.5">Based on money received from client minus all project spend</p>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-500 dark:text-slate-400">Spent</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(100 - balancePct)}% of received funds</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3">
                    <div className={`h-3 rounded-full transition-all ${
                      balancePct < 10 ? "bg-red-500" :
                      balancePct < 30 ? "bg-amber-500" : "bg-emerald-500"
                    }`} style={{ width: `${Math.min(100, Math.max(0, 100 - balancePct))}%` }}/>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-500/10 border border-blue-100 dark:border-blue-500/20 col-span-2 sm:col-span-1">
                    <div className="text-[10px] text-blue-500 uppercase tracking-wider font-semibold">Available to Spend</div>
                    <div className={`text-xl font-black mt-1 ${availableBalance < 0 ? "text-red-600 dark:text-red-400" : "text-blue-700 dark:text-blue-300"}`}>
                      JMD {availableBalance.toLocaleString(undefined, {maximumFractionDigits:0})}
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20">
                    <div className="text-[10px] text-emerald-500 uppercase tracking-wider font-semibold">Received</div>
                    <div className="text-base font-bold text-emerald-700 dark:text-emerald-300 mt-1">
                      JMD {totalReceived.toLocaleString(undefined, {maximumFractionDigits:0})}
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-100 dark:border-red-500/20">
                    <div className="text-[10px] text-red-500 uppercase tracking-wider font-semibold">Total Spent</div>
                    <div className="text-base font-bold text-red-700 dark:text-red-300 mt-1">
                      JMD {totalSpent.toLocaleString(undefined, {maximumFractionDigits:0})}
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-100 dark:border-slate-800 pt-3 space-y-2">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Spend Breakdown</div>
                  {[
                    { label: "Field Payments (Labor)", amount: totalFieldPayments, icon: "👷" },
                    { label: "Purchase Orders (Materials)", amount: totalPOCommitments, icon: "📦" },
                    { label: "Expenses", amount: totalExpenses, icon: "🧾" },
                  ].map(({ label, amount, icon }) => (
                    <div key={label} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span>{icon}</span>
                        <span className="text-sm text-slate-600 dark:text-slate-300">{label}</span>
                      </div>
                      <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                        JMD {amount.toLocaleString(undefined, {maximumFractionDigits:0})}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Cost per Milestone */}
            {milestones.length>0&&(
              <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-200 dark:border-white/[0.06]">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Cost per Milestone</span>
                </div>
                {milestones.map((ms,i)=>{
                  const pct=ms.planned_total_cost>0?Math.min(100,(ms.actual_total_cost/ms.planned_total_cost)*100):0;
                  return(
                    <div key={ms.id} className={`px-5 py-4 border-b border-slate-100 dark:border-white/[0.04] last:border-0 ${i%2===1?"bg-slate-50 dark:bg-white/[0.01]":""}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">{ms.milestone_name}</span>
                        <div className="flex items-center gap-3 text-xs">
                          <span className="text-slate-500">Planned: <span className="text-blue-400 font-semibold">{fmtJMD(ms.planned_total_cost||0)}</span></span>
                          <span className="text-slate-500">Actual: <span className="text-amber-400 font-semibold">{fmtJMD(ms.actual_total_cost||0)}</span></span>
                        </div>
                      </div>
                      {ms.planned_total_cost>0&&(
                        <div className="w-full bg-slate-200 dark:bg-white/[0.06] rounded-full h-1.5">
                          <div className={`h-1.5 rounded-full ${pct>100?"bg-red-500":pct>70?"bg-amber-500":"bg-cyan-500"}`} style={{width:`${Math.min(pct,100)}%`}}/>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {/* Weekly payroll forecast */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200">📅 Weekly Forecast</h3>
                <p className="text-xs text-slate-400 mt-0.5">Based on last 7 days of field payments</p>
              </div>
              <div className="p-5 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">Last 7 Days Paid</div>
                    <div className="text-base font-bold text-slate-700 dark:text-slate-200 mt-1">
                      JMD {weeklyFieldPayments.toLocaleString(undefined, {maximumFractionDigits:0})}
                    </div>
                  </div>
                  <div className={`p-3 rounded-xl border ${
                    nextWeekForecast < 0
                      ? "bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/30"
                      : "bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/30"
                  }`}>
                    <div className={`text-[10px] uppercase tracking-wider ${nextWeekForecast < 0 ? "text-red-500" : "text-emerald-500"}`}>
                      After This Week
                    </div>
                    <div className={`text-base font-bold mt-1 ${nextWeekForecast < 0 ? "text-red-700 dark:text-red-400" : "text-emerald-700 dark:text-emerald-400"}`}>
                      JMD {nextWeekForecast.toLocaleString(undefined, {maximumFractionDigits:0})}
                    </div>
                  </div>
                </div>
                {nextWeekForecast < 0 && (
                  <div className="text-xs text-red-500 font-semibold">
                    ⚠️ If weekly payroll continues at this rate, funds will run out. Request client payment.
                  </div>
                )}
                {nextWeekForecast >= 0 && weeklyFieldPayments > 0 && nextWeekForecast < weeklyFieldPayments && (
                  <div className="text-xs text-amber-500 font-semibold">
                    ⚠️ Enough for approximately {Math.floor(availableBalance / weeklyFieldPayments)} more week(s) at current spend rate.
                  </div>
                )}
              </div>
            </div>

            {/* Director-only section — profit view */}
            {(userRole === "director" || userRole === "admin") && (
              <div className="rounded-2xl border border-purple-200 dark:border-purple-500/30 overflow-hidden">
                <div className="px-5 py-4 border-b border-purple-200 dark:border-purple-500/30 bg-purple-50 dark:bg-purple-500/10">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-purple-700 dark:text-purple-300">📊 Director View — Profitability</h3>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 font-semibold">Private</span>
                  </div>
                  <p className="text-xs text-purple-400 mt-0.5">Not visible to site managers or other staff</p>
                </div>
                <div className="p-5 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">Contract Value</div>
                      <div className="text-base font-bold text-slate-700 dark:text-slate-200 mt-1">
                        JMD {contractAmount.toLocaleString(undefined, {maximumFractionDigits:0})}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">Still to Collect</div>
                      <div className="text-base font-bold text-amber-600 dark:text-amber-400 mt-1">
                        JMD {stillToCollect.toLocaleString(undefined, {maximumFractionDigits:0})}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30">
                      <div className="text-[10px] text-emerald-500 uppercase tracking-wider">Estimated Profit</div>
                      <div className={`text-base font-bold mt-1 ${estimatedProfit >= 0 ? "text-emerald-700 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`}>
                        JMD {estimatedProfit.toLocaleString(undefined, {maximumFractionDigits:0})}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30">
                      <div className="text-[10px] text-emerald-500 uppercase tracking-wider">Profit Margin</div>
                      <div className={`text-base font-bold mt-1 ${estimatedProfit >= 0 ? "text-emerald-700 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`}>
                        {contractAmount > 0 ? ((estimatedProfit / contractAmount) * 100).toFixed(1) : "0"}%
                      </div>
                    </div>
                  </div>
                  <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                    * Estimated profit = Contract value − total spend. Final profit calculated at project completion.
                  </div>
                </div>
              </div>
            )}

            <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] overflow-hidden">
              <div className="px-5 py-3 border-b border-slate-200 dark:border-white/[0.06]"><span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-600">Quick Links</span></div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3">
                {[
                  {label:"Field Payments", to:`/field-payments?project=${projectId}`, icon:<Users size={13}/>,        color:"text-emerald-400"},
                  {label:"Procurement",    to:`/projects/${projectId}/procurement`,   icon:<ShoppingCart size={13}/>, color:"text-blue-400"},
                  {label:"Expenses",       to:`/expenses?project=${projectId}`,       icon:<Receipt size={13}/>,      color:"text-amber-400"},
                  {label:"Invoices",       to:`/accounts-receivable?project=${projectId}`, icon:<FileText size={13}/>, color:"text-violet-400"},
                ].map(l=>(
                  <button key={l.to} onClick={()=>nav(l.to)}
                    className="flex items-center gap-2.5 px-4 py-3 rounded-lg border border-slate-200 dark:border-white/[0.06] hover:border-white/[0.12] hover:bg-white/[0.03] transition text-left">
                    <span className={l.color}>{l.icon}</span>
                    <span className="text-xs text-slate-600 dark:text-slate-400">{l.label}</span>
                    <ArrowRight size={11} className="ml-auto text-slate-400 dark:text-slate-700"/>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* ── COST PLAN ── */}
        {tab==="costplan"&&(
          <div className="space-y-6">

            {/* Price recommendation banner */}
            <div className={`p-4 rounded-2xl border-2 ${
              currentMargin >= cpTargetProfit
                ? "border-emerald-400 dark:border-emerald-500 bg-emerald-50 dark:bg-emerald-500/10"
                : currentMargin > 0
                ? "border-amber-400 dark:border-amber-500 bg-amber-50 dark:bg-amber-500/10"
                : "border-red-400 dark:border-red-500 bg-red-50 dark:bg-red-500/10"
            }`}>
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <div className={`text-sm font-bold ${currentMargin >= cpTargetProfit ? "text-emerald-700 dark:text-emerald-300" : currentMargin > 0 ? "text-amber-700 dark:text-amber-300" : "text-red-700 dark:text-red-300"}`}>
                    {currentMargin >= cpTargetProfit ? "✅ On Track — Meeting profit target" :
                     currentMargin > 0 ? "⚠️ Below Target — Consider raising price" :
                     "🔴 Losing Money — Price too low"}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Current margin: {currentMargin.toFixed(1)}% | Target: {cpTargetProfit}%
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-400">Recommended price</div>
                  <div className="text-xl font-black text-slate-800 dark:text-slate-100">
                    JMD {recommendedPrice.toLocaleString(undefined, {maximumFractionDigits:0})}
                  </div>
                </div>
              </div>
            </div>

            {/* Project duration + profit target */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.07] overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.07] bg-slate-50 dark:bg-white/[0.03]">
                <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200">⚙️ Project Setup</h3>
              </div>
              <div className="p-5 grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Project Duration</label>
                  <div className="flex items-center gap-2">
                    <input type="number" min="1" max="60"
                      value={cpDuration}
                      onChange={e => setCpDuration(Number(e.target.value))}
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-sm text-slate-400">months</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Target Profit %</label>
                  <div className="flex items-center gap-2">
                    <input type="number" min="0" max="100"
                      value={cpTargetProfit}
                      onChange={e => setCpTargetProfit(Number(e.target.value))}
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-sm text-slate-400">%</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Company Overhead %</label>
                  <div className="flex items-center gap-2">
                    <input type="number" min="0" max="50"
                      value={cpOverheadPct}
                      onChange={e => setCpOverheadPct(Number(e.target.value))}
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-sm text-slate-400">%</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Contingency %</label>
                  <div className="flex items-center gap-2">
                    <input type="number" min="0" max="50"
                      value={cpContingencyPct}
                      onChange={e => setCpContingencyPct(Number(e.target.value))}
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-sm text-slate-400">%</span>
                  </div>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Vehicles on Job</label>
                  <div className="flex items-center gap-2">
                    <input type="number" min="0" max="20"
                      value={cpVehicles}
                      onChange={e => setCpVehicles(Number(e.target.value))}
                      className="w-20 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-sm text-slate-400">× JMD</span>
                    <input type="number" min="0"
                      value={cpVehicleCost}
                      onChange={e => setCpVehicleCost(Number(e.target.value))}
                      className="w-24 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-xs text-slate-400">/mo</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Staff allocation */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.07] overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.07] bg-slate-50 dark:bg-white/[0.03]">
                <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200">👥 Staff Overhead</h3>
                <p className="text-xs text-slate-400 mt-0.5">Project managers, supervisors, estimators running this job</p>
              </div>
              <div className="p-5 space-y-4">
                <div className="flex gap-2 flex-wrap">
                  <select value={addStaffId}
                    onChange={e => setAddStaffId(e.target.value)}
                    className="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm text-slate-700 dark:text-slate-200 focus:outline-none">
                    <option value="">Select staff member...</option>
                    {availableWorkers
                      .filter(w => !cpStaff.find(s => s.workerId === w.id))
                      .map(w => (
                        <option key={w.id} value={w.id}>
                          {w.first_name} {w.last_name} — {w.job_title || w.pay_type} (JMD {Number(w.pay_rate||0).toLocaleString()}/mo)
                        </option>
                      ))}
                  </select>
                  <div className="flex items-center gap-1">
                    <input type="number" min="10" max="100"
                      value={addStaffPct}
                      onChange={e => setAddStaffPct(Number(e.target.value))}
                      className="w-16 px-2 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm text-center font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                    <span className="text-xs text-slate-400">%</span>
                  </div>
                  <button
                    onClick={() => {
                      const w = availableWorkers.find(x => x.id === addStaffId);
                      if (!w) return;
                      setCpStaff(prev => [...prev, {
                        workerId: w.id,
                        name: `${w.first_name} ${w.last_name}`,
                        role: w.job_title || w.pay_type || "Staff",
                        monthlyRate: Number(w.pay_rate || 0),
                        allocationPct: addStaffPct,
                      }]);
                      setAddStaffId("");
                    }}
                    disabled={!addStaffId}
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold transition-colors">
                    + Add
                  </button>
                </div>

                {cpStaff.length === 0 ? (
                  <div className="text-center py-4 text-sm text-slate-400">
                    No staff allocated yet. Add project managers, supervisors etc.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {cpStaff.map((s, i) => {
                      const totalCost = s.monthlyRate * cpDuration * s.allocationPct / 100;
                      return (
                        <div key={s.workerId} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/[0.07]">
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-semibold text-slate-700 dark:text-slate-200">{s.name}</div>
                            <div className="text-xs text-slate-400">
                              {s.role} · JMD {s.monthlyRate.toLocaleString()}/mo × {cpDuration}mo × {s.allocationPct}% allocated
                            </div>
                          </div>
                          <div className="flex items-center gap-3 flex-shrink-0">
                            <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                              JMD {totalCost.toLocaleString(undefined, {maximumFractionDigits:0})}
                            </div>
                            <button onClick={() => setCpStaff(prev => prev.filter((_, idx) => idx !== i))}
                              className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-500/10 text-slate-400 hover:text-red-500 transition-colors">
                              <X size={13}/>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Full cost breakdown */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.07] overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.07] bg-slate-50 dark:bg-white/[0.03]">
                <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200">📊 Full Cost Breakdown</h3>
                <p className="text-xs text-slate-400 mt-0.5">What this project actually costs to deliver</p>
              </div>
              <div className="p-5 space-y-2">
                {[
                  { label: "Direct Costs (BOQ)", amount: directCosts, color: "text-slate-700 dark:text-slate-200", indent: false },
                  { label: "Staff Overhead", amount: staffCost, color: "text-purple-600 dark:text-purple-400", indent: true },
                  { label: `Vehicle/Transport (${cpVehicles} × JMD ${cpVehicleCost.toLocaleString()}/mo × ${cpDuration}mo)`, amount: vehicleCost, color: "text-purple-600 dark:text-purple-400", indent: true },
                  { label: `Company Overhead (${cpOverheadPct}% of direct)`, amount: overheadCost, color: "text-purple-600 dark:text-purple-400", indent: true },
                  { label: "Total Overhead", amount: totalOverhead, color: "text-purple-700 dark:text-purple-300 font-bold", indent: false },
                  { label: "TOTAL PROJECT COST", amount: totalProjectCost, color: "text-slate-800 dark:text-slate-100 font-bold", indent: false },
                  { label: `Contingency (${cpContingencyPct}%)`, amount: contingencyAmt, color: "text-amber-600 dark:text-amber-400", indent: true },
                  { label: `Target Profit (${cpTargetProfit}%)`, amount: markupAmt, color: "text-emerald-600 dark:text-emerald-400", indent: true },
                ].map(({ label, amount, color, indent }) => (
                  <div key={label} className={`flex items-center justify-between py-1.5 ${indent ? "pl-4 border-l-2 border-slate-100 dark:border-white/[0.06]" : "border-t border-slate-100 dark:border-white/[0.06] pt-2 mt-1"}`}>
                    <span className={`text-sm ${color}`}>{label}</span>
                    <span className={`text-sm ${color}`}>JMD {amount.toLocaleString(undefined, {maximumFractionDigits:0})}</span>
                  </div>
                ))}

                <div className="mt-4 space-y-2 border-t border-slate-200 dark:border-white/[0.07] pt-4">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100 dark:bg-white/[0.06]">
                    <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">Break-even Price</span>
                    <span className="text-sm font-bold text-slate-700 dark:text-slate-200">JMD {breakEvenPrice.toLocaleString(undefined, {maximumFractionDigits:0})}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-600">
                    <span className="text-sm font-bold text-white">Recommended Price ({cpTargetProfit}% profit)</span>
                    <span className="text-lg font-black text-white">JMD {recommendedPrice.toLocaleString(undefined, {maximumFractionDigits:0})}</span>
                  </div>
                  {contractAmount > 0 && (
                    <div className={`flex items-center justify-between p-3 rounded-xl ${
                      currentEstimateProfit >= 0 ? "bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/30" : "bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30"
                    }`}>
                      <span className={`text-sm font-semibold ${currentEstimateProfit >= 0 ? "text-blue-700 dark:text-blue-300" : "text-red-700 dark:text-red-300"}`}>
                        {currentEstimateProfit >= 0 ? "Profit at current contract price" : "Loss at current contract price"}
                      </span>
                      <span className={`text-sm font-bold ${currentEstimateProfit >= 0 ? "text-blue-700 dark:text-blue-300" : "text-red-700 dark:text-red-300"}`}>
                        JMD {currentEstimateProfit.toLocaleString(undefined, {maximumFractionDigits:0})} ({currentMargin.toFixed(1)}%)
                      </span>
                    </div>
                  )}
                </div>

                <button
                  onClick={async () => {
                    setCpSaving(true);
                    try {
                      await supabase.from("projects").update({
                        duration_months: cpDuration,
                        target_profit_pct: cpTargetProfit,
                        overhead_budget: totalOverhead,
                      }).eq("id", projectId);

                      const payload = {
                        budget_amount: totalOverhead,
                        description: JSON.stringify({
                          staff: cpStaff,
                          vehicles: cpVehicles,
                          vehicle_cost: cpVehicleCost,
                        }),
                        budget_period: "total",
                        is_active: true,
                      };
                      const { data: existing } = await supabase.from("project_budgets")
                        .select("id").eq("project_id", projectId).eq("category", "overhead")
                        .eq("is_active", true).limit(1).maybeSingle();
                      if (existing) {
                        await supabase.from("project_budgets").update(payload).eq("id", existing.id);
                      } else {
                        await supabase.from("project_budgets").insert({
                          project_id: projectId, company_id: companyId, category: "overhead", ...payload,
                        });
                      }
                      alert("Cost plan saved!");
                    } catch (e: any) {
                      alert("Failed to save cost plan: " + e.message);
                    } finally {
                      setCpSaving(false);
                    }
                  }}
                  disabled={cpSaving}
                  className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold transition-colors mt-2">
                  {cpSaving ? "Saving..." : "💾 Save Cost Plan"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── TEAM ── */}
        {tab==="team"&&(
          <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-white/[0.06]">
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200">Active Workers</span>
              <button onClick={()=>nav("/workers")} className="flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-700 dark:text-slate-300 transition">Manage <ArrowRight size={11}/></button>
            </div>
            {workers.length===0?(
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Users size={20} className="text-slate-400 dark:text-slate-700"/>
                <p className="text-xs text-slate-500 dark:text-slate-600">No active workers found</p>
                <button onClick={()=>nav("/workers")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition">
                  <Users size={11}/> Go to Workers
                </button>
              </div>
            ):workers.map((w:any)=>(
              <div key={w.id} className="flex items-center gap-3 px-5 py-3 border-b border-slate-100 dark:border-white/[0.04] last:border-0 hover:bg-slate-50 dark:bg-white/[0.02] transition">
                <div className="w-8 h-8 rounded-full bg-violet-500/10 border border-violet-500/20 flex items-center justify-center flex-shrink-0">
                  <Users size={12} className="text-violet-400"/>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{w.first_name} {w.last_name}</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-600">{w.worker_type||"General"}</div>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">{w.status}</span>
              </div>
            ))}
          </div>
        )}

        {/* ── ACTIVITY ── */}
        {tab==="activity"&&(
          <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0d1117] overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 dark:border-white/[0.06]">
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200">Recent Activity</span>
            </div>
            {activity.length===0?(
              <div className="flex flex-col items-center justify-center py-12 gap-2">
                <Clock size={20} className="text-slate-400 dark:text-slate-700"/>
                <p className="text-xs text-slate-500 dark:text-slate-600">No activity yet</p>
              </div>
            ):activity.map((a:any)=>{
              const typeMap:Record<string,{color:string;bg:string;icon:React.ReactNode}>={
                expense:{color:"text-amber-400",bg:"bg-amber-500/10",icon:<Receipt size={11}/>},
                po:{color:"text-blue-400",bg:"bg-blue-500/10",icon:<Package size={11}/>},
              };
              const t=typeMap[a.type]||typeMap.po;
              return(
                <div key={a.id} className="flex items-center gap-3 px-5 py-3 border-b border-slate-100 dark:border-white/[0.04] last:border-0">
                  <div className={`w-7 h-7 rounded-lg ${t.bg} flex items-center justify-center flex-shrink-0`}>
                    <span className={t.color}>{t.icon}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate">{a.label}</div>
                    <div className="text-[10px] text-slate-400 dark:text-slate-700 capitalize">{a.type} · {fmtTime(a.time)}</div>
                  </div>
                  {a.amount!==undefined&&<div className="text-xs font-bold text-slate-700 dark:text-slate-300 flex-shrink-0">{fmtShort(Number(a.amount||0))}</div>}
                  {a.status&&(
                    <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold border ${a.status==="approved"?"bg-emerald-500/10 text-emerald-400 border-emerald-500/20":a.status==="pending"?"bg-amber-500/10 text-amber-400 border-amber-500/20":"bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20"}`}>
                      {a.status}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {tab==="messages"&&(
          <div className="space-y-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4 max-h-96 overflow-y-auto space-y-3">
              {messages.length===0&&(
                <div className="text-sm text-slate-400 text-center py-8">No messages yet.</div>
              )}
              {messages.map((m:any)=>(
                <div key={m.id} className={`flex ${m.sender_type==="staff"?"justify-end":"justify-start"}`}>
                  <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${
                    m.sender_type==="staff"?"bg-cyan-600 text-white":"bg-slate-100 text-slate-800"
                  }`}>
                    <div>{m.message}</div>
                    <div className={`text-[10px] mt-1 ${m.sender_type==="staff"?"text-cyan-100":"text-slate-400"}`}>
                      {m.sender_type==="staff"?"You":"Client"} · {new Date(m.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <textarea value={newReply} onChange={(e)=>setNewReply(e.target.value)}
                placeholder="Reply to client..." rows={2}
                className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-cyan-400"/>
              <button onClick={sendReply} disabled={!newReply.trim()||sendingReply}
                className="px-4 py-2 rounded-lg bg-cyan-600 text-white text-sm font-semibold disabled:opacity-50 self-end">
                {sendingReply?"Sending...":"Send"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}