import React, { useState, useEffect, useLayoutEffect, useRef, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ChevronLeft, Upload, Search, Plus, X, ZoomIn, ZoomOut,
  ChevronRight, ChevronLeft as ChevronLeftIcon, Bookmark,
  Pencil, Download, Move, Ruler, Type, Trash2, Check,
  ArrowRight, RotateCcw, Maximize2, Layers,
} from "lucide-react";
import { supabase } from "../lib/supabase";
import { signPrivatePath, signPrivatePaths } from "../lib/privateFiles";

// ─── Types ────────────────────────────────────────────────────────────────────
interface Plan {
  id: string;
  project_id: string;
  file_name: string;
  file_url: string;
  file_type: string;
  file_size: number | null;
  category: string;
  page_count: number;
  calibration_data: CalibrationData | null;
  created_at: string;
  publicUrl: string;
}

interface CalibrationData {
  pixelsPerUnit: number;
  unit: string;
  knownLength: number;
  // Zoom `scale` at the moment of calibration. Canvas pixel density scales
  // with zoom, so a measurement taken at a different zoom must be
  // compensated by (calibratedAtScale / currentScale) before dividing by
  // pixelsPerUnit, or it will be off by the zoom ratio.
  calibratedAtScale?: number;
}

interface Annotation {
  id: string;
  type: "pen" | "arrow" | "text";
  color: string;
  lineWidth: number;
  points: { x: number; y: number }[];
  text?: string;
}

interface Measurement {
  id: string;
  from: { x: number; y: number };
  to: { x: number; y: number };
  label: string;
  pixelLength: number;
  realLength: number | null;
  unit: string | null;
}

interface BookmarkItem {
  id: string;
  page: number;
  label: string;
  note: string;
}

const CATEGORIES = [
  "General", "Architectural", "Structural", "Electrical",
  "Plumbing", "Mechanical", "Civil", "Landscape", "Shop Drawings",
];

// PDF pages are rasterized once per page load at this fixed resolution;
// all visual zoom beyond/below it is pure CSS transform:scale(), never a
// re-render. Higher = crisper at high zoom but slower initial page load.
const RENDER_SCALE = 2.0;

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtSize(bytes: number | null) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

// Parses construction-style lengths: "10", "10.25", "1/4", "10 1/4", "10-1/4",
// and feet+inches like 1'6", 1' 6", 1'6.5", 1'6 1/2", 5'
function parseFraction(input: string): number | null {
  const s = input.trim();
  if (!s) return null;

  const feetInches = s.match(/^(\d+(?:\.\d+)?)'(?:\s*(\d+(?:\.\d+)?)(?:\s+(\d+)\/(\d+))?"?)?$/);
  if (feetInches) {
    const feet = Number(feetInches[1]);
    let inches = feetInches[2] ? Number(feetInches[2]) : 0;
    if (feetInches[3] && feetInches[4]) inches += Number(feetInches[3]) / Number(feetInches[4]);
    return feet + inches / 12;
  }

  const mixed = s.match(/^(\d+(?:\.\d+)?)[\s-]+(\d+)\/(\d+)$/);
  if (mixed) return Number(mixed[1]) + Number(mixed[2]) / Number(mixed[3]);
  const frac = s.match(/^(\d+)\/(\d+)$/);
  if (frac) return Number(frac[1]) / Number(frac[2]);
  const dec = Number(s.replace(/["']/g, ""));
  return Number.isFinite(dec) ? dec : null;
}

// Formats a decimal inch value as a mixed number rounded to the nearest 1/16"
function formatInches(value: number): string {
  const whole = Math.floor(value);
  let num = Math.round((value - whole) * 16);
  let den = 16;
  if (num === 16) return `${whole + 1}"`;
  if (num === 0) return `${whole}"`;
  while (num % 2 === 0) { num /= 2; den /= 2; }
  return whole > 0 ? `${whole} ${num}/${den}"` : `${num}/${den}"`;
}

// Shortest distance from point p to the segment a-b (for hit-testing a click near a line)
function distToSegment(p: { x: number; y: number }, a: { x: number; y: number }, b: { x: number; y: number }): number {
  const dx = b.x - a.x, dy = b.y - a.y;
  const lenSq = dx * dx + dy * dy;
  let t = lenSq === 0 ? 0 : ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}

// ─── PDF Renderer ─────────────────────────────────────────────────────────────
async function renderPdfPage(
  url: string,
  pageNum: number,
  canvas: HTMLCanvasElement,
  scale: number
): Promise<number> {
  const pdfjsLib = await import("pdfjs-dist");
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    "pdfjs-dist/build/pdf.worker.mjs",
    import.meta.url
  ).toString();
  const pdf = await pdfjsLib.getDocument({ url, withCredentials: false }).promise;
  const page = await pdf.getPage(pageNum);
  const viewport = page.getViewport({ scale });
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  await page.render({ canvasContext: canvas.getContext("2d")!, viewport, canvas }).promise;
  return pdf.numPages;
}

async function getPdfPageCount(url: string): Promise<number> {
  const pdfjsLib = await import("pdfjs-dist");
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    "pdfjs-dist/build/pdf.worker.mjs",
    import.meta.url
  ).toString();
  const pdf = await pdfjsLib.getDocument({ url, withCredentials: false }).promise;
  return pdf.numPages;
}

// ─── PlanViewer ───────────────────────────────────────────────────────────────
function PlanViewer({
  plan,
  onClose,
  onCalibrationSave,
}: {
  plan: Plan;
  onClose: () => void;
  onCalibrationSave: (data: CalibrationData | null) => void;
}) {
  const isPdf = plan.file_type === "application/pdf" || plan.file_url.toLowerCase().endsWith(".pdf");

  // Render state
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const annotCanvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [pageNum, setPageNum] = useState(1);
  const [totalPages, setTotalPages] = useState(isPdf ? (plan.page_count ?? 1) : 1);
  const [scale, setScale] = useState(1.2);
  const [rendering, setRendering] = useState(false);

  // Pan state
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const panStart = useRef<{ mx: number; my: number; px: number; py: number } | null>(null);
  const isPanning = useRef(false);

  // Touch pinch-zoom state
  const pinchStartDist = useRef(0);
  const pinchStartScale = useRef(1);
  // `scale` is the VISUAL zoom level (0.25-5), decoupled from PDF render
  // resolution. The PDF is rendered once per page at a fixed high
  // resolution (RENDER_SCALE) and all zoom in between is pure CSS
  // transform:scale() on canvasWrapperRef — never a re-render — so a
  // gesture never needs to bridge a "live preview" to a freshly
  // rendered canvas, which is what caused the earlier snap/jump bugs.
  const liveScaleRef = useRef(1);
  const canvasWrapperRef = useRef<HTMLDivElement>(null);
  const wheelZoomEndTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Where the CSS scale visually anchors from (pinch midpoint or cursor
  // position), in the wrapper's own untransformed local space. Persists
  // across the gesture AND into the "at rest" state (see the layout
  // effect below), since with a permanent CSS transform there's no
  // discontinuity point where the origin choice stops mattering.
  const zoomOriginRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  // Mirrors `pan` state for imperative mid-gesture writes. Needed because
  // retargeting the zoom origin (see retargetZoomOrigin below) has to nudge
  // pan to keep the pivot from jumping — but doing that via setPan mid-
  // gesture would race with the "at rest" layout effect, which writes the
  // committed `scale` and would revert the live in-progress zoom. Synced
  // from `pan` state in the layout effect below, so any pan committed from
  // elsewhere (the drag/pan tool, reset-view) stays reflected here too.
  const livePanRef = useRef(pan);
  // The PDF render effect has no cancellation for its async work: if a
  // second page/file change fires before the first render's promise
  // resolves, both .then() callbacks eventually fire and can land out
  // of order. Each render effect run claims the next generation and
  // only applies its side effects if it's still the latest by the time
  // it resolves.
  const renderGeneration = useRef(0);

  // Converts a desired VISUAL zoom level into the CSS scale() factor
  // needed on top of however the content is actually rendered: PDFs are
  // rasterized once at RENDER_SCALE, so the remaining zoom is
  // visualScale/RENDER_SCALE; images are always at their natural
  // (1x) size, so the remaining zoom is just visualScale itself.
  function cssScaleFor(visualScale: number): number {
    return isPdf ? visualScale / RENDER_SCALE : visualScale;
  }

  function applyLiveScale(newScale: number) {
    liveScaleRef.current = newScale;
    const el = canvasWrapperRef.current;
    if (el) {
      const { x, y } = zoomOriginRef.current;
      const { x: px, y: py } = livePanRef.current;
      el.style.transformOrigin = `${x}px ${y}px`;
      el.style.transform = `translate(${px}px, ${py}px) scale(${cssScaleFor(newScale)})`;
    }
  }

  function commitLiveScale() {
    setScale(liveScaleRef.current);
    setPan(livePanRef.current);
  }

  // transform-origin defines the pivot a scale() change expands/contracts
  // around. Retargeting it mid-gesture (a new pinch midpoint, or the cursor
  // moving between wheel ticks) moves that pivot — and unless pan is nudged
  // to compensate, the content visibly jumps by
  // (1 - currentCssScale) * (oldOrigin - newOrigin) the instant the new
  // origin takes effect, even before scale itself changes. Mutates
  // livePanRef directly (not setPan) so this stays synchronous with the
  // imperative applyLiveScale writes instead of racing a React re-render.
  function retargetZoomOrigin(newOrigin: { x: number; y: number }, currentCssScale: number) {
    const oldOrigin = zoomOriginRef.current;
    zoomOriginRef.current = newOrigin;
    const dx = (1 - currentCssScale) * (oldOrigin.x - newOrigin.x);
    const dy = (1 - currentCssScale) * (oldOrigin.y - newOrigin.y);
    if (dx !== 0 || dy !== 0) {
      livePanRef.current = { x: livePanRef.current.x + dx, y: livePanRef.current.y + dy };
    }
  }

  // canvasWrapperRef's transform is driven exclusively here (imperatively)
  // rather than via a declarative JSX style, so a live pinch/wheel-zoom
  // transform (also written imperatively, see applyLiveScale) is never
  // fought over by React re-applying a stale transform mid-gesture. This
  // single effect is also what makes the "at rest" state (after a
  // gesture commits, on keyboard-shortcut zoom, and on initial mount)
  // correct — no separate commit-time DOM write is needed.
  useLayoutEffect(() => {
    const el = canvasWrapperRef.current;
    if (!el) return;
    livePanRef.current = pan;
    const { x, y } = zoomOriginRef.current;
    el.style.transformOrigin = `${x}px ${y}px`;
    el.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${cssScaleFor(scale)})`;
  }, [pan, scale, isPdf]);

  // Tool state
  const [activeTool, setActiveTool] = useState<"pan" | "pen" | "arrow" | "text" | "measure" | "calibrate">("pan");
  const [penColor, setPenColor] = useState("#ef4444");
  const [penWidth, setPenWidth] = useState(2);

  // Annotations
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const drawingAnnot = useRef<Annotation | null>(null);
  const isAnnotDrawing = useRef(false);

  // Text input overlay
  const [textPos, setTextPos] = useState<{ x: number; y: number } | null>(null);
  const [textVal, setTextVal] = useState("");

  // Measurements
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  // State (not a ref) so the first-point indicator redraws reliably via
  // the shared redraw effect, the same way calibPoints already does.
  const [measStart, setMeasStart] = useState<{ x: number; y: number } | null>(null);
  const [pendingMeas, setPendingMeas] = useState<Omit<Measurement, "id"> | null>(null);
  const [draggingMeasId, setDraggingMeasId] = useState<string | null>(null);
  const dragOffset = useRef<{ x: number; y: number } | null>(null);

  // Edge-detection snap (calibrate/measure tools only)
  const snapPoints = useRef<{ x: number; y: number }[]>([]);
  const [snapIndicator, setSnapIndicator] = useState<{ x: number; y: number } | null>(null);
  const SNAP_RADIUS = 15;

  // Calibration — two-click approach
  const [calibration, setCalibration] = useState<CalibrationData | null>(plan.calibration_data ?? null);
  const [calibStep, setCalibStep] = useState<"idle" | "drawing" | "input">("idle");
  const [calibPoints, setCalibPoints] = useState<{ x: number; y: number }[]>([]);
  const [pendingCalib, setPendingCalib] = useState<{ from: { x: number; y: number }; to: { x: number; y: number }; px: number } | null>(null);
  const [calibLength, setCalibLength] = useState("");
  const [calibUnit, setCalibUnit] = useState("ft");
  const [calibFeet, setCalibFeet] = useState("");
  const [calibInches, setCalibInches] = useState("");
  const [calibFraction, setCalibFraction] = useState("0");
  const [toast, setToast] = useState<string | null>(null);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }

  // Bookmarks
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [bookmarkLabel, setBookmarkLabel] = useState("");
  const [addingBookmark, setAddingBookmark] = useState(false);

  // Thumbnails
  const [showThumbs, setShowThumbs] = useState(false);
  const thumbRefs = useRef<Map<number, HTMLCanvasElement>>(new Map());

  // ── Load page ────────────────────────────────────────────────────────────
  // Fires only on page/file change now — zoom (`scale`) is deliberately
  // NOT a dependency, since it's handled entirely via CSS transform (see
  // canvasWrapperRef's layout effect above) and never needs a re-render.
  useEffect(() => {
    if (!isPdf) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const myGeneration = ++renderGeneration.current;
    // The scrollable container's native scroll position is unrelated to
    // React state, so re-rendering the canvas (which briefly changes its
    // size mid-render) can otherwise cause the browser to reset scroll
    // to 0,0. Restore it once the new canvas is in place.
    const container = containerRef.current;
    const scrollLeft = container?.scrollLeft ?? 0;
    const scrollTop = container?.scrollTop ?? 0;
    setRendering(true);
    renderPdfPage(plan.publicUrl, pageNum, canvas, RENDER_SCALE)
      .then(total => {
        setTotalPages(total); setRendering(false);
        // A newer render (triggered by another page/file change that
        // fired before this one resolved) already applied its own
        // results — don't let this stale one clobber them.
        if (myGeneration !== renderGeneration.current) return;
        syncAnnotCanvas(); detectEdges();
        if (container) {
          container.scrollLeft = scrollLeft;
          container.scrollTop = scrollTop;
        }
      })
      .catch(() => setRendering(false));
  }, [pageNum, plan.publicUrl, isPdf]);

  // Sync annotation canvas size to the underlying PDF canvas or image
  function syncAnnotCanvas() {
    const ann = annotCanvasRef.current;
    if (!ann) return;
    if (isPdf) {
      const base = canvasRef.current;
      if (!base) return;
      ann.width = base.width;
      ann.height = base.height;
    } else {
      const img = imgRef.current;
      if (!img) return;
      ann.width = img.naturalWidth;
      ann.height = img.naturalHeight;
    }
    redrawAnnotations(annotations);
  }

  // Scans the rendered plan for dark-line corners/intersections so the
  // calibrate/measure tools can snap to them. Runs on a background-drawn
  // offscreen canvas for images (there's no visible <canvas> for those),
  // and directly on the PDF canvas for PDFs. Best-effort: silently disables
  // snapping for this render if pixel access is blocked (e.g. a
  // cross-origin image without permissive CORS headers).
  function detectEdges() {
    let source: HTMLCanvasElement | null = null;
    if (isPdf) {
      source = canvasRef.current;
    } else if (imgRef.current) {
      const img = imgRef.current;
      const temp = document.createElement("canvas");
      temp.width = img.naturalWidth;
      temp.height = img.naturalHeight;
      const tctx = temp.getContext("2d");
      if (!tctx) return;
      try {
        tctx.drawImage(img, 0, 0);
      } catch {
        snapPoints.current = [];
        return;
      }
      source = temp;
    }
    if (!source) return;

    const ctx = source.getContext("2d");
    if (!ctx) return;
    let data: Uint8ClampedArray, w: number, h: number;
    try {
      const imageData = ctx.getImageData(0, 0, source.width, source.height);
      data = imageData.data; w = imageData.width; h = imageData.height;
    } catch {
      // Tainted canvas (cross-origin without CORS) — snapping unavailable.
      snapPoints.current = [];
      return;
    }

    const points: { x: number; y: number }[] = [];
    const THRESHOLD = 80; // darkness threshold
    const GRID = 8; // sample every 8px for performance
    const dirs = [[0, -GRID], [GRID, 0], [0, GRID], [-GRID, 0]]; // up, right, down, left

    for (let y = GRID; y < h - GRID; y += GRID) {
      for (let x = GRID; x < w - GRID; x += GRID) {
        const idx = (y * w + x) * 4;
        const brightness = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
        if (brightness > THRESHOLD) continue;

        const darkDirs: number[] = [];
        dirs.forEach(([dx, dy], i) => {
          const ni = ((y + dy) * w + (x + dx)) * 4;
          if (ni >= 0 && ni < data.length) {
            const nb = (data[ni] + data[ni + 1] + data[ni + 2]) / 3;
            if (nb < THRESHOLD) darkDirs.push(i);
          }
        });

        // A point with exactly 2 dark neighbors that are directly opposite
        // (up+down, or left+right) just sits on a straight line, not a
        // corner — skip those to avoid flagging every pixel of every wall.
        const isStraightLine = darkDirs.length === 2 &&
          ((darkDirs.includes(0) && darkDirs.includes(2)) || (darkDirs.includes(1) && darkDirs.includes(3)));
        if (darkDirs.length >= 2 && darkDirs.length <= 3 && !isStraightLine) {
          const tooClose = points.some(p => Math.abs(p.x - x) < GRID * 2 && Math.abs(p.y - y) < GRID * 2);
          if (!tooClose) points.push({ x, y });
        }
      }
    }
    snapPoints.current = points;
  }

  // Snaps a click/hover position to the nearest detected edge point within
  // SNAP_RADIUS, and updates the visual snap indicator. Returns the
  // original position unchanged if nothing is close enough.
  function snapToPoint(pos: { x: number; y: number }): { x: number; y: number } {
    let closest: { x: number; y: number } | null = null;
    let closestDist = SNAP_RADIUS;
    for (const pt of snapPoints.current) {
      const d = Math.hypot(pos.x - pt.x, pos.y - pt.y);
      if (d < closestDist) { closestDist = d; closest = pt; }
    }
    setSnapIndicator(closest);
    return closest ?? pos;
  }

  // ── Thumbnails ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (!showThumbs || !isPdf) return;
    for (let p = 1; p <= totalPages; p++) {
      const c = thumbRefs.current.get(p);
      if (c && c.dataset.loaded !== "1") {
        renderPdfPage(plan.publicUrl, p, c, 0.2).then(() => { c.dataset.loaded = "1"; });
      }
    }
  }, [showThumbs, totalPages]);

  // ── Annotation draw ───────────────────────────────────────────────────────
  function redrawAnnotations(anns: Annotation[]) {
    const ann = annotCanvasRef.current;
    if (!ann) return;
    const ctx = ann.getContext("2d")!;
    ctx.clearRect(0, 0, ann.width, ann.height);
    anns.forEach(a => drawAnnot(ctx, a));
    measurements.forEach(m => drawMeasLine(ctx, m.from, m.to, m.label, "#f97316"));
    drawCalibOverlay(ctx);
    // First-point indicator for an in-progress measurement (mirrors the
    // calibrate tool's own first-point dot below).
    if (activeTool === "measure" && measStart) drawFirstPointRing(ctx, measStart, "#f97316");
  }

  // Locked calibration dot(s)/line — kept in sync with calibPoints so it
  // survives any redraw instead of being a one-off imperative paint.
  function drawCalibOverlay(ctx: CanvasRenderingContext2D) {
    if (calibPoints.length === 0) return;
    if (calibPoints.length === 1) {
      drawFirstPointRing(ctx, calibPoints[0], "#f59e0b");
      return;
    }
    drawCalibDot(ctx, calibPoints[0]);
    drawCalibDot(ctx, calibPoints[1]);
    // Once a calibration has been committed (calibStep back to "idle"),
    // label the locked line with its real-world length instead of raw px.
    const committedLabel = calibStep === "idle" && calibration
      ? `CAL: ${calibration.knownLength.toFixed(3)} ${calibration.unit}`
      : undefined;
    drawCalibLine(ctx, calibPoints[0], calibPoints[1], committedLabel);
  }

  function drawCalibDot(ctx: CanvasRenderingContext2D, pt: { x: number; y: number }) {
    ctx.save();
    ctx.fillStyle = "#f59e0b";
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }

  // A more prominent dot+ring shown at the first point of an in-progress
  // calibration or measurement, so it's clearly visible before the second
  // point is tapped (important on touch where there's no hover feedback).
  function drawFirstPointRing(ctx: CanvasRenderingContext2D, pt: { x: number; y: number }, color: string) {
    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 14, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawCalibLine(ctx: CanvasRenderingContext2D, from: { x: number; y: number }, to: { x: number; y: number }, labelOverride?: string) {
    ctx.save();
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 3]);
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
    ctx.setLineDash([]);
    const px = Math.hypot(to.x - from.x, to.y - from.y);
    const label = labelOverride ?? `${px.toFixed(0)} px`;
    const mx = (from.x + to.x) / 2;
    const my = (from.y + to.y) / 2 - 10;
    ctx.font = "bold 13px sans-serif";
    ctx.textAlign = "center";
    if (labelOverride) {
      const tw = ctx.measureText(label).width;
      ctx.fillStyle = "rgba(0,0,0,0.7)";
      ctx.fillRect(mx - tw / 2 - 4, my - 13, tw + 8, 18);
    }
    ctx.fillStyle = "#f59e0b";
    ctx.fillText(label, mx, my);
    ctx.textAlign = "left";
    ctx.restore();
  }

  function drawAnnot(ctx: CanvasRenderingContext2D, a: Annotation) {
    ctx.save();
    ctx.strokeStyle = a.color; ctx.fillStyle = a.color;
    ctx.lineWidth = a.lineWidth; ctx.lineCap = "round"; ctx.lineJoin = "round";
    if (a.type === "pen" && a.points.length > 1) {
      ctx.beginPath(); ctx.moveTo(a.points[0].x, a.points[0].y);
      a.points.forEach(p => ctx.lineTo(p.x, p.y)); ctx.stroke();
    } else if (a.type === "arrow" && a.points.length >= 2) {
      const [from, to] = [a.points[0], a.points[a.points.length - 1]];
      const angle = Math.atan2(to.y - from.y, to.x - from.x);
      const hl = 14;
      ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y);
      ctx.lineTo(to.x - hl * Math.cos(angle - 0.4), to.y - hl * Math.sin(angle - 0.4));
      ctx.moveTo(to.x, to.y);
      ctx.lineTo(to.x - hl * Math.cos(angle + 0.4), to.y - hl * Math.sin(angle + 0.4));
      ctx.stroke();
    } else if (a.type === "text" && a.text) {
      ctx.font = `bold 16px sans-serif`;
      ctx.fillText(a.text, a.points[0].x, a.points[0].y);
    }
    ctx.restore();
  }

  function drawMeasLine(
    ctx: CanvasRenderingContext2D,
    from: { x: number; y: number },
    to: { x: number; y: number },
    label: string,
    color: string
  ) {
    ctx.save();
    ctx.strokeStyle = color; ctx.fillStyle = color;
    ctx.lineWidth = 2; ctx.setLineDash([6, 3]);
    ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.font = "bold 13px sans-serif"; ctx.textAlign = "center";
    ctx.fillText(label, (from.x + to.x) / 2, (from.y + to.y) / 2 - 6);
    ctx.textAlign = "left";
    ctx.restore();
  }

  // Compensates for the canvas being rendered at a different zoom level
  // than when the calibration was originally captured.
  function realFromPixels(px: number, calib: CalibrationData): number {
    const scaleFactor = calib.calibratedAtScale ? calib.calibratedAtScale / scale : 1;
    return (px * scaleFactor) / calib.pixelsPerUnit;
  }

  function formatMeasurement(px: number, calib: CalibrationData): string {
    const real = realFromPixels(px, calib);
    return calib.unit === "in" ? formatInches(real) : `${real.toFixed(2)} ${calib.unit}`;
  }

  useLayoutEffect(() => { redrawAnnotations(annotations); }, [annotations, measurements, calibPoints, calibStep, calibration, measStart, activeTool]);

  // ── Pointer events ────────────────────────────────────────────────────────
  // Mouse and single-touch input share this canvas-space conversion and the
  // handlePointerDown/Move/Up logic below; only the raw event extraction
  // differs between onMouse* and onTouch*.
  function posFromClient(clientX: number, clientY: number): { x: number; y: number } {
    const canvas = annotCanvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY };
  }

  function getCanvasPos(e: React.MouseEvent<HTMLCanvasElement>): { x: number; y: number } {
    return posFromClient(e.clientX, e.clientY);
  }

  function getTouchPos(e: React.TouchEvent<HTMLCanvasElement>): { x: number; y: number } {
    const touch = e.touches[0] || e.changedTouches[0];
    return posFromClient(touch.clientX, touch.clientY);
  }

  function handlePointerDown(pos: { x: number; y: number }, clientX: number, clientY: number) {
    if (activeTool === "pan") {
      // Grab an existing measurement line if the tap lands near it,
      // instead of panning the view.
      const hit = measurements.find(m => distToSegment(pos, m.from, m.to) < 10);
      if (hit) {
        setDraggingMeasId(hit.id);
        const mx = (hit.from.x + hit.to.x) / 2, my = (hit.from.y + hit.to.y) / 2;
        dragOffset.current = { x: pos.x - mx, y: pos.y - my };
        return;
      }
      isPanning.current = true;
      panStart.current = { mx: clientX, my: clientY, px: pan.x, py: pan.y };
      return;
    }
    if (activeTool === "pen" || activeTool === "arrow") {
      isAnnotDrawing.current = true;
      const a: Annotation = { id: crypto.randomUUID(), type: activeTool, color: penColor, lineWidth: penWidth, points: [pos] };
      drawingAnnot.current = a;
      return;
    }
    if (activeTool === "text") {
      setTextPos(pos); return;
    }
    if (activeTool === "measure") {
      const snapped = snapToPoint(pos);
      if (measStart === null) {
        setMeasStart(snapped);
      } else {
        // Second tap — finalize the measurement and open the save popup.
        const start = measStart;
        const dx = snapped.x - start.x; const dy = snapped.y - start.y;
        const px = Math.sqrt(dx * dx + dy * dy);
        const real = calibration ? realFromPixels(px, calibration) : null;
        const label = real != null
          ? (calibration!.unit === "in" ? formatInches(real) : `${real.toFixed(2)} ${calibration!.unit}`)
          : `${px.toFixed(0)} px`;
        const m: Measurement = {
          id: crypto.randomUUID(), from: start, to: snapped,
          label, pixelLength: px, realLength: real, unit: calibration?.unit ?? null,
        };
        setPendingMeas(m);
        setMeasStart(null);
      }
      return;
    }
    if (activeTool === "calibrate") {
      const snapped = snapToPoint(pos);
      if (calibStep === "idle") {
        setCalibPoints([snapped]);
        setCalibStep("drawing");
      } else if (calibStep === "drawing" && calibPoints.length === 1) {
        // Second tap — compute pixel distance and open input dialog.
        // The locked dot/line stays visible via the calibPoints-driven redraw effect.
        const dx = snapped.x - calibPoints[0].x;
        const dy = snapped.y - calibPoints[0].y;
        const px = Math.sqrt(dx * dx + dy * dy);
        setCalibPoints([calibPoints[0], snapped]);
        setPendingCalib({ from: calibPoints[0], to: snapped, px });
        setCalibStep("input");
      }
      return;
    }
  }

  function handlePointerMove(pos: { x: number; y: number }, clientX: number, clientY: number) {
    if (draggingMeasId) {
      const dragged = measurements.find(m => m.id === draggingMeasId);
      if (dragged && dragOffset.current) {
        const newMx = pos.x - dragOffset.current.x;
        const newMy = pos.y - dragOffset.current.y;
        const halfX = (dragged.to.x - dragged.from.x) / 2;
        const halfY = (dragged.to.y - dragged.from.y) / 2;
        setMeasurements(prev => prev.map(m => m.id === draggingMeasId
          ? { ...m, from: { x: newMx - halfX, y: newMy - halfY }, to: { x: newMx + halfX, y: newMy + halfY } }
          : m));
      }
      return;
    }
    if (activeTool === "pan" && isPanning.current && panStart.current) {
      setPan({ x: panStart.current.px + clientX - panStart.current.mx, y: panStart.current.py + clientY - panStart.current.my });
      return;
    }
    if ((activeTool === "pen" || activeTool === "arrow") && isAnnotDrawing.current && drawingAnnot.current) {
      if (activeTool === "pen") drawingAnnot.current.points.push(pos);
      else drawingAnnot.current.points = [drawingAnnot.current.points[0], pos];
      const ann = annotCanvasRef.current!;
      const ctx = ann.getContext("2d")!;
      ctx.clearRect(0, 0, ann.width, ann.height);
      annotations.forEach(a => drawAnnot(ctx, a));
      measurements.forEach(m => drawMeasLine(ctx, m.from, m.to, m.label, "#f97316"));
      drawCalibOverlay(ctx);
      drawAnnot(ctx, drawingAnnot.current);
    }
    if (activeTool === "calibrate" && calibStep === "drawing" && calibPoints.length === 1) {
      const snapped = snapToPoint(pos);
      const ann = annotCanvasRef.current;
      if (!ann) return;
      const ctx = ann.getContext("2d")!;
      ctx.clearRect(0, 0, ann.width, ann.height);
      annotations.forEach(a => drawAnnot(ctx, a));
      measurements.forEach(m => drawMeasLine(ctx, m.from, m.to, m.label, "#f97316"));
      drawFirstPointRing(ctx, calibPoints[0], "#f59e0b");
      drawCalibLine(ctx, calibPoints[0], snapped);
      return;
    }
    if (activeTool === "measure" && measStart !== null) {
      const snapped = snapToPoint(pos);
      const start = measStart;
      const ann = annotCanvasRef.current!;
      const ctx = ann.getContext("2d")!;
      ctx.clearRect(0, 0, ann.width, ann.height);
      annotations.forEach(a => drawAnnot(ctx, a));
      measurements.forEach(m => drawMeasLine(ctx, m.from, m.to, m.label, "#f97316"));
      drawCalibOverlay(ctx);
      drawFirstPointRing(ctx, start, "#f97316");
      const px = Math.hypot(snapped.x - start.x, snapped.y - start.y);
      const liveLabel = calibration
        ? formatMeasurement(px, calibration)
        : `${px.toFixed(0)} px`;
      drawMeasLine(ctx, start, snapped, liveLabel, "#f97316");
    }
  }

  function handlePointerUp() {
    isPanning.current = false;
    if (draggingMeasId) {
      setDraggingMeasId(null);
      dragOffset.current = null;
      return;
    }
    if ((activeTool === "pen" || activeTool === "arrow") && isAnnotDrawing.current && drawingAnnot.current) {
      isAnnotDrawing.current = false;
      const next = [...annotations, drawingAnnot.current];
      setAnnotations(next);
      drawingAnnot.current = null;
      return;
    }
    // Measure and calibrate are both two-tap tools; nothing to do on release
  }

  function onMouseDown(e: React.MouseEvent<HTMLCanvasElement>) {
    handlePointerDown(getCanvasPos(e), e.clientX, e.clientY);
  }
  function onMouseMove(e: React.MouseEvent<HTMLCanvasElement>) {
    handlePointerMove(getCanvasPos(e), e.clientX, e.clientY);
  }
  function onMouseUp() {
    handlePointerUp();
  }

  function pinchDistance(e: React.TouchEvent<HTMLCanvasElement>): number {
    const dx = e.touches[0].clientX - e.touches[1].clientX;
    const dy = e.touches[0].clientY - e.touches[1].clientY;
    return Math.hypot(dx, dy);
  }

  function onTouchStart(e: React.TouchEvent<HTMLCanvasElement>) {
    e.preventDefault();
    if (e.touches.length === 2) {
      pinchStartDist.current = pinchDistance(e);
      pinchStartScale.current = scale;
      liveScaleRef.current = scale;
      // Anchor the zoom at the pinch midpoint, in the wrapper's own
      // untransformed local space (what transform-origin expects) rather
      // than the corner. The wrapper's transform now has a *permanent*
      // scale() applied (see cssScaleFor), so getBoundingClientRect()
      // returns the already-scaled visual box — divide by the currently
      // applied CSS scale to convert back to local/untransformed units.
      const wrapper = canvasWrapperRef.current;
      if (wrapper) {
        const rect = wrapper.getBoundingClientRect();
        const currentCssScale = cssScaleFor(scale) || 1;
        retargetZoomOrigin({
          x: ((e.touches[0].clientX + e.touches[1].clientX) / 2 - rect.left) / currentCssScale,
          y: ((e.touches[0].clientY + e.touches[1].clientY) / 2 - rect.top) / currentCssScale,
        }, currentCssScale);
      }
      return;
    }
    handlePointerDown(getTouchPos(e), e.touches[0].clientX, e.touches[0].clientY);
  }
  function onTouchMove(e: React.TouchEvent<HTMLCanvasElement>) {
    e.preventDefault();
    if (e.touches.length === 2) {
      if (pinchStartDist.current === 0) return;
      const dist = pinchDistance(e);
      const newScale = Math.min(5, Math.max(0.25, pinchStartScale.current * (dist / pinchStartDist.current)));
      applyLiveScale(newScale);
      return;
    }
    handlePointerMove(getTouchPos(e), e.touches[0].clientX, e.touches[0].clientY);
  }
  function onTouchEnd(e: React.TouchEvent<HTMLCanvasElement>) {
    e.preventDefault();
    if (e.touches.length < 2 && pinchStartDist.current !== 0) {
      // Pinch just ended — save the final scale (just updates state for
      // the next gesture and the toolbar's % display; the CSS transform
      // is already showing the correct result, no re-render involved).
      pinchStartDist.current = 0;
      commitLiveScale();
      return;
    }
    pinchStartDist.current = 0;
    handlePointerUp();
  }

  function commitText() {
    if (!textVal.trim() || !textPos) return;
    const a: Annotation = { id: crypto.randomUUID(), type: "text", color: penColor, lineWidth: penWidth, points: [textPos], text: textVal };
    setAnnotations(prev => [...prev, a]);
    setTextPos(null); setTextVal("");
  }

  function commitMeasurement() {
    if (!pendingMeas) return;
    setMeasurements(prev => [...prev, { ...pendingMeas, id: crypto.randomUUID() }]);
    setPendingMeas(null);
  }

  function commitCalibration() {
    if (!pendingCalib) return;
    const realLength = calibUnit === "ft"
      ? (parseFloat(calibFeet || "0") + (parseFloat(calibInches || "0") + parseFloat(calibFraction || "0")) / 12)
      : parseFraction(calibLength);
    if (realLength == null || realLength <= 0) return;
    const ppu = pendingCalib.px / realLength;
    const data: CalibrationData = { pixelsPerUnit: ppu, unit: calibUnit, knownLength: realLength, calibratedAtScale: scale };
    setCalibration(data);
    onCalibrationSave(data);
    showToast(`✅ Calibrated: 1 ${data.unit} = ${ppu.toFixed(1)} px`);
    setPendingCalib(null); setCalibLength("");
    setCalibFeet(""); setCalibInches(""); setCalibFraction("0");
    // Keep calibStep "idle" but leave calibPoints so the locked line
    // stays visible on the plan with its real-world length label.
    setCalibStep("idle");
  }

  function clearCalibration() {
    setCalibration(null);
    onCalibrationSave(null);
    setCalibPoints([]);
  }

  function cancelMeasure() {
    if (measStart !== null) setMeasStart(null);
    setActiveTool("pan");
  }

  function cancelCalibration() {
    // Only an in-progress (uncommitted) attempt exists while calibStep !== "idle";
    // discard it entirely. A previously committed line has calibStep "idle" and
    // is left untouched.
    if (calibStep !== "idle") {
      setCalibStep("idle");
      setCalibPoints([]);
      setPendingCalib(null);
    }
    setActiveTool("pan");
  }

  // Escape backs out of the measure/calibrate tools without losing a
  // previously committed calibration line (that has calibStep "idle").
  // Also handles zoom shortcuts, guarded so typing in a text field (e.g.
  // the calibration length input, which can contain "-" and "+") never
  // triggers a zoom change.
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      const target = e.target as HTMLElement;
      const isTyping = target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT";
      if (e.key === "Escape") {
        if (activeTool === "measure") cancelMeasure();
        else if (activeTool === "calibrate") cancelCalibration();
        return;
      }
      if (isTyping) return;
      // Ctrl/Cmd+Plus/Minus/0 are browser zoom shortcuts — best-effort
      // block so they drive the canvas zoom instead of the whole page
      // (browsers may still ignore preventDefault on these reserved keys).
      if ((e.ctrlKey || e.metaKey) && (e.key === "+" || e.key === "=" || e.key === "-" || e.key === "0")) {
        e.preventDefault();
        if (e.key === "0") { setScale(1); return; }
      }
      if (e.key === "+" || e.key === "=") setScale(s => Math.min(s + 0.25, 5));
      else if (e.key === "-") setScale(s => Math.max(s - 0.25, 0.25));
      else if (e.key === "m" || e.key === "M") setScale(2);
      else if (e.key === "f" || e.key === "F") setScale(1);
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeTool, annotations, calibStep]);

  // Belt-and-suspenders backstop for the CSS touchAction:"none" above —
  // some browsers (notably older Safari) don't fully honor touch-action
  // for pinch gestures, so also block the native default at the JS level.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const preventPinch = (e: TouchEvent) => {
      if (e.touches.length > 1) e.preventDefault();
    };
    el.addEventListener("touchstart", preventPinch, { passive: false });
    el.addEventListener("touchmove", preventPinch, { passive: false });
    return () => {
      el.removeEventListener("touchstart", preventPinch);
      el.removeEventListener("touchmove", preventPinch);
    };
  }, []);

  // Desktop trackpad pinch-to-zoom and Ctrl+scroll both fire as wheel
  // events with ctrlKey true (that's how Chrome/Firefox report them —
  // there's no separate "pinch" event on desktop). Left alone, this zooms
  // the whole browser page, including the toolbar. Intercept it and drive
  // the canvas-only zoom instead, matching the touch pinch behavior.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handleWheelZoom = (e: WheelEvent) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      // First tick of a new gesture (no pending commit yet) starts from the
      // committed scale; subsequent ticks within the same gesture compound
      // on top of the live value so rapid trackpad ticks don't fight the
      // still-pending commit.
      if (wheelZoomEndTimer.current === null) liveScaleRef.current = scale;
      // Anchor on the current cursor position so the zoom expands from
      // under the pointer rather than the corner. liveScaleRef.current
      // here still holds whatever CSS scale is *currently* applied to
      // the wrapper (just synced above, or from the previous tick) —
      // getBoundingClientRect() reflects that already-applied scale, so
      // dividing it back out converts to the untransformed local units
      // transform-origin expects.
      const wrapper = canvasWrapperRef.current;
      if (wrapper) {
        const rect = wrapper.getBoundingClientRect();
        const currentCssScale = cssScaleFor(liveScaleRef.current) || 1;
        retargetZoomOrigin({
          x: (e.clientX - rect.left) / currentCssScale,
          y: (e.clientY - rect.top) / currentCssScale,
        }, currentCssScale);
      }
      const newScale = Math.min(5, Math.max(0.25, liveScaleRef.current - e.deltaY * 0.01));
      applyLiveScale(newScale);
      if (wheelZoomEndTimer.current) clearTimeout(wheelZoomEndTimer.current);
      // Wheel has no discrete "gesture end" event, so debounce: commit
      // (save the final value to state) once ticks stop arriving, rather
      // than triggering a React re-render on every single tick.
      wheelZoomEndTimer.current = setTimeout(() => {
        wheelZoomEndTimer.current = null;
        commitLiveScale();
      }, 150);
    };
    el.addEventListener("wheel", handleWheelZoom, { passive: false });
    return () => {
      el.removeEventListener("wheel", handleWheelZoom);
      if (wheelZoomEndTimer.current) clearTimeout(wheelZoomEndTimer.current);
    };
  }, [scale, pan]);

  function addBookmark() {
    const b: BookmarkItem = { id: crypto.randomUUID(), page: pageNum, label: bookmarkLabel || `Page ${pageNum}`, note: "" };
    setBookmarks(prev => [...prev, b]);
    setBookmarkLabel(""); setAddingBookmark(false);
  }

  function exportAnnotated() {
    const base = canvasRef.current;
    const ann = annotCanvasRef.current;
    if (!base || !ann) return;
    const out = document.createElement("canvas");
    out.width = base.width; out.height = base.height;
    const ctx = out.getContext("2d")!;
    ctx.drawImage(base, 0, 0);
    ctx.drawImage(ann, 0, 0);
    const a = document.createElement("a");
    a.download = `${plan.file_name}-p${pageNum}-annotated.png`;
    a.href = out.toDataURL("image/png"); a.click();
  }

  const TOOLS = [
    { key: "pan" as const, icon: <Move size={15}/>, title: "Pan" },
    { key: "pen" as const, icon: <Pencil size={15}/>, title: "Draw" },
    { key: "arrow" as const, icon: <ArrowRight size={15}/>, title: "Arrow" },
    { key: "text" as const, icon: <Type size={15}/>, title: "Text" },
    { key: "measure" as const, icon: <Ruler size={15}/>, title: "Measure" },
    { key: "calibrate" as const, icon: <Maximize2 size={15}/>, title: "Calibrate" },
  ];
  const COLORS = ["#ef4444","#f97316","#eab308","#22c55e","#3b82f6","#8b5cf6","#ffffff","#000000"];

  return (
    <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col" style={{ touchAction: "none" }}>
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 bg-slate-900 border-b border-slate-800 flex-wrap">
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
          <X size={16}/>
        </button>
        <span className="text-sm font-semibold text-white truncate max-w-xs">{plan.file_name}</span>

        <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1 ml-1">
          {TOOLS.map(t => (
            <button key={t.key} onClick={() => setActiveTool(t.key)} title={t.title}
              className={`p-1.5 rounded-md transition-colors ${activeTool === t.key ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-700"}`}>
              {t.icon}
            </button>
          ))}
        </div>

        {activeTool === "measure" && (
          <button onClick={cancelMeasure}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-500/20 border border-red-500/40 text-red-400 text-xs font-semibold hover:bg-red-500/30 transition-colors">
            <X size={12}/> Cancel Measure (Esc)
          </button>
        )}

        {/* Color + width (pen/arrow/text) */}
        {(activeTool === "pen" || activeTool === "arrow" || activeTool === "text") && (
          <div className="flex items-center gap-1.5">
            {COLORS.map(c => (
              <button key={c} onClick={() => setPenColor(c)}
                className={`w-5 h-5 rounded-full border-2 transition-transform ${penColor === c ? "border-white scale-125" : "border-transparent"}`}
                style={{ background: c }}/>
            ))}
            {[1, 2, 4].map(w => (
              <button key={w} onClick={() => setPenWidth(w)}
                className={`px-2 py-0.5 rounded text-xs font-bold transition-colors ${penWidth === w ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"}`}>
                {w}
              </button>
            ))}
          </div>
        )}

        {calibration ? (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            <span>📏</span>
            <span>Calibrated · 1 {calibration.unit} = {calibration.pixelsPerUnit.toFixed(1)} px</span>
            <button onClick={clearCalibration} className="ml-1 text-emerald-300 hover:text-red-400 transition-colors" title="Clear calibration">
              <X size={12}/>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-700/50 border border-slate-600/30 text-slate-500 text-xs">
            <span>📏</span>
            <span>Not calibrated</span>
          </div>
        )}

        <div className="flex-1"/>

        {/* Page nav */}
        {isPdf && (
          <div className="flex items-center gap-1">
            <button onClick={() => setPageNum(p => Math.max(1, p - 1))} disabled={pageNum === 1}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white disabled:opacity-30 transition-colors">
              <ChevronLeftIcon size={15}/>
            </button>
            <span className="text-xs text-slate-300 px-1">{pageNum} / {totalPages}</span>
            <button onClick={() => setPageNum(p => Math.min(totalPages, p + 1))} disabled={pageNum === totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white disabled:opacity-30 transition-colors">
              <ChevronRight size={15}/>
            </button>
          </div>
        )}

        {/* Zoom */}
        <div className="flex items-center gap-1">
          <button onClick={() => setScale(s => Math.max(0.3, +(s - 0.2).toFixed(1)))} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"><ZoomOut size={15}/></button>
          <span className="text-xs text-slate-300 w-10 text-center">{Math.round(scale * 100)}%</span>
          <button onClick={() => setScale(s => Math.min(5, +(s + 0.2).toFixed(1)))} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"><ZoomIn size={15}/></button>
          <button onClick={() => { setScale(1.2); setPan({ x: 0, y: 0 }); }} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors" title="Reset view"><RotateCcw size={13}/></button>
        </div>

        <button onClick={() => setShowThumbs(s => !s)} title="Thumbnails"
          className={`p-1.5 rounded-lg transition-colors ${showThumbs ? "bg-blue-600 text-white" : "hover:bg-slate-800 text-slate-400 hover:text-white"}`}>
          <Layers size={15}/>
        </button>
        <button onClick={() => setShowBookmarks(s => !s)} title="Bookmarks"
          className={`p-1.5 rounded-lg transition-colors ${showBookmarks ? "bg-blue-600 text-white" : "hover:bg-slate-800 text-slate-400 hover:text-white"}`}>
          <Bookmark size={15}/>
        </button>
        <button onClick={() => setAddingBookmark(true)} title="Add bookmark"
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
          <Plus size={15}/>
        </button>
        <button onClick={exportAnnotated} title="Export annotated PNG"
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
          <Download size={15}/>
        </button>
        <button onClick={() => { setAnnotations([]); setMeasurements([]); }} title="Clear annotations"
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-red-400 transition-colors">
          <Trash2 size={15}/>
        </button>
      </div>

      {(activeTool === "calibrate" || activeTool === "measure") && (
        <div className="flex-shrink-0 px-4 py-2 bg-amber-500/10 border-b border-amber-500/20 text-amber-400 text-xs font-medium flex items-center gap-2">
          {activeTool === "calibrate"
            ? (calibStep === "idle"
                ? "📏 Tap point 1 on a known measurement"
                : calibStep === "drawing"
                ? "📏 ● Point 1 set — tap point 2"
                : null)
            : (measStart === null
                ? "📐 Tap point 1 to start measuring"
                : "📐 ● Point 1 set — tap point 2")}
        </div>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl bg-emerald-600 text-white text-sm font-semibold shadow-2xl">
          {toast}
        </div>
      )}

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Thumbnail strip */}
        {showThumbs && isPdf && (
          <div className="w-28 bg-slate-900 border-r border-slate-800 overflow-y-auto flex flex-col gap-2 p-2 flex-shrink-0">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <div key={p} onClick={() => setPageNum(p)}
                className={`rounded-lg overflow-hidden cursor-pointer border-2 transition-colors ${pageNum === p ? "border-blue-500" : "border-transparent hover:border-slate-600"}`}>
                <canvas
                  ref={el => { if (el) thumbRefs.current.set(p, el); }}
                  className="w-full"
                />
                <div className="text-center text-[10px] text-slate-500 py-0.5">{p}</div>
              </div>
            ))}
          </div>
        )}

        {/* Bookmark panel */}
        {showBookmarks && (
          <div className="w-56 bg-slate-900 border-r border-slate-800 overflow-y-auto flex flex-col gap-1 p-3 flex-shrink-0">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Bookmarks</div>
            {bookmarks.length === 0 && (
              <div className="text-xs text-slate-600 text-center py-4">No bookmarks yet.<br/>Use + to add one.</div>
            )}
            {bookmarks.map(b => (
              <div key={b.id} onClick={() => { setPageNum(b.page); }}
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-800 cursor-pointer group">
                <Bookmark size={12} className="text-amber-400 flex-shrink-0"/>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-slate-200 truncate">{b.label}</div>
                  <div className="text-[10px] text-slate-500">Page {b.page}</div>
                </div>
                <button onClick={ev => { ev.stopPropagation(); setBookmarks(prev => prev.filter(x => x.id !== b.id)); }}
                  className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:text-red-400 text-slate-500 transition-all">
                  <X size={10}/>
                </button>
              </div>
            ))}
            {calibration && (
              <div className="mt-3 pt-3 border-t border-slate-800">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Calibration</div>
                <div className="text-xs text-slate-300">{calibration.pixelsPerUnit.toFixed(1)} px/{calibration.unit}</div>
                <button onClick={clearCalibration} className="text-[10px] text-red-400 hover:text-red-300 mt-1">Clear</button>
              </div>
            )}
          </div>
        )}

        {/* Canvas area */}
        <div ref={containerRef} className="flex-1 overflow-auto bg-slate-950 relative flex p-4">
          {rendering && (
            <div className="absolute inset-0 flex items-center justify-center z-10">
              <div className="text-slate-400 text-sm animate-pulse">Rendering…</div>
            </div>
          )}
          {/* margin: auto (not items-center/justify-center) centers this when
              smaller than the container while staying fully scrollable to
              every edge when zoomed in past the container size — plain
              flex centering clips the start edge of overflowing content. */}
          <div ref={canvasWrapperRef} style={{ userSelect: "none", margin: "auto" }} className="relative inline-block">
            {isPdf ? (
              <canvas ref={canvasRef} className="block shadow-2xl"/>
            ) : (
              <img ref={imgRef} src={plan.publicUrl} alt={plan.file_name} crossOrigin="anonymous" className="block shadow-2xl max-w-none" onLoad={() => { syncAnnotCanvas(); detectEdges(); }}/>
            )}
            <canvas ref={annotCanvasRef}
              className="absolute inset-0 w-full h-full"
              style={{ cursor: activeTool === "pan" ? "grab" : "crosshair", touchAction: "none" }}
              onMouseDown={onMouseDown} onMouseMove={onMouseMove} onMouseUp={onMouseUp} onMouseLeave={onMouseUp}
              onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}
            />
            {(activeTool === "calibrate" || activeTool === "measure") && snapIndicator && annotCanvasRef.current && (
              <div className="absolute pointer-events-none rounded-full border-2 border-emerald-400 bg-emerald-400/20"
                style={{
                  left: (snapIndicator.x / annotCanvasRef.current.width) * 100 + "%",
                  top: (snapIndicator.y / annotCanvasRef.current.height) * 100 + "%",
                  width: 16, height: 16,
                  transform: "translate(-50%, -50%)",
                }}
              />
            )}
          </div>

          {/* Text input overlay */}
          {textPos && (
            <div className="absolute z-20 flex items-center gap-2 bg-slate-900/95 border border-slate-700 rounded-xl p-3 shadow-2xl" style={{ top: "20%", left: "50%", transform: "translateX(-50%)" }}>
              <input value={textVal} onChange={e => setTextVal(e.target.value)}
                onKeyDown={e => e.key === "Enter" && commitText()}
                autoFocus placeholder="Label…"
                className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none w-40"/>
              <button onClick={commitText} className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white"><Check size={14}/></button>
              <button onClick={() => { setTextPos(null); setTextVal(""); }} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400"><X size={14}/></button>
            </div>
          )}

          {/* Add bookmark overlay */}
          {addingBookmark && (
            <div className="absolute z-20 flex items-center gap-2 bg-slate-900/95 border border-slate-700 rounded-xl p-3 shadow-2xl" style={{ top: "20%", left: "50%", transform: "translateX(-50%)" }}>
              <Bookmark size={14} className="text-amber-400"/>
              <input value={bookmarkLabel} onChange={e => setBookmarkLabel(e.target.value)}
                onKeyDown={e => e.key === "Enter" && addBookmark()}
                autoFocus placeholder={`Bookmark page ${pageNum}…`}
                className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none w-44"/>
              <button onClick={addBookmark} className="p-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white"><Check size={14}/></button>
              <button onClick={() => setAddingBookmark(false)} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400"><X size={14}/></button>
            </div>
          )}

          {/* Measurement confirm overlay */}
          {pendingMeas && (
            <div className="absolute z-20 bg-slate-900/95 border border-slate-700 rounded-xl p-4 shadow-2xl" style={{ top: "20%", left: "50%", transform: "translateX(-50%)" }}>
              <div className="text-sm text-slate-200 mb-2">Add measurement?</div>
              <div className="text-xs text-slate-400 mb-3">
                {pendingMeas.label} ({pendingMeas.pixelLength.toFixed(0)} px)
                {calibration ? "" : " — calibrate for real units"}
              </div>
              <div className="flex gap-2">
                <button onClick={commitMeasurement} className="px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold">Add</button>
                <button onClick={() => setPendingMeas(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs">Discard</button>
              </div>
            </div>
          )}

          {/* Calibration confirm overlay */}
          {pendingCalib && (
            <div className="absolute z-20 bg-slate-900/95 border border-slate-700 rounded-xl p-4 shadow-2xl" style={{ top: "20%", left: "50%", transform: "translateX(-50%)" }}>
              <div className="text-sm font-semibold text-slate-200 mb-1">Set calibration</div>
              <div className="text-xs text-slate-400 mb-3">Line = {pendingCalib.px.toFixed(0)} px. What is the real length?</div>
              <div className="flex items-end gap-2 mb-3">
                {calibUnit === "ft" ? (
                  <>
                    <div className="flex flex-col items-center gap-1">
                      <input type="number" min="0" value={calibFeet} onChange={e => setCalibFeet(e.target.value)}
                        onKeyDown={e => e.key === "Enter" && commitCalibration()}
                        placeholder="0" autoFocus
                        className="w-16 px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white text-center focus:outline-none focus:border-blue-500"/>
                      <span className="text-[10px] text-slate-500">ft</span>
                    </div>
                    <span className="text-slate-500 text-sm mb-4">—</span>
                    <div className="flex flex-col items-center gap-1">
                      <input type="number" min="0" max="11" value={calibInches} onChange={e => setCalibInches(e.target.value)}
                        onKeyDown={e => e.key === "Enter" && commitCalibration()}
                        placeholder="0"
                        className="w-16 px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white text-center focus:outline-none focus:border-blue-500"/>
                      <span className="text-[10px] text-slate-500">in</span>
                    </div>
                    <span className="text-slate-500 text-sm mb-4">—</span>
                    <div className="flex flex-col items-center gap-1">
                      <select value={calibFraction} onChange={e => setCalibFraction(e.target.value)}
                        className="w-20 px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white text-center focus:outline-none focus:border-blue-500">
                        <option value="0">—</option>
                        <option value="0.125">⅛"</option>
                        <option value="0.25">¼"</option>
                        <option value="0.375">⅜"</option>
                        <option value="0.5">½"</option>
                        <option value="0.625">⅝"</option>
                        <option value="0.75">¾"</option>
                        <option value="0.875">⅞"</option>
                      </select>
                      <span className="text-[10px] text-slate-500">frac</span>
                    </div>
                  </>
                ) : (
                  <input value={calibLength} onChange={e => setCalibLength(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && commitCalibration()}
                    placeholder={calibUnit === "in" ? `e.g. 10 or 10 1/4` : "e.g. 10"} autoFocus
                    className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white w-28 focus:outline-none"/>
                )}
                <select value={calibUnit} onChange={e => setCalibUnit(e.target.value)}
                  className="px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none">
                  {["ft","m","in","mm","cm","yd"].map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              {calibUnit === "ft" && (
                <div className="text-xs text-amber-400 mb-3 text-center">
                  = {(parseFloat(calibFeet || "0") + (parseFloat(calibInches || "0") + parseFloat(calibFraction || "0")) / 12).toFixed(4)} ft
                </div>
              )}
              {calibUnit === "in" && (
                <div className="text-[10px] text-slate-500 mb-3 -mt-2">Accepts: 10, 10 1/4, 10-1/4</div>
              )}
              <div className="flex gap-2">
                <button onClick={commitCalibration} className="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold">Save calibration</button>
                <button onClick={() => { setPendingCalib(null); setCalibStep("idle"); setCalibPoints([]); }} className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs">Cancel</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── FileList ─────────────────────────────────────────────────────────────────
function FileList({
  plans,
  uploading,
  onUpload,
  onOpen,
  onDelete,
}: {
  plans: Plan[];
  uploading: boolean;
  onUpload: (files: FileList) => void;
  onOpen: (plan: Plan) => void;
  onDelete: (plan: Plan) => void;
}) {
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("All");
  const fileRef = useRef<HTMLInputElement>(null);

  const filtered = plans.filter(p => {
    const matchCat = catFilter === "All" || p.category === catFilter;
    const matchSearch = !search || p.file_name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const cats = ["All", ...CATEGORIES.filter(c => plans.some(p => p.category === c))];

  function thumbUrl(plan: Plan) {
    if (plan.file_type.startsWith("image/")) return plan.publicUrl;
    return null;
  }

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search plans…"
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
        </div>
        <select value={catFilter} onChange={e => setCatFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none">
          {cats.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button onClick={() => fileRef.current?.click()} disabled={uploading}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold transition-colors">
          <Upload size={14}/> {uploading ? "Uploading…" : "Upload"}
        </button>
        <input ref={fileRef} type="file" accept=".pdf,image/*" multiple className="hidden"
          onChange={e => e.target.files && onUpload(e.target.files)}/>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-4xl mb-3">📐</div>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            {plans.length === 0 ? "No plans uploaded yet — click Upload to add PDFs or images." : "No plans match your search."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map(plan => {
            const thumb = thumbUrl(plan);
            return (
              <div key={plan.id}
                className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer"
                onClick={() => onOpen(plan)}>
                {/* Thumbnail */}
                <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-800 flex items-center justify-center overflow-hidden">
                  {thumb ? (
                    <img src={thumb} alt={plan.file_name} className="w-full h-full object-cover"/>
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <div className="text-3xl">📄</div>
                      {plan.page_count > 1 && (
                        <div className="text-xs text-slate-400">{plan.page_count} pages</div>
                      )}
                    </div>
                  )}
                </div>
                {/* Info */}
                <div className="p-3">
                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-200 truncate">{plan.file_name}</div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">{plan.category}</span>
                    <span className="text-[10px] text-slate-400">{fmtSize(plan.file_size)}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">{fmtDate(plan.created_at)}</div>
                </div>
                {/* Actions */}
                <div className="border-t border-slate-100 dark:border-slate-800 flex opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={e => { e.stopPropagation(); onOpen(plan); }}
                    className="flex-1 py-2 text-xs font-medium text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-500/10 transition-colors">
                    Open
                  </button>
                  <div className="w-px bg-slate-100 dark:bg-slate-800"/>
                  <button onClick={e => { e.stopPropagation(); onDelete(plan); }}
                    className="flex-1 py-2 text-xs font-medium text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors">
                    Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function ProjectPlansPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [viewingPlan, setViewingPlan] = useState<Plan | null>(null);

  // Category picker during upload
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [uploadCategory, setUploadCategory] = useState("General");
  const [showCategoryModal, setShowCategoryModal] = useState(false);

  useEffect(() => {
    if (projectId) { loadProject(); loadPlans(); }
  }, [projectId]);

  async function loadProject() {
    const { data } = await supabase.from("projects").select("name").eq("id", projectId!).single();
    if (data) setProjectName(data.name);
  }

  async function loadPlans() {
    setLoading(true);
    const { data } = await supabase
      .from("project_plans").select("*").eq("project_id", projectId!)
      .order("created_at", { ascending: false });
    // file_url is a storage PATH in the private private-files bucket; sign it on read. (The Plan field is still called
    // publicUrl, but it now holds a signed URL.)
    const rows = data || [];
    const signed = await signPrivatePaths(rows.map((p: any) => p.file_url));
    const withUrls = rows.map((p: any) => ({ ...p, publicUrl: signed.get(p.file_url) || "" } as Plan));
    setPlans(withUrls);
    setLoading(false);
  }

  // pdf.js re-fetches the whole file for every page it renders, so the viewer must never be handed a URL that is about to
  // lapse: sign a fresh one each time a plan is opened (on top of the 24-hour window from loadPlans).
  async function openPlan(plan: Plan) {
    const fresh = await signPrivatePath(plan.file_url);
    setViewingPlan(fresh ? { ...plan, publicUrl: fresh } : plan);
  }

  function handleFileDrop(files: FileList) {
    const arr = Array.from(files);
    setPendingFiles(arr);
    setUploadCategory("General");
    setShowCategoryModal(true);
  }

  async function doUpload() {
    if (!pendingFiles.length || !projectId) return;
    setShowCategoryModal(false);
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { data: profile } = await supabase.from("user_profiles").select("company_id").eq("id", user!.id).single();
      // private-files requires the company id as the first folder of the path
      if (!profile?.company_id) { alert("Can't upload plans: your account isn't linked to a company."); return; }

      for (const file of pendingFiles) {
        const ext = file.name.split(".").pop() ?? "bin";
        const path = `${profile.company_id}/plans/${projectId}/${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`;
        const { error: upErr } = await supabase.storage.from("private-files").upload(path, file, { upsert: false });
        if (upErr) { console.error(upErr); continue; }

        let pageCount = 1;
        if (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")) {
          const signedUrl = await signPrivatePath(path);
          if (signedUrl) { try { pageCount = await getPdfPageCount(signedUrl); } catch {} }
        }

        await supabase.from("project_plans").insert({
          project_id: projectId,
          company_id: profile?.company_id,
          file_name: file.name,
          file_url: path,
          file_type: file.type || "application/octet-stream",
          file_size: file.size,
          category: uploadCategory,
          page_count: pageCount,
          uploaded_by: user!.id,
        });
      }
    } finally {
      setUploading(false);
      setPendingFiles([]);
      await loadPlans();
    }
  }

  async function handleDelete(plan: Plan) {
    if (!confirm(`Delete "${plan.file_name}"?`)) return;
    await supabase.from("project_plans").delete().eq("id", plan.id);
    await supabase.storage.from("private-files").remove([plan.file_url]);
    await loadPlans();
  }

  async function handleCalibrationSave(planId: string, data: CalibrationData | null) {
    await supabase.from("project_plans").update({ calibration_data: data }).eq("id", planId);
    setPlans(prev => prev.map(p => p.id === planId ? { ...p, calibration_data: data } : p));
    if (viewingPlan?.id === planId) setViewingPlan(prev => prev ? { ...prev, calibration_data: data } : prev);
  }

  if (loading) return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
      <p className="text-slate-400 text-sm animate-pulse">Loading plans…</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
          <ChevronLeft size={18} className="text-slate-600 dark:text-slate-300"/>
        </button>
        <div className="flex-1">
          <h1 className="text-base font-bold text-slate-800 dark:text-slate-100">Plans & Drawings</h1>
          <p className="text-xs text-slate-500">{projectName}</p>
        </div>
        <span className="text-xs text-slate-400">{plans.length} file{plans.length !== 1 ? "s" : ""}</span>
      </div>

      <div className="max-w-5xl mx-auto p-4">
        <FileList
          plans={plans}
          uploading={uploading}
          onUpload={handleFileDrop}
          onOpen={openPlan}
          onDelete={handleDelete}
        />
      </div>

      {/* Category picker modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl space-y-4">
            <h2 className="text-base font-bold text-slate-800 dark:text-slate-100">Set category</h2>
            <p className="text-xs text-slate-500">{pendingFiles.length} file{pendingFiles.length !== 1 ? "s" : ""} selected</p>
            <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-0.5 max-h-24 overflow-y-auto">
              {pendingFiles.map(f => <li key={f.name} className="truncate">• {f.name}</li>)}
            </ul>
            <select value={uploadCategory} onChange={e => setUploadCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30">
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <div className="flex gap-3">
              <button onClick={doUpload}
                className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm transition-colors">
                Upload
              </button>
              <button onClick={() => { setShowCategoryModal(false); setPendingFiles([]); }}
                className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Plan viewer */}
      {viewingPlan && (
        <PlanViewer
          plan={viewingPlan}
          onClose={() => setViewingPlan(null)}
          onCalibrationSave={data => handleCalibrationSave(viewingPlan.id, data)}
        />
      )}
    </div>
  );
}
