// src/pages/dashboard/AISummaryBanner.tsx
import React, { useEffect, useState } from "react";
import { Sparkles, Volume2, Square } from "lucide-react";
import { supabase } from "../../lib/supabase";
import { aiChat } from "../../lib/magnusAI";
import { fetchOwnerDrawsYTD } from "../../lib/ownerDraws";

const FALLBACK_TEXT =
  "AI summary is unavailable right now — the cards below still show today's real numbers.";

// Session-level cache (persists across remounts/navigation within this
// browser tab, cleared when the tab closes) — "regenerate once per
// dashboard load, not continuously" per the brief. Keyed by company_id so
// switching companies (not that this app supports it today, but just in
// case) doesn't serve a stale summary. Module-level, not React state, so
// it survives this component unmounting/remounting entirely.
const sessionCacheKey = (companyId: string) => `director-dashboard-ai-summary:${companyId}`;

// Free, client-side only — window.speechSynthesis, no external API/cost.
// Checked once per render rather than cached in state since support never
// changes mid-session; cheap enough ("speechSynthesis" in window) not to
// bother memoizing.
function speechSupported() {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

// Minimal, dependency-free **bold** renderer for the visual display. The
// message sent to the model never asks for markdown, but it sometimes
// emits **bold** syntax unprompted (confirmed live — "**$1.78M in liquid
// cash**" rendered as literal asterisks instead of bold text). Checked
// package.json and grepped the codebase first: no markdown library exists
// anywhere here, and no other page already solves this, so pulling in
// react-markdown/marked for one formatting case isn't warranted — a small
// regex split is enough for the one syntax actually observed.
function renderBoldMarkdown(text: string | null): React.ReactNode {
  if (!text) return null; // matches the original {summary} behavior — renders nothing
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    const m = part.match(/^\*\*([^*]+)\*\*$/);
    return m
      ? <strong key={i} className="font-semibold text-slate-900 dark:text-slate-100">{m[1]}</strong>
      : <React.Fragment key={i}>{part}</React.Fragment>;
  });
}

// Plain-text sanitization for speech synthesis — separate from the visual
// renderer above, since TTS needs the marker characters gone entirely, not
// styled: the read-aloud feature was audibly saying "asterisk asterisk"
// before this (confirmed — SpeechSynthesisUtterance was given the raw
// summary string, "**" and all). Bold is the only syntax actually
// observed in a real summary, but *italic*/_italic_/`code` are stripped
// too, defensively — costs nothing and avoids the same bug recurring for
// a different marker the model might emit later. Order matters: **bold**
// must be stripped before the single-* pattern runs, or the single-*
// regex could misfire on the leftover single asterisks of an
// only-partially-processed **bold** span.
function stripMarkdown(text: string): string {
  return text
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/_([^_]+)_/g, "$1")
    .replace(/`([^`]+)`/g, "$1");
}

export default function AISummaryBanner() {
  const [summary, setSummary] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error("Not signed in");
        const { data: profile } = await supabase
          .from("user_profiles").select("company_id").eq("id", user.id).maybeSingle();
        const companyId = profile?.company_id;
        if (!companyId) throw new Error("Couldn't determine company");

        const cacheKey = sessionCacheKey(companyId);
        const cached = sessionStorage.getItem(cacheKey);
        if (cached) {
          if (!alive) return;
          setSummary(cached);
          setLoading(false);
          return;
        }

        // Gather already-aggregated figures the other 8 cards each compute
        // themselves — NOT raw rows. There's no shared state between cards
        // in this dashboard (each resolves its own company_id and queries
        // independently, by design — see the note on CashPositionCard's
        // report about this), so the only way to reuse "already computed"
        // numbers without touching those 8 files is to run the same small,
        // targeted aggregate queries/RPCs they already use, a second time,
        // here. Every query below mirrors an existing card's own query
        // exactly — nothing new is being computed, just re-fetched compactly.
        const todayYear = new Date().getFullYear();
        const monday = (() => {
          const now = new Date();
          const day = now.getDay();
          const diff = day === 0 ? 6 : day - 1;
          const d = new Date(now);
          d.setDate(now.getDate() - diff);
          d.setHours(0, 0, 0, 0);
          return d.toISOString().slice(0, 10);
        })();
        const today = new Date().toISOString().slice(0, 10);

        const [
          cashRes,
          plAccountsRes,
          activeProjectsRes,
          remittanceRes,
          workersRes,
          fieldPaymentsRes,
          agingRes,
          overdueInvoicesRes,
          overdueBillsRes,
        ] = await Promise.all([
          // Cash Position's own filter (type=asset, subtype bank/current_asset)
          supabase.from("v_account_balances").select("current_balance")
            .eq("company_id", companyId).eq("type", "asset").in("subtype", ["bank", "current_asset"]),
          // P&L Overview's own filter
          supabase.from("chart_of_accounts").select("type, current_balance")
            .eq("company_id", companyId).eq("is_active", true).in("type", ["revenue", "expense"]),
          // Project Health's own filter
          supabase.from("projects").select("id").eq("company_id", companyId).eq("status", "active"),
          // Payroll Compliance's own filter, soonest one only
          supabase.from("government_remittances").select("period_month, period_year, due_date, total_due")
            .eq("company_id", companyId).eq("status", "pending").order("due_date", { ascending: true }).limit(1),
          // Workforce Snapshot's own filter
          supabase.from("workers").select("id").eq("company_id", companyId).eq("status", "active"),
          supabase.from("field_payments").select("total_amount").eq("company_id", companyId).gte("work_date", monday),
          // Receivables & Payables' own RPC
          supabase.rpc("get_ar_ap_aging", { p_company_id: companyId }),
          // Needs Attention's own overdue-invoice count
          supabase.from("client_invoices").select("id", { count: "exact", head: true })
            .eq("company_id", companyId).in("status", ["sent", "partial", "overdue"]).gt("balance_due", 0).lte("due_date", today),
          supabase.from("supplier_invoices").select("id", { count: "exact", head: true })
            .eq("company_id", companyId).gt("balance_due", 0).lte("due_date", today),
        ]);

        const totalLiquidCash = (cashRes.data || []).reduce((s, a: any) => s + (Number(a.current_balance) || 0), 0);

        const plRows = plAccountsRes.data || [];
        const totalRevenue = plRows.filter((a: any) => a.type === "revenue").reduce((s, a: any) => s + (Number(a.current_balance) || 0), 0);
        const totalExpenses = plRows.filter((a: any) => a.type === "expense").reduce((s, a: any) => s + (Number(a.current_balance) || 0), 0);
        const netIncome = totalRevenue - totalExpenses;

        const activeProjectCount = (activeProjectsRes.data || []).length;

        const r = (remittanceRes.data || [])[0];
        const nextRemittance = r ? { dueDate: r.due_date, amount: Number(r.total_due) || 0 } : null;

        const activeWorkers = (workersRes.data || []).length;
        const fieldPaymentsThisWeek = (fieldPaymentsRes.data || []).reduce((s, p: any) => s + (Number(p.total_amount) || 0), 0);

        // Owner draws this year, from the SAME shared function the Owner Draws card uses (src/lib/ownerDraws.ts): one entry per equity
        // account with real Fund Transfer activity, named by the account's own name. A failure here just leaves it out of the summary.
        let ownerDraws: Array<{ accountName: string; ytd: number }> = [];
        try {
          ownerDraws = (await fetchOwnerDrawsYTD(companyId, todayYear)).map(d => ({ accountName: d.accountName, ytd: d.ytd }));
        } catch (e) {
          console.error("AISummaryBanner: owner draws unavailable:", e);
        }

        const agingByKind: Record<string, number> = {};
        for (const row of agingRes.data || []) {
          agingByKind[(row as any).kind] = (agingByKind[(row as any).kind] || 0) + (Number((row as any).amount) || 0);
        }

        const needsAttentionCount =
          (overdueInvoicesRes.count || 0) + (overdueBillsRes.count || 0) + (nextRemittance ? 1 : 0);

        const context = {
          cash_position: { total_liquid_cash: totalLiquidCash },
          profit_and_loss: { total_revenue: totalRevenue, total_expenses: totalExpenses, net_income: netIncome },
          projects: { active_count: activeProjectCount },
          next_remittance: nextRemittance,
          workforce: { active_workers: activeWorkers, field_payments_this_week: fieldPaymentsThisWeek },
          // Only present when this company actually has owner draw activity, so the AI is never told about draws that don't exist.
          ...(ownerDraws.length > 0 ? { owner_draws_ytd: { year: todayYear, by_account: ownerDraws } } : {}),
          receivables_payables: { receivable_total: agingByKind["receivable"] || 0, payable_total: agingByKind["payable"] || 0 },
          needs_attention_count: needsAttentionCount,
          // Explicit, named data gaps — the whole reason this is passed at
          // all rather than just the numbers: several figures above are
          // real but structurally incomplete right now (not wrong, just
          // partial), and the model has no way to know that from the raw
          // numbers alone.
          //
          // GL Phase 2 is now genuinely complete — all 7 entities posted
          // and verified this session (Expenses, Fund Transfer, Client
          // Invoices, Client Payments, Bills, Supplier Payments, Field
          // Payments). The profit_and_loss entry that lived here through
          // the mid-arc update is removed entirely, not reworded — Bills
          // and Field Payments (the last two things it was waiting on)
          // are posted, so there's nothing left to caveat about net
          // income. receivables_payables was already removed in the
          // prior round (never actually GL-posting-dependent — see that
          // round's own reasoning if this needs revisiting).
          //
          // projects.active_count is left exactly as it was — a real,
          // separate gap (BOQ/job-costing data entry, not GL posting)
          // that Phase 2 never touched and doesn't resolve it.
          data_caveats: [
            "projects.active_count is real, but budget and actual-cost figures for those projects are currently $0 across the board — BOQ items and job-costing data have not been entered for them yet. This is a data gap, not a claim that projects have no budget.",
          ],
        };

        const message =
          "Give a 2-3 sentence, plain-English summary of this construction company's current financial and operational position, written for the company director glancing at their dashboard. " +
          "Use specific real numbers from the data below where you have them. " +
          "Do not state or imply a confident conclusion about anything listed in data_caveats — if you mention one of those areas at all, say plainly that the data is incomplete rather than describing it as good, bad, on-track, or complete.";

        const result = await aiChat(message, context);
        const finalText = result && result.trim() ? result.trim() : FALLBACK_TEXT;

        if (!alive) return;
        setSummary(finalText);
        if (result && result.trim()) {
          try { sessionStorage.setItem(cacheKey, finalText); } catch { /* storage full/unavailable — fine to skip caching */ }
        }
      } catch (e: any) {
        console.error("AISummaryBanner failed to load:", e);
        if (!alive) return;
        setSummary(FALLBACK_TEXT);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  // Stops any in-progress speech when the summary text changes (a fresh
  // load overwriting cached/previous text shouldn't get talked over by
  // audio of the old text) and on unmount (navigating away). Deliberately
  // does NOT check `speaking` in the dependency array — this only needs to
  // run cancel() as a side effect when summary changes or the component
  // goes away, not re-run every time speaking itself toggles.
  useEffect(() => {
    return () => {
      if (speechSupported()) window.speechSynthesis.cancel();
    };
  }, [summary]);

  function toggleSpeech() {
    if (!speechSupported() || !summary) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    // Clear any stray queued utterance first — defensive, since only one
    // utterance should ever be active from this button, but a leftover
    // queued item from a fast double-click could otherwise play after this
    // one finishes.
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(stripMarkdown(summary));
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  }

  return (
    <div className="relative overflow-hidden rounded-2xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 via-white dark:via-[#0c1018] to-emerald-500/10 p-5">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center flex-shrink-0">
          <Sparkles size={16} className="text-cyan-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-1">
            <div className="text-[10px] font-bold uppercase tracking-widest text-cyan-600 dark:text-cyan-400">
              Magnus AI Summary
            </div>
            {!loading && summary && speechSupported() && (
              <button
                onClick={toggleSpeech}
                aria-label={speaking ? "Stop reading summary aloud" : "Read summary aloud"}
                title={speaking ? "Stop" : "Read aloud"}
                className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 transition-colors ${
                  speaking
                    ? "bg-cyan-500/20 text-cyan-500"
                    : "text-cyan-600/70 dark:text-cyan-400/70 hover:bg-cyan-500/10 hover:text-cyan-600 dark:hover:text-cyan-400"
                }`}
              >
                {speaking ? <Square size={10} className="fill-current" /> : <Volume2 size={12} />}
              </button>
            )}
          </div>
          {loading ? (
            <div className="h-4 w-3/4 rounded bg-cyan-500/10 animate-pulse" />
          ) : (
            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{renderBoldMarkdown(summary)}</p>
          )}
        </div>
      </div>
    </div>
  );
}
