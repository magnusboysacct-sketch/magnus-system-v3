﻿// src/pages/EstimatesPage.tsx — v2 Rebuild
import React, { useEffect, useState } from "react";
import { useCompanySettings } from "../hooks/useCompanySettings";
import { companyDisplayName } from "../lib/companyName";
import { showPrintPreview } from "../lib/printPreview";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useProjectContext } from "../context/ProjectContext";
import { magnusAI } from "../lib/magnusAI";
import EstimateAdvisorPanel from "../components/EstimateAdvisorPanel";
import SendToClientModal from "../components/SendToClientModal";
import type { DetailLevel } from "../components/SendToClientModal";
import { buildEstimateSnapshot } from "../lib/estimateSnapshot";
import { isSharedNow, formatJamaicaDateTime, shareViaLabel } from "../lib/portalShare";
import { SeenBadge } from "../components/PortalSeen";
import { useItemViews } from "../lib/useItemViews";
import type { ItemViews } from "../lib/portalSeen";
import {
  createClientInvoice, createInvoiceLineItems,
  createClientPayment, updateInvoiceAfterPayment, fetchInvoicePayments,
} from "../lib/finance";
import {
  PageHeader, Card, Badge, Btn, Input, Select, Field,
  Table, Th, Tr, Td, Empty, Modal, Alert, Textarea,
  Tabs, Progress, cn
} from "../components/ui";
import {
  Plus, Search, FileText, ArrowRight, RefreshCw,
  DollarSign, Edit2, Trash2, Copy, Send,
  CheckCircle2, XCircle, Clock, LayoutGrid, List, X, Bot, Sparkles, Loader, Printer
} from "lucide-react";

// --- Types --------------------------------------------------------------------

type EstimateHeader = {
  id: string;
  project_id: string;
  title: string;
  status: "draft" | "sent" | "approved" | "declined";
  version: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
  // pricing
  markup_overall?: number | null;
  markup_enabled?: boolean | null;      // off: no markup on this estimate (the client's own prices)
  markup_type?: "overall" | "category" | null;
  contingency_pct?: number | null;
  contingency_enabled?: boolean | null;  // off: no contingency on this estimate
  contingency_amount?: number | null;
  subtotal_cost?: number | null;
  subtotal_markup?: number | null;
  total_client_price?: number | null;
  print_format?: string | null;
  invoice_id?: string | null;
  // send-to-client state
  shared_at?: string | null;
  shared_via?: string | null;
  shared_by?: string | null;
  withdrawn_at?: string | null;
  shared_snapshot?: { detail_level?: DetailLevel } | null;
  // joined
  projects?: { name: string } | null;
};

type EstimateItem = {
  id: string;
  estimate_id: string;
  line_no: number;
  item_type: "labor" | "material" | "equipment" | "subcontractor" | "other";
  category: string | null;
  item: string;
  description: string | null;
  unit: string | null;
  qty: number;
  rate: number;
  amount: number;
};

type Tab = "all" | "draft" | "sent" | "approved" | "declined";
type ViewMode = "grid" | "list";

function Switch({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)}
      className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition ${on ? "bg-blue-600" : "bg-slate-300 dark:bg-white/[0.15]"}`}>
      <span className={`inline-block h-5 w-5 rounded-full bg-white shadow transition ${on ? "translate-x-5" : "translate-x-0.5"}`} />
    </button>
  );
}

const STATUS_COLOR: Record<string, any> = {
  draft: "slate", sent: "blue", approved: "green", declined: "red",
};

const STATUS_ICON: Record<string, React.ReactNode> = {
  draft:    <Clock size={12}/>,
  sent:     <Send size={12}/>,
  approved: <CheckCircle2 size={12}/>,
  declined: <XCircle size={12}/>,
};

const ITEM_TYPE_COLOR: Record<string, string> = {
  labor: "text-blue-400", material: "text-emerald-400",
  equipment: "text-amber-400", subcontractor: "text-violet-400", other: "text-slate-400",
};

function fmt(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency", currency: "JMD", maximumFractionDigits: 2
  }).format(n);
}

function fmtDate(d: string) {
  return new Date(d).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric"
  });
}

// Small "Sent to client" / "Not sent" marker driven by shared_at.
function ShareMarker({ estimate }: { estimate: EstimateHeader }) {
  const at = isSharedNow(estimate.shared_at, estimate.withdrawn_at);
  return at ? (
    <span
      title={`Sent to client via ${shareViaLabel(estimate.shared_via)} on ${formatJamaicaDateTime(at)}`}
      className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[9px] font-semibold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
    >
      Sent to client
    </span>
  ) : (
    <span
      title="Not shared with the client yet"
      className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[9px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500"
    >
      Not sent
    </span>
  );
}

// --- Estimate Card ------------------------------------------------------------

function EstimateCard({ estimate, total, onView, onDelete, onDuplicate, onUpdateStatus, onAdvisor, onSend, seenViews }: {
  estimate: EstimateHeader;
  total: number;
  onView: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
  onUpdateStatus: (status: EstimateHeader["status"]) => void;
  onAdvisor: () => void;
  onSend: () => void;
  seenViews: Record<string, ItemViews> | null;
}) {
  return (
    <Card className="group hover:border-slate-300 dark:hover:border-white/[0.13] transition-all cursor-pointer" onClick={onView}>
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
          <FileText size={15} className="text-blue-400"/>
        </div>
        <div className="flex items-center gap-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity"
          onClick={e => e.stopPropagation()}>
          <button onClick={onDuplicate}
            className="p-2.5 md:p-1.5 rounded-lg hover:bg-white/10 text-slate-600 hover:text-slate-300 transition-colors" title="Duplicate">
            <Copy size={11}/>
          </button>
          <button onClick={onDelete}
            className="p-2.5 md:p-1.5 rounded-lg hover:bg-red-500/15 text-slate-600 hover:text-red-400 transition-colors" title="Delete">
            <Trash2 size={11}/>
          </button>
          <button onClick={onAdvisor}
            className="p-2.5 md:p-1.5 rounded-lg hover:bg-purple-500/15 text-slate-600 hover:text-purple-400 transition-colors" title="AI Advisor">
            <Bot size={11}/>
          </button>
        </div>
      </div>

      <div className="mb-3">
        <div className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate mb-1">{estimate.title}</div>
        <div className="text-[10px] text-slate-600">
          {estimate.projects?.name || "No project"} · v{estimate.version}
        </div>
      </div>

      <div className="text-xl font-bold text-emerald-400 mb-3">{fmt(total)}</div>

      <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-white/[0.05]">
        <Badge color={STATUS_COLOR[estimate.status]} dot>{estimate.status}</Badge>
        <ShareMarker estimate={estimate} />
        <SeenBadge sharedAt={isSharedNow(estimate.shared_at, estimate.withdrawn_at)} viewsMap={seenViews} id={estimate.id} />
        <div className="text-[9px] text-slate-700">{fmtDate(estimate.updated_at)}</div>
      </div>

      {/* Status actions */}
      {estimate.status === "draft" && (
        <div className="mt-3 flex gap-1.5" onClick={e => e.stopPropagation()}>
          <button onClick={onSend}
            className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 text-[10px] text-blue-300 font-semibold transition-colors">
            <Send size={10}/> Send
          </button>
        </div>
      )}
      {estimate.status === "sent" && (
        <div className="mt-3 flex gap-1.5" onClick={e => e.stopPropagation()}>
          <button onClick={() => onUpdateStatus("approved")}
            className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-[10px] text-emerald-300 font-semibold transition-colors">
            <CheckCircle2 size={10}/> Approve
          </button>
          <button onClick={() => onUpdateStatus("declined")}
            className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-[10px] text-red-300 font-semibold transition-colors">
            <XCircle size={10}/> Decline
          </button>
        </div>
      )}
    </Card>
  );
}

// --- Detail Modal -------------------------------------------------------------

function EstimateDetailModal({ estimate, items, companyId, onUpdateStatus, onSend, onClose, seenViews }: {
  estimate: EstimateHeader;
  items: EstimateItem[];
  companyId: string | null;
  onUpdateStatus: (status: EstimateHeader["status"]) => void;
  onSend: (live: { markupOverall: number; contingencyPct: number }) => void;
  onClose: () => void;
  seenViews: Record<string, ItemViews> | null;
}) {
  const nav = useNavigate();
  const total = items.reduce((s, i) => s + (i.amount || 0), 0);
  const byType = items.reduce((acc: Record<string, number>, i) => {
    acc[i.item_type] = (acc[i.item_type] || 0) + (i.amount || 0);
    return acc;
  }, {});

  // --- Pricing: markup + contingency ------------------------------------
  const [markupType, setMarkupType] = useState<"overall" | "category">(estimate.markup_type || "overall");
  const [markupOverall, setMarkupOverall] = useState<number>(estimate.markup_overall ?? 25);
  const [markupOn, setMarkupOn] = useState<boolean>(estimate.markup_enabled !== false);
  const markupPct = markupOn ? markupOverall : 0;          // what is really added (0 when markup is switched off)
  const [contingencyPct, setContingencyPct] = useState<number>(estimate.contingency_pct ?? 5);
  const [contingencyOn, setContingencyOn] = useState<boolean>(estimate.contingency_enabled !== false);
  const contPct = contingencyOn ? contingencyPct : 0;       // what is really added (0 when contingency is switched off)
  const [savingMarkup, setSavingMarkup] = useState(false);

  // --- Payment tracking ---------------------------------------------------
  const [linkedInvoiceId, setLinkedInvoiceId] = useState<string | null>(estimate.invoice_id || null);
  const [creatingInvoice, setCreatingInvoice] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [savingPayment, setSavingPayment] = useState(false);
  const [invoicePayments, setInvoicePayments] = useState<any[]>([]);
  const [paymentForm, setPaymentForm] = useState({
    amount: "",
    payment_method: "cash",
    reference_number: "",
    payment_date: new Date().toISOString().slice(0, 10),
    notes: "",
  });

  useEffect(() => {
    async function loadDefaults() {
      if (!companyId || estimate.markup_overall != null) return;
      const { data: cs } = await supabase
        .from("company_settings")
        .select("estimate_markup_overall, estimate_contingency, estimate_markup_enabled, estimate_contingency_enabled")
        .eq("company_id", companyId)
        .maybeSingle();
      if (cs) {
        setMarkupOverall(cs.estimate_markup_overall ?? 25);
        setMarkupOn(cs.estimate_markup_enabled !== false);
        setContingencyOn(cs.estimate_contingency_enabled !== false);
        setContingencyPct(cs.estimate_contingency ?? 5);
      }
    }
    loadDefaults();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [estimate.id, companyId]);

  useEffect(() => {
    async function loadPayments() {
      if (!estimate.invoice_id) return;
      setLinkedInvoiceId(estimate.invoice_id);
      const payments = await fetchInvoicePayments(estimate.invoice_id);
      setInvoicePayments(payments || []);
    }
    loadPayments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [estimate.id, estimate.invoice_id]);

  const subtotalCost = items.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const markupAmount = subtotalCost * (markupPct / 100);
  const subtotalWithMarkup = subtotalCost + markupAmount;
  const contingencyAmount = subtotalWithMarkup * (contPct / 100);
  const totalClientPrice = subtotalWithMarkup + contingencyAmount;

  async function saveMarkup() {
    setSavingMarkup(true);
    await supabase.from("estimate_headers").update({
      markup_overall: markupOverall,
      markup_enabled: markupOn,
      markup_type: markupType,
      contingency_pct: contingencyPct,
      contingency_enabled: contingencyOn,
      contingency_amount: contingencyAmount,
      subtotal_cost: subtotalCost,
      subtotal_markup: markupAmount,
      total_client_price: totalClientPrice,
    }).eq("id", estimate.id);
    setSavingMarkup(false);
  }

  function handleGenerateContract() {
    const params = new URLSearchParams({
      estimate_id: estimate.id,
      project_id: estimate.project_id || "",
      amount: String(Math.round(totalClientPrice)),
      title: estimate.title,
    });
    nav(`/contracts?new=1&${params.toString()}`);
  }

  async function createInvoiceFromEstimate() {
    if (!companyId) return;
    setCreatingInvoice(true);
    try {
      const { data: project } = await supabase
        .from("projects").select("client_id").eq("id", estimate.project_id).maybeSingle();

      const invNumber = `INV-${new Date().getFullYear()}-${Date.now().toString().slice(-5)}`;
      const total = totalClientPrice || subtotalCost;

      const invoice = await createClientInvoice({
        company_id: companyId,
        project_id: estimate.project_id,
        client_id: project?.client_id || null,
        invoice_number: invNumber,
        invoice_date: new Date().toISOString().slice(0, 10),
        due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
        subtotal: subtotalCost,
        tax_rate: 0,
        tax_amount: 0,
        total_amount: total,
        amount_paid: 0,
        balance_due: total,
        status: "draft",
        notes: `Generated from estimate: ${estimate.title}`,
        terms: "Net 30",
      });

      if (items.length > 0) {
        await createInvoiceLineItems(items.map((item, i) => ({
          invoice_id: invoice.id,
          company_id: companyId,
          line_number: i + 1,
          description: item.item || item.description || "Item",
          quantity: Number(item.qty) || 1,
          unit: item.unit || "",
          rate: Number(item.rate) || 0,
          amount: Number(item.amount) || 0,
        })));
      }

      await supabase.from("estimate_headers").update({ invoice_id: invoice.id }).eq("id", estimate.id);

      setLinkedInvoiceId(invoice.id);
      setInvoicePayments([]);
      alert(`Invoice ${invNumber} created successfully! View it in Accounts Receivable.`);
    } catch (e: any) {
      alert("Failed to create invoice: " + e.message);
    } finally {
      setCreatingInvoice(false);
    }
  }

  async function handleRecordPayment() {
    if (!linkedInvoiceId || !companyId) return;
    const amount = Number(paymentForm.amount);
    if (!amount || amount <= 0) { alert("Enter a valid amount."); return; }
    setSavingPayment(true);
    try {
      await createClientPayment({
        company_id: companyId,
        invoice_id: linkedInvoiceId,
        payment_number: `PAY-${Date.now()}`,
        payment_date: paymentForm.payment_date,
        amount,
        payment_method: paymentForm.payment_method as any,
        reference_number: paymentForm.reference_number || null,
        notes: paymentForm.notes || null,
      });

      await updateInvoiceAfterPayment(linkedInvoiceId);

      const payments = await fetchInvoicePayments(linkedInvoiceId);
      setInvoicePayments(payments || []);
      setShowPaymentModal(false);
      setPaymentForm(f => ({ ...f, amount: "", reference_number: "", notes: "" }));
    } catch (e: any) {
      alert("Failed to record payment: " + e.message);
    } finally {
      setSavingPayment(false);
    }
  }

  // Builds the proposal's HTML (all the data lookups happen here). The document itself is unchanged.
  async function buildProposalHtml(): Promise<string> {
    const fmtJMD = (n: number) => new Intl.NumberFormat("en-US",{style:"currency",currency:"JMD",minimumFractionDigits:2}).format(n);

    const { data: { user } } = await supabase.auth.getUser();
    let cs: any = null;
    let proj: any = null;
    let client: any = null;
    if (user) {
      const { data: profile } = await supabase.from("user_profiles").select("company_id").eq("id", user.id).maybeSingle();
      if (profile?.company_id) {
        const { data } = await supabase.from("company_settings")
          .select("company_name, address_line1, address_line2, parish, phone, email, logo_url, estimate_validity_days, estimate_print_format")
          .eq("company_id", profile.company_id).maybeSingle();
        cs = data;
      }
    }
    const { data: projData } = await supabase.from("projects")
      .select("name, site_address, client_id").eq("id", estimate.project_id).maybeSingle();
    proj = projData;
    if (proj?.client_id) {
      const { data: c } = await supabase.from("clients").select("name, address, phone, email").eq("id", proj.client_id).maybeSingle();
      client = c;
    }

    const markup = markupAmount;
    const subtotal = subtotalWithMarkup;
    const contingency = contingencyAmount;
    const grandTotal = totalClientPrice;
    const validUntil = new Date(new Date(estimate.created_at).getTime() + (cs?.estimate_validity_days || 30) * 24 * 60 * 60 * 1000);
    const estNumber = `EST-${new Date(estimate.created_at).getFullYear()}-${estimate.id.slice(-6).toUpperCase()}`;
    const printFormat = estimate.print_format || cs?.estimate_print_format || "summary";

    const html = `<!DOCTYPE html><html><head>
    <title>${estimate.title} — Cost Proposal</title>
    <style>
      * { margin:0; padding:0; box-sizing:border-box; }
      body { font-family: 'Segoe UI', Arial, sans-serif; color:#1e293b; background:white; padding:40px; font-size:13px; }
      .header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:32px; padding-bottom:20px; border-bottom:3px solid #1e3a5f; }
      .company-logo { height:60px; width:auto; object-fit:contain; margin-bottom:8px; }
      .company-name { font-size:22px; font-weight:900; color:#1e3a5f; }
      .company-sub { font-size:11px; color:#64748b; margin-top:2px; }
      .doc-title { font-size:28px; font-weight:900; color:#1e3a5f; text-align:right; }
      .doc-meta { font-size:11px; color:#64748b; text-align:right; margin-top:4px; line-height:1.8; }
      .info-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:28px; padding:16px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0; }
      .info-label { font-size:9px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#94a3b8; margin-bottom:6px; }
      .info-value { font-size:14px; font-weight:700; color:#1e293b; }
      .info-sub { font-size:11px; color:#64748b; margin-top:2px; line-height:1.6; }
      table { width:100%; border-collapse:collapse; margin-bottom:24px; }
      th { background:#1e3a5f; color:white; padding:10px 12px; text-align:left; font-size:11px; text-transform:uppercase; letter-spacing:0.5px; }
      th.right { text-align:right; }
      td { padding:10px 12px; border-bottom:1px solid #e2e8f0; font-size:12px; }
      td.right { text-align:right; }
      tr:nth-child(even) td { background:#f8fafc; }
      .totals { display:flex; justify-content:flex-end; margin-bottom:32px; }
      .totals-box { width:320px; }
      .total-row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #e2e8f0; font-size:12px; }
      .total-final { display:flex; justify-content:space-between; padding:14px 16px; background:#1e3a5f; border-radius:8px; margin-top:8px; }
      .total-final span { color:white; font-weight:700; font-size:14px; }
      .contingency-row { display:flex; justify-content:space-between; padding:8px 12px; background:#fffbeb; border:1px solid #fcd34d; border-radius:6px; margin:4px 0; font-size:12px; }
      .terms { margin-bottom:24px; padding:16px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0; }
      .terms-title { font-size:9px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#94a3b8; margin-bottom:8px; }
      .terms-text { font-size:10px; color:#64748b; line-height:1.8; }
      .sigs { display:grid; grid-template-columns:1fr 1fr; gap:40px; margin-bottom:32px; }
      .sig-line { border-top:2px solid #1e3a5f; padding-top:8px; }
      .sig-name { font-size:11px; font-weight:600; color:#1e293b; }
      .sig-sub { font-size:10px; color:#94a3b8; margin-top:4px; }
      .footer { text-align:center; padding-top:16px; border-top:1px solid #e2e8f0; font-size:10px; color:#94a3b8; line-height:1.8; }
      .badge { display:inline-block; padding:3px 10px; background:#dcfce7; color:#166534; font-size:10px; font-weight:700; border-radius:20px; text-transform:uppercase; }
      @media print { body { padding:20px; } }
    </style>
    </head><body>

    <div class="header">
      <div>
        ${cs?.logo_url ? `<img src="${cs.logo_url}" class="company-logo"/>` : `<div class="company-name">${companyDisplayName(cs?.company_name)}</div>`}
        <div class="company-sub">${cs?.address_line1 || ""}${cs?.parish ? ", " + cs.parish : ""}</div>
        <div class="company-sub">${cs?.phone || ""}${cs?.email ? " · " + cs.email : ""}</div>
      </div>
      <div>
        <div class="doc-title">COST PROPOSAL</div>
        <div class="doc-meta">
          Estimate #: ${estNumber}<br/>
          Date: ${new Date(estimate.created_at).toLocaleDateString("en-JM", {day:"numeric",month:"long",year:"numeric"})}<br/>
          Valid Until: ${validUntil.toLocaleDateString("en-JM", {day:"numeric",month:"long",year:"numeric"})}<br/>
          Version ${estimate.version || 1} &nbsp; <span class="badge">${estimate.status}</span>
        </div>
      </div>
    </div>

    <div class="info-grid">
      <div>
        <div class="info-label">Prepared For</div>
        <div class="info-value">${client?.name || "—"}</div>
        <div class="info-sub">${client?.address || ""}${client?.phone ? "<br/>" + client.phone : ""}${client?.email ? "<br/>" + client.email : ""}</div>
      </div>
      <div>
        <div class="info-label">Project</div>
        <div class="info-value">${proj?.name || estimate.title}</div>
        <div class="info-sub">${proj?.site_address || ""}${estimate.notes ? "<br/>" + estimate.notes : ""}</div>
      </div>
    </div>

    ${printFormat === "summary" ? `
    <table>
      <thead><tr>
        <th>#</th><th>Description</th><th class="right">Amount (JMD)</th>
      </tr></thead>
      <tbody>
        ${Object.entries(
          items.reduce((groups: Record<string, number>, item: any) => {
            const cat = item.category || "General Works";
            groups[cat] = (groups[cat] || 0) + (Number(item.amount) || 0);
            return groups;
          }, {})
        ).map(([cat, amt], i) => {
          const clientAmt = (amt as number) * (1 + markupPct / 100);
          return `<tr><td>${i+1}</td><td><strong>${cat}</strong></td><td class="right"><strong>JMD ${clientAmt.toLocaleString(undefined,{maximumFractionDigits:0})}</strong></td></tr>`;
        }).join("")}
      </tbody>
    </table>
    ` : `
    <table>
      <thead><tr>
        <th>#</th><th>Item</th><th>Type</th><th>Unit</th>
        ${printFormat === "breakdown" ? "<th class='right'>Qty</th><th class='right'>Rate (JMD)</th>" : "<th class='right'>Qty</th>"}
        <th class="right">Amount (JMD)</th>
      </tr></thead>
      <tbody>
        ${items.map((item: any, i: number) => {
          const clientRate = (Number(item.rate)||0) * (1 + markupPct/100);
          const clientAmt = (Number(item.amount)||0) * (1 + markupPct/100);
          return `<tr>
            <td>${i+1}</td>
            <td><strong>${item.item||""}</strong>${item.description ? "<br/><span style='color:#64748b;font-size:10px'>" + item.description + "</span>" : ""}</td>
            <td>${item.item_type||""}</td>
            <td>${item.unit||""}</td>
            ${printFormat === "breakdown" ? `<td class="right">${Number(item.qty||0).toLocaleString()}</td><td class="right">${clientRate.toLocaleString(undefined,{maximumFractionDigits:0})}</td>` : `<td class="right">${Number(item.qty||0).toLocaleString()}</td>`}
            <td class="right"><strong>JMD ${clientAmt.toLocaleString(undefined,{maximumFractionDigits:0})}</strong></td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>
    `}

    <div class="totals">
      <div class="totals-box">
        <div class="total-row"><span>Subtotal</span><span>JMD ${subtotal.toLocaleString(undefined,{maximumFractionDigits:0})}</span></div>
        ${contingency > 0 ? `<div class="contingency-row"><span>Contingency (${contingencyPct}%)</span><span>JMD ${contingency.toLocaleString(undefined,{maximumFractionDigits:0})}</span></div>` : ""}
        <div class="total-final"><span>TOTAL CONTRACT VALUE</span><span>JMD ${grandTotal.toLocaleString(undefined,{maximumFractionDigits:0})}</span></div>
      </div>
    </div>

    <div class="terms">
      <div class="terms-title">Terms & Conditions</div>
      <div class="terms-text">
        1. This proposal is valid for ${cs?.estimate_validity_days || 30} days from date of issue.<br/>
        2. Prices are in Jamaican Dollars (JMD) and subject to change after validity period.<br/>
        3. A deposit is required before commencement of work.<br/>
        4. Progress payments as per agreed schedule.<br/>
        5. All materials remain property of ${companyDisplayName(cs?.company_name)} until full payment is received.<br/>
        6. Contingency allowance covers unforeseen site conditions and price variations.
      </div>
    </div>

    <div class="sigs">
      <div class="sig-line">
        <div class="sig-name">Client Acceptance</div>
        <div class="sig-sub">Signature &amp; Date</div>
      </div>
      <div class="sig-line">
        <div class="sig-name">Authorized By — ${companyDisplayName(cs?.company_name)}</div>
        <div class="sig-sub">Signature &amp; Date</div>
      </div>
    </div>

    <div class="footer">
      ${companyDisplayName(cs?.company_name)} · ${cs?.phone || ""} · ${cs?.email || ""}<br/>
      This proposal is valid for ${cs?.estimate_validity_days || 30} days from date of issue.
    </div>

    </body></html>`;

    return html;
  }

  // Print: prepare the document, then show it in the in-app print preview (Print is pressed there, so nothing can be blocked by the awaits above).
  // Any failure is shown, never swallowed.
  const [printing, setPrinting] = useState(false);
  async function printProposal() {
    if (printing) return;
    setPrinting(true);
    try {
      showPrintPreview(await buildProposalHtml());
    } catch (e) {
      console.error("Print proposal failed:", e);
      alert("Could not print the proposal: " + (e instanceof Error && e.message ? e.message : "please try again."));
    } finally {
      setPrinting(false);
    }
  }
  return (
    <>
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl border border-slate-200 dark:border-white/10 shadow-2xl w-full sm:max-w-3xl flex flex-col"
        style={{ maxHeight: "95dvh" }}>

        {/* Mobile drag handle */}
        <div className="flex-shrink-0 flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-slate-300 dark:bg-slate-600"/>
        </div>

        {/* Header — fixed, never scrolls */}
        <div className="flex-shrink-0 flex items-start justify-between px-5 py-4 border-b border-slate-200 dark:border-white/[0.07]">
          <div>
            <h2 className="text-base font-bold text-slate-800 dark:text-slate-100">{estimate.title}</h2>
            <div className="flex items-center gap-2 mt-1">
              <Badge color={STATUS_COLOR[estimate.status]} dot>{estimate.status}</Badge>
              <span className="text-xs text-slate-500">v{estimate.version} · {estimate.projects?.name || "No project"}</span>
              <ShareMarker estimate={estimate} />
              <SeenBadge sharedAt={isSharedNow(estimate.shared_at, estimate.withdrawn_at)} viewsMap={seenViews} id={estimate.id} />
            </div>
          </div>
          <button onClick={onClose}
            className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/[0.06] text-slate-400 flex-shrink-0">
            <X size={18}/>
          </button>
        </div>

        {/* Body — scrollable */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {/* Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Object.entries(byType).map(([type, amt]) => (
            <div key={type} className="rounded-lg bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/[0.06] p-2.5">
              <div className={cn("text-[9px] font-bold uppercase tracking-widest mb-1", ITEM_TYPE_COLOR[type] || "text-slate-600")}>{type}</div>
              <div className="text-sm font-bold text-slate-800 dark:text-slate-200">{fmt(amt)}</div>
            </div>
          ))}
        </div>

        {/* Pricing Panel */}
        <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] overflow-hidden">
          <div className="px-4 py-3 bg-slate-50 dark:bg-white/[0.03] border-b border-slate-200 dark:border-white/[0.06] flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Pricing</span>
            <span className="text-[9px] text-slate-500 bg-slate-100 dark:bg-white/[0.06] px-2 py-0.5 rounded-full">Internal — client never sees markup</span>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">BOQ Cost</span>
              <span className="font-semibold text-slate-700 dark:text-slate-200">{fmt(subtotalCost)}</span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <span className="text-sm text-slate-600 dark:text-slate-400">Add markup</span>
                {!markupOn && <div className="text-[10px] text-slate-500">Off: the client's own prices, nothing added</div>}
              </div>
              <Switch on={markupOn} onChange={setMarkupOn} label="Add markup" />
            </div>
            <div className={`flex items-center justify-between gap-3 ${markupOn ? "" : "opacity-40 pointer-events-none"}`}>
              <span className="text-sm text-slate-600 dark:text-slate-400">Markup</span>
              <div className="flex items-center gap-2">
                <input type="number" min="0" max="200"
                  value={markupOverall}
                  onChange={e => setMarkupOverall(Number(e.target.value))}
                  className="w-16 px-2 py-1 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm text-right font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"/>
                <span className="text-sm text-slate-400">%</span>
                <span className="text-sm font-semibold text-emerald-500 dark:text-emerald-400">
                  = {fmt(markupAmount)}
                </span>
              </div>
            </div>
            <div className="border-t border-slate-100 dark:border-white/[0.06] pt-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600 dark:text-slate-400">{markupOn ? "Subtotal (with markup)" : "Subtotal (no markup)"}</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200">{fmt(subtotalWithMarkup)}</span>
              </div>
            </div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <span className="text-sm text-slate-600 dark:text-slate-400">Add contingency</span>
                {!contingencyOn && <div className="text-[10px] text-slate-500">Off: no contingency added</div>}
              </div>
              <Switch on={contingencyOn} onChange={setContingencyOn} label="Add contingency" />
            </div>
            <div className={`flex items-center justify-between gap-3 bg-amber-50 dark:bg-amber-500/10 rounded-lg p-3 ${contingencyOn ? "" : "opacity-40 pointer-events-none"}`}>
              <div>
                <span className="text-sm font-semibold text-amber-700 dark:text-amber-400">Contingency</span>
                <span className="text-[10px] text-amber-600 dark:text-amber-500 ml-2">shown to client</span>
              </div>
              <div className="flex items-center gap-2">
                <input type="number" min="0" max="50"
                  value={contingencyPct}
                  onChange={e => setContingencyPct(Number(e.target.value))}
                  className="w-16 px-2 py-1 rounded-lg border border-amber-200 dark:border-amber-500/30 bg-white dark:bg-white/[0.04] text-sm text-right font-semibold text-amber-700 dark:text-amber-400 focus:outline-none"/>
                <span className="text-sm text-amber-600 dark:text-amber-500">%</span>
                <span className="text-sm font-semibold text-amber-700 dark:text-amber-400">
                  = {fmt(contingencyAmount)}
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between bg-blue-600 rounded-xl px-4 py-3">
              <span className="text-sm font-bold text-white">TOTAL TO CLIENT</span>
              <span className="text-lg font-black text-white">{fmt(totalClientPrice)}</span>
            </div>
            <button onClick={saveMarkup} disabled={savingMarkup}
              className="w-full py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] text-xs font-semibold text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/[0.04] transition-colors">
              {savingMarkup ? "Saving..." : "Save markup settings"}
            </button>
          </div>
        </div>

        {/* Payment Tracking */}
        {estimate.status === "approved" && (
          <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] overflow-hidden">
            <div className="px-4 py-3 bg-slate-50 dark:bg-white/[0.03] border-b border-slate-200 dark:border-white/[0.06] flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Payment Tracking</span>
              {!linkedInvoiceId ? (
                <button onClick={createInvoiceFromEstimate} disabled={creatingInvoice}
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white transition-colors">
                  {creatingInvoice ? "Creating..." : "Create Invoice"}
                </button>
              ) : (
                <button onClick={() => setShowPaymentModal(true)}
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors">
                  + Record Payment
                </button>
              )}
            </div>

            {!linkedInvoiceId ? (
              <div className="px-4 py-6 text-center">
                <div className="text-sm font-semibold text-slate-600 dark:text-slate-300 mb-1">No invoice yet</div>
                <div className="text-xs text-slate-400">Create an invoice from this estimate to start tracking payments.</div>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {(() => {
                  const invTotal = totalClientPrice || subtotalCost;
                  const paid = invoicePayments.reduce((s, p) => s + Number(p.amount), 0);
                  const outstanding = invTotal - paid;
                  const pct = invTotal > 0 ? (paid / invTotal) * 100 : 0;
                  return (
                    <>
                      <div className="w-full bg-slate-100 dark:bg-white/[0.06] rounded-full h-2.5">
                        <div className="bg-emerald-500 h-2.5 rounded-full transition-all"
                          style={{ width: `${Math.min(100, pct)}%` }}/>
                      </div>
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="p-2 rounded-lg bg-slate-50 dark:bg-white/[0.03]">
                          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Total</div>
                          <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                            {fmt(invTotal)}
                          </div>
                        </div>
                        <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-500/10">
                          <div className="text-[10px] text-emerald-600 dark:text-emerald-500 uppercase tracking-wider">Paid</div>
                          <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                            {fmt(paid)}
                          </div>
                        </div>
                        <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-500/10">
                          <div className="text-[10px] text-amber-600 dark:text-amber-500 uppercase tracking-wider">Outstanding</div>
                          <div className="text-sm font-bold text-amber-600 dark:text-amber-400">
                            {fmt(Math.max(0, outstanding))}
                          </div>
                        </div>
                      </div>
                      {invoicePayments.length > 0 && (
                        <div className="border-t border-slate-100 dark:border-white/[0.06] pt-3 space-y-2">
                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Payment History</div>
                          {invoicePayments.map(p => (
                            <div key={p.id} className="flex items-center justify-between text-xs">
                              <div>
                                <span className="font-semibold text-slate-700 dark:text-slate-200">
                                  {fmt(Number(p.amount))}
                                </span>
                                <span className="text-slate-400 ml-2">{p.payment_date}</span>
                                <span className="text-slate-400 ml-2 capitalize">{p.payment_method}</span>
                                {p.reference_number && <span className="text-slate-400 ml-2">· {p.reference_number}</span>}
                              </div>
                              <span className="text-emerald-500 font-bold">Received</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
          </div>
        )}

        {/* Items table */}
        <div className="rounded-xl border border-slate-200 dark:border-white/[0.07] overflow-hidden max-h-80 overflow-y-auto">
          <Table>
            <thead>
              <tr>
                <Th>#</Th>
                <Th>Item</Th>
                <Th>Type</Th>
                <Th>Unit</Th>
                <Th right>Qty</Th>
                <Th right>Rate</Th>
                <Th right>Amount</Th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 ? (
                <tr><Td colSpan={7} className="text-center py-6 text-slate-600">No items</Td></tr>
              ) : items.map(item => (
                <Tr key={item.id}>
                  <Td muted className="font-mono text-[10px]">{item.line_no}</Td>
                  <Td>
                    <div className="font-medium text-slate-800 dark:text-slate-200 text-xs">{item.item}</div>
                    {item.description && <div className="text-[10px] text-slate-600">{item.description}</div>}
                  </Td>
                  <Td>
                    <span className={cn("text-[10px] font-semibold capitalize", ITEM_TYPE_COLOR[item.item_type] || "text-slate-500")}>
                      {item.item_type}
                    </span>
                  </Td>
                  <Td muted>{item.unit || "—"}</Td>
                  <Td right muted>{item.qty}</Td>
                  <Td right muted>{fmt(item.rate)}</Td>
                  <Td right><span className="font-semibold text-slate-800 dark:text-slate-200">{fmt(item.amount)}</span></Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        </div>

        {/* Total */}
        <div className="flex items-center justify-between px-4 py-3 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/[0.06]">
          <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Total Estimate</span>
          <span className="text-xl font-bold text-emerald-400">{fmt(total)}</span>
        </div>

        {estimate.notes && (
          <div className="rounded-lg bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/[0.06] px-3 py-2.5">
            <div className="text-[9px] font-bold uppercase tracking-widest text-slate-600 mb-1">Notes</div>
            <div className="text-xs text-slate-500 dark:text-slate-400">{estimate.notes}</div>
          </div>
        )}
        </div>

        {/* Footer — fixed, always visible */}
        <div className="flex-shrink-0 flex flex-wrap items-center gap-2 px-5 py-4 border-t border-slate-200 dark:border-white/[0.07] bg-white dark:bg-slate-900">
          {estimate.status === "draft" && (
            <button onClick={() => onSend({ markupOverall: markupPct, contingencyPct: contPct })}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold transition">
              <Send size={14}/> Send to Client
            </button>
          )}
          {(estimate.status === "sent" || estimate.status === "approved") && (
            <button onClick={() => onSend({ markupOverall: markupPct, contingencyPct: contPct })}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-blue-500/30 bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-300 text-sm font-semibold transition">
              <Send size={14}/> {isSharedNow(estimate.shared_at, estimate.withdrawn_at) ? "Sent to Client · Resend" : "Send to Client"}
            </button>
          )}
          {estimate.status === "sent" && (
            <>
              <button onClick={() => onUpdateStatus("approved")}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition">
                <CheckCircle2 size={14}/> Approve
              </button>
              <button onClick={() => onUpdateStatus("declined")}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 text-sm font-semibold transition">
                <XCircle size={14}/> Decline
              </button>
            </>
          )}
          {estimate.status === "approved" && (
            <button onClick={handleGenerateContract}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold transition">
              <FileText size={14}/> Generate Contract
            </button>
          )}
          <div className="flex-1"/>
          <button onClick={printProposal} disabled={printing}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition disabled:opacity-60 disabled:cursor-wait">
            <Printer size={14}/> {printing ? "Preparing…" : "Print"}
          </button>
          <button onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/[0.08] text-sm text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/[0.05] transition">
            Close
          </button>
        </div>
      </div>
    </div>

    {/* Record Payment Modal */}
    {showPaymentModal && (
      <div className="fixed inset-0 bg-black/70 flex items-end sm:items-center justify-center z-[60] p-0 sm:p-4">
        <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl w-full sm:max-w-md flex flex-col"
          style={{ maxHeight: "90dvh" }}>
          {/* Header */}
          <div className="flex-shrink-0 flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/[0.07]">
            <div>
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">Record Payment</h3>
              <p className="text-xs text-slate-400 mt-0.5">{estimate.title}</p>
            </div>
            <button onClick={() => setShowPaymentModal(false)}
              className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/[0.06] text-slate-400">
              <X size={16}/>
            </button>
          </div>
          {/* Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">Quick Select</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Deposit 30%", pct: 0.30 },
                  { label: "Progress 40%", pct: 0.40 },
                  { label: "Final 30%", pct: 0.30 },
                ].map(({ label, pct }) => {
                  const invTotal = totalClientPrice || subtotalCost;
                  const amt = Math.round(invTotal * pct);
                  return (
                    <button key={label} type="button"
                      onClick={() => setPaymentForm(f => ({ ...f, amount: String(amt) }))}
                      className="flex flex-col items-center p-2.5 rounded-xl border-2 border-slate-200 dark:border-white/[0.1] hover:border-blue-400 dark:hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-500/10 transition-all text-center">
                      <span className="text-[10px] text-slate-400 font-medium">{label}</span>
                      <span className="text-sm font-bold text-slate-700 dark:text-slate-200 mt-0.5">
                        {fmt(amt)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                Amount (JMD) <span className="text-red-400">*</span>
              </label>
              <input type="number" min="0"
                value={paymentForm.amount}
                onChange={e => setPaymentForm(f => ({ ...f, amount: e.target.value }))}
                placeholder="0.00"
                className="w-full px-3 py-2.5 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Payment Method</label>
              <div className="grid grid-cols-3 gap-2">
                {["cash", "check", "wire", "credit_card", "ach", "other"].map(m => (
                  <button key={m} type="button"
                    onClick={() => setPaymentForm(f => ({ ...f, payment_method: m }))}
                    className={cn("py-2 rounded-lg text-xs font-semibold capitalize border-2 transition-colors",
                      paymentForm.payment_method === m
                        ? "border-blue-500 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400"
                        : "border-slate-200 dark:border-white/[0.1] text-slate-500 dark:text-slate-400 hover:border-slate-300")}>
                    {m.replace("_", " ")}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Payment Date</label>
                <input type="date"
                  value={paymentForm.payment_date}
                  onChange={e => setPaymentForm(f => ({ ...f, payment_date: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Reference #</label>
                <input type="text"
                  value={paymentForm.reference_number}
                  onChange={e => setPaymentForm(f => ({ ...f, reference_number: e.target.value }))}
                  placeholder="Cheque # / Transfer ref"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Notes</label>
              <textarea
                value={paymentForm.notes}
                onChange={e => setPaymentForm(f => ({ ...f, notes: e.target.value }))}
                rows={2}
                placeholder="Optional notes..."
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-white/[0.04] text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30 resize-none"/>
            </div>
          </div>
          {/* Footer */}
          <div className="flex-shrink-0 flex gap-3 px-5 py-4 border-t border-slate-200 dark:border-white/[0.07]">
            <button onClick={() => setShowPaymentModal(false)}
              className="flex-1 py-3 rounded-xl border border-slate-200 dark:border-white/[0.1] text-sm text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-white/[0.05] transition-colors">
              Cancel
            </button>
            <button onClick={handleRecordPayment} disabled={savingPayment || !paymentForm.amount}
              className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-semibold transition-colors">
              {savingPayment ? "Recording..." : "Record Payment"}
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
}

// --- Main Page ----------------------------------------------------------------

export default function EstimatesPage() {
  const { projects, currentProject } = useProjectContext();
  const nav = useNavigate();
  const { settings: companySettings } = useCompanySettings();
  const [estimates, setEstimates] = useState<EstimateHeader[]>([]);
  const [itemsByEstimate, setItemsByEstimate] = useState<Record<string, EstimateItem[]>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<Tab>("all");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [projectFilter, setProjectFilter] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [viewingEstimate, setViewingEstimate] = useState<EstimateHeader | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState<string | null>(null);
  const [advisorEstimate, setAdvisorEstimate] = useState<EstimateHeader | null>(null);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [sendTarget, setSendTarget] = useState<{
    estimateId: string;
    client: any;
    projectName: string;
    markupOverall: number;
    contingencyPct: number;
  } | null>(null);
  const [form, setForm] = useState({ title: "", project_id: currentProject?.id || "", notes: "", status: "draft" });
  // "New estimate" starts with the project selected NOW (the form above was set when the page opened)
  function openNewEstimate() { setForm((f) => ({ ...f, project_id: currentProject?.id || "" })); setShowNew(true); }

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return;
      supabase.from("user_profiles").select("company_id").eq("id", user.id).maybeSingle()
        .then(({ data }) => { if (data?.company_id) setCompanyId(data.company_id); });
    });
  }, []);

  useEffect(() => { if (companyId) loadEstimates(); }, [companyId]);

  // "Opened by client" data for the shared estimates, in one batched query.
  const estimateViews = useItemViews(
    "estimate",
    estimates.filter(e => isSharedNow(e.shared_at, e.withdrawn_at)).map(e => e.id)
  );

  async function loadEstimates() {
    setLoading(true);
    try {
      const { data, error: e } = await supabase
        .from("estimate_headers")
        .select("*, projects(name)")
        
        .order("updated_at", { ascending: false });
      if (e) throw e;
      const hdrs = data || [];
      setEstimates(hdrs);

      // Load items for all estimates
      if (hdrs.length > 0) {
        const ids = hdrs.map((h: any) => h.id);
        const { data: items } = await supabase
          .from("estimate_items")
          .select("*")
          .in("estimate_id", ids)
          .order("line_no", { ascending: true });
        const map: Record<string, EstimateItem[]> = {};
        (items || []).forEach((item: EstimateItem) => {
          if (!map[item.estimate_id]) map[item.estimate_id] = [];
          map[item.estimate_id].push(item);
        });
        setItemsByEstimate(map);
      }
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  }

  async function createEstimate() {
    if (!form.project_id) { setError("Please select a project."); return; }
    if (!form.title.trim()) { setError("Please enter an estimate title."); return; }
    setSaving(true); setError(null);
    try {
      const { error: e } = await supabase.from("estimate_headers").insert({
        project_id: form.project_id,
        title: form.title.trim(),
        status: form.status,
        version: 1,
        notes: form.notes.trim() || null,
        company_id: companyId,
      });
      if (e) throw e;
      await loadEstimates();
      setShowNew(false);
      setForm({ title: "", project_id: currentProject?.id || "", notes: "", status: "draft" });
    } catch (e: any) { setError(e.message); }
    finally { setSaving(false); }
  }

  async function deleteEstimate(id: string) {
    try {
      await supabase.from("estimate_items").delete().eq("estimate_id", id);
      await supabase.from("estimate_headers").delete().eq("id", id);
      setEstimates(prev => prev.filter(e => e.id !== id));
    } catch (e: any) { setError(e.message); }
  }

  async function duplicateEstimate(estimate: EstimateHeader) {
    try {
      const { data: newHdr, error: e } = await supabase.from("estimate_headers").insert({
        company_id: companyId,
        project_id: estimate.project_id,
        title: estimate.title + " (Copy)",
        status: "draft",
        version: estimate.version + 1,
        notes: estimate.notes,
      }).select().maybeSingle();
      if (e) throw e;
      if (newHdr) {
        const srcItems = itemsByEstimate[estimate.id] || [];
        if (srcItems.length > 0) {
          await supabase.from("estimate_items").insert(
            srcItems.map(i => ({ ...i, id: undefined, estimate_id: newHdr.id, created_at: undefined, updated_at: undefined }))
          );
        }
        await loadEstimates();
      }
    } catch (e: any) { setError(e.message); }
  }

  async function updateStatus(id: string, status: EstimateHeader["status"]) {
    await supabase.from("estimate_headers").update({ status }).eq("id", id);
    setEstimates(prev => prev.map(e => e.id === id ? { ...e, status } : e));
    setViewingEstimate(prev => prev && prev.id === id ? { ...prev, status } : prev);
  }

  // -- Send to Client (estimate) ------------------------------------------
  // The client is resolved through the estimate's project (projects.client_id).
  // live = the detail modal's current markup/contingency, so what is sent equals
  // what Print would show; from the card it falls back to the saved header values.
  async function openSend(est: EstimateHeader, live?: { markupOverall: number; contingencyPct: number }) {
    try {
      const { data: proj, error: pe } = await supabase
        .from("projects").select("name, client_id").eq("id", est.project_id).maybeSingle();
      if (pe) throw new Error(pe.message);
      if (!proj?.client_id) {
        alert("This estimate's project has no client assigned. Assign a client to the project first.");
        return;
      }
      const { data: cl, error: ce } = await supabase
        .from("clients")
        .select("id, name, contact_name, phone, email, portal_enabled, portal_token")
        .eq("id", proj.client_id)
        .maybeSingle();
      if (ce || !cl) throw new Error(ce?.message || "Client not found.");
      setSendTarget({
        estimateId: est.id,
        client: cl,
        projectName: proj.name || est.projects?.name || "",
        markupOverall: live?.markupOverall ?? (est.markup_enabled === false ? 0 : est.markup_overall ?? 25),
        contingencyPct: live?.contingencyPct ?? (est.contingency_enabled === false ? 0 : est.contingency_pct ?? 5),
      });
    } catch (e: any) {
      alert("Could not open Send to Client: " + (e?.message || "unknown error"));
    }
  }

  // Runs at the moment of sending (see SendToClientModal.resolveSnapshot). Throws on
  // failure so the modal shows the message and sends nothing.
  async function buildSendSnapshot(level: DetailLevel) {
    if (!sendTarget) throw new Error("Nothing to send.");
    const est = estimates.find(x => x.id === sendTarget.estimateId);
    if (!est) throw new Error("Estimate not found.");
    const items = itemsByEstimate[est.id] || [];
    if (items.length === 0) throw new Error("This estimate has no line items to send.");
    let cs: any = null;
    if (companyId) {
      const { data } = await supabase.from("company_settings")
        .select("company_name, phone, email, address_line1, parish, logo_url, estimate_validity_days")
        .eq("company_id", companyId).maybeSingle();
      cs = data;
    }
    return buildEstimateSnapshot(level, {
      title: est.title,
      version: est.version,
      createdAt: est.created_at,
      items,
      markupOverall: sendTarget.markupOverall,
      contingencyPct: sendTarget.contingencyPct,
      projectName: sendTarget.projectName || null,
      clientName: sendTarget.client?.name || null,
      company: cs,
    });
  }

  // After a send/withdraw: pull the new share state (and status) into the list
  // and the open detail modal without reloading everything.
  async function refreshEstimateShare(id: string) {
    try {
      const { data } = await supabase
        .from("estimate_headers")
        .select("status, shared_at, shared_via, shared_by, withdrawn_at, shared_snapshot")
        .eq("id", id)
        .maybeSingle();
      if (data) {
        setEstimates(prev => prev.map(e => e.id === id ? { ...e, ...data } : e));
        setViewingEstimate(prev => prev && prev.id === id ? { ...prev, ...data } : prev);
      }
    } catch (e) {
      console.error("Error refreshing estimate share state:", e);
    }
  }

  async function getAISuggestion() {
    if (!form.title.trim()) return;
    setAiLoading(true); setAiSuggestion(null);
    try {
      const text = await magnusAI.chat(`You are a Jamaica construction expert. Write professional estimate notes for: "${form.title}". 2-3 sentences covering scope, terms, and conditions. Be concise and professional.`);
      setAiSuggestion(String(text).trim());
    } catch { setAiSuggestion(null); }
    setAiLoading(false);
  }

  function getTotal(estimateId: string) {
    return (itemsByEstimate[estimateId] || []).reduce((s, i) => s + (i.amount || 0), 0);
  }

  // Filter
  const filtered = estimates.filter(e => {
    const matchSearch = e.title.toLowerCase().includes(search.toLowerCase()) ||
      (e.projects?.name || "").toLowerCase().includes(search.toLowerCase());
    const matchTab = tab === "all" || e.status === tab;
    const matchProject = !projectFilter || e.project_id === projectFilter;
    return matchSearch && matchTab && matchProject;
  });

  const stats = {
    total: estimates.length,
    draft: estimates.filter(e => e.status === "draft").length,
    sent: estimates.filter(e => e.status === "sent").length,
    approved: estimates.filter(e => e.status === "approved").length,
    totalValue: estimates.filter(e => e.status === "approved").reduce((s, e) => s + getTotal(e.id), 0),
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#080b10]">
      <PageHeader
        title="Estimates"
        subtitle={`${stats.total} total · ${fmt(stats.totalValue)} approved`}
        actions={
          <>
            <Btn variant="ghost" size="sm"
              icon={<RefreshCw size={13} className={loading ? "animate-spin" : ""}/>}
              onClick={loadEstimates}/>
            <Btn variant="primary" size="sm" icon={<Plus size={13}/>} onClick={openNewEstimate}>
              New Estimate
            </Btn>
          </>
        }
      />

      <div className="p-6 space-y-5">
        {/* Stats strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total",    value: stats.total,    color: "text-slate-800 dark:text-slate-200",   key: "all" as Tab },
            { label: "Draft",    value: stats.draft,    color: "text-slate-500 dark:text-slate-400",   key: "draft" as Tab },
            { label: "Sent",     value: stats.sent,     color: "text-blue-400",    key: "sent" as Tab },
            { label: "Approved", value: stats.approved, color: "text-emerald-400", key: "approved" as Tab },
          ].map(s => (
            <button key={s.key} onClick={() => setTab(s.key)}
              className={cn("rounded-xl border p-3 text-left transition-all",
                tab === s.key ? "border-cyan-500/30 bg-cyan-500/10" : "border-slate-200 dark:border-white/[0.07] bg-white dark:bg-[#0c1018] hover:border-slate-300 dark:hover:border-white/[0.12]")}>
              <div className="text-[9px] font-bold uppercase tracking-widest text-slate-600 mb-1">{s.label}</div>
              <div className={cn("text-2xl font-bold", s.color)}>{s.value}</div>
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-700"/>
            <Input className="pl-8" placeholder="Search estimates..."
              value={search} onChange={e => setSearch(e.target.value)}/>
          </div>
          <Select value={projectFilter} onChange={e => setProjectFilter(e.target.value)} className="w-44">
            <option value="">All projects</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          <div className="flex items-center gap-1 rounded-lg border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-white/[0.04] p-1">
            <button onClick={() => setViewMode("grid")}
              className={cn("p-1.5 rounded-md transition-colors", viewMode === "grid" ? "bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-slate-200" : "text-slate-600 hover:text-slate-400")}>
              <LayoutGrid size={13}/>
            </button>
            <button onClick={() => setViewMode("list")}
              className={cn("p-1.5 rounded-md transition-colors", viewMode === "list" ? "bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-slate-200" : "text-slate-600 hover:text-slate-400")}>
              <List size={13}/>
            </button>
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex items-center justify-center py-16 text-xs text-slate-600">
            <RefreshCw size={14} className="animate-spin mr-2"/> Loading estimates...
          </div>
        ) : filtered.length === 0 ? (
          <Empty
            icon={<FileText size={20}/>}
            title={search ? "No estimates match your search" : "No estimates yet"}
            body={search ? "Try a different search." : "Create your first estimate or generate one from a BOQ."}
            action={!search ? <Btn variant="primary" icon={<Plus size={13}/>} onClick={openNewEstimate}>New Estimate</Btn> : undefined}
          />
        ) : viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map(e => (
              <EstimateCard
                key={e.id}
                estimate={e}
                total={getTotal(e.id)}
                onView={() => setViewingEstimate(e)}
                onDelete={() => deleteEstimate(e.id)}
                onDuplicate={() => duplicateEstimate(e)}
                onUpdateStatus={status => updateStatus(e.id, status)}
                onAdvisor={() => setAdvisorEstimate(e)}
                onSend={() => openSend(e)}
                seenViews={estimateViews}
              />
            ))}
          </div>
        ) : (
          <Card padding={false}>
            <Table>
              <thead>
                <tr>
                  <Th>Title</Th>
                  <Th>Project</Th>
                  <Th>Version</Th>
                  <Th>Status</Th>
                  <Th>Updated</Th>
                  <Th right>Total</Th>
                  <Th>Actions</Th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(e => (
                  <Tr key={e.id} onClick={() => setViewingEstimate(e)}>
                    <Td><span className="font-semibold text-slate-800 dark:text-slate-200">{e.title}</span></Td>
                    <Td muted>{e.projects?.name || "—"}</Td>
                    <Td muted>v{e.version}</Td>
                    <Td><Badge color={STATUS_COLOR[e.status]} dot>{e.status}</Badge></Td>
                    <Td muted>{fmtDate(e.updated_at)}</Td>
                    <Td right><span className="font-semibold text-emerald-400">{fmt(getTotal(e.id))}</span></Td>
                    <Td>
                      <div className="flex items-center gap-1" onClick={ev => ev.stopPropagation()}>
                        <button onClick={() => duplicateEstimate(e)}
                          className="p-1.5 rounded hover:bg-white/10 text-slate-600 hover:text-slate-300 transition-colors">
                          <Copy size={12}/>
                        </button>
                        <button onClick={() => deleteEstimate(e.id)}
                          className="p-1.5 rounded hover:bg-red-500/15 text-slate-600 hover:text-red-400 transition-colors">
                          <Trash2 size={12}/>
                        </button>
                      </div>
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          </Card>
        )}
      </div>

      {/* Detail Modal */}
      {viewingEstimate && (
        <EstimateDetailModal
          estimate={viewingEstimate}
          items={itemsByEstimate[viewingEstimate.id] || []}
          companyId={companyId}
          onUpdateStatus={status => updateStatus(viewingEstimate.id, status)}
          onSend={live => openSend(viewingEstimate, live)}
          seenViews={estimateViews}
          onClose={() => setViewingEstimate(null)}
        />
      )}

      {/* Send to Client */}
      {sendTarget && (() => {
        const est = estimates.find(x => x.id === sendTarget.estimateId);
        if (!est) return null;
        const at = isSharedNow(est.shared_at, est.withdrawn_at);
        return (
          <SendToClientModal
            open
            onClose={() => setSendTarget(null)}
            itemType="estimate"
            itemId={est.id}
            itemLabel={`Estimate "${est.title}"`}
            client={sendTarget.client}
            sharedAt={at}
            sharedVia={at ? (est.shared_via || null) : null}
            currentDetailLevel={at ? (est.shared_snapshot?.detail_level ?? null) : null}
            detailOptions
            buildSnapshot={buildSendSnapshot}
            messageText={(url) =>
              `Hello ${sendTarget.client.contact_name || sendTarget.client.name}, your estimate for ${sendTarget.projectName} is ready to view in your client portal:\n\n${url}\n\n${companyDisplayName(companySettings?.company_name)}`
            }
            onChanged={() => refreshEstimateShare(est.id)}
          />
        );
      })()}

      {/* AI Advisor Panel */}
      {advisorEstimate && companyId && (
        <EstimateAdvisorPanel
          estimateId={advisorEstimate.id}
          estimateTitle={advisorEstimate.title}
          estimateTotal={getTotal(advisorEstimate.id)}
          itemCount={(itemsByEstimate[advisorEstimate.id] || []).length}
          companyId={companyId}
          onClose={() => setAdvisorEstimate(null)}
        />
      )}

      {/* New Estimate Modal */}
      <Modal open={showNew} onClose={() => { setShowNew(false); setError(null); }}
        title="New Estimate" subtitle="Create a new project estimate">
        <div className="space-y-4">
          {error && <Alert type="error" onClose={() => setError(null)}>{error}</Alert>}
          <Field label="Title">
            <Input placeholder="e.g. Phase 1 Construction Estimate"
              value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} autoFocus/>
          </Field>
          <Field label="Project">
            <Select value={form.project_id} onChange={e => setForm(f => ({ ...f, project_id: e.target.value }))}>
              <option value="" disabled>Select a project</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label="Status">
            <Select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
              <option value="draft">Draft</option>
              <option value="approved">Approved</option>
            </Select>
          </Field>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">Notes</span>
              <button type="button" onClick={getAISuggestion} disabled={aiLoading || !form.title.trim()}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/20 text-[10px] text-purple-400 font-semibold disabled:opacity-40 transition">
                {aiLoading ? <Loader size={9} className="animate-spin"/> : <Sparkles size={9}/>}
                {aiLoading ? "Writing..." : "AI Write Notes"}
              </button>
            </div>
            {aiSuggestion && (
              <div className="mb-2 rounded-lg bg-purple-500/10 border border-purple-500/20 px-3 py-2 flex gap-2">
                <Bot size={11} className="text-purple-400 flex-shrink-0 mt-0.5"/>
                <div className="flex-1">
                  <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">{aiSuggestion}</p>
                  <button type="button" onClick={() => setForm(f => ({ ...f, notes: aiSuggestion }))}
                    className="mt-1 text-[10px] text-purple-400 hover:text-purple-300 font-semibold">Use this ?</button>
                </div>
                <button type="button" onClick={() => setAiSuggestion(null)} className="text-slate-600 hover:text-slate-400"><X size={10}/></button>
              </div>
            )}
            <textarea rows={2} placeholder="Any notes or terms..."
              value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.08] rounded-lg px-3 py-2 text-sm text-slate-800 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600 outline-none focus:border-blue-500/50 resize-none"/>
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-white/[0.06]">
            <Btn variant="ghost" onClick={() => { setShowNew(false); setError(null); }}>Cancel</Btn>
            <Btn variant="primary" onClick={createEstimate}
              disabled={!form.title.trim() || saving}>
              {saving ? "Creating..." : "Create Estimate"}
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}